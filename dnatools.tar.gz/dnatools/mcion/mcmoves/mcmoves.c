#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mcmoves.h"
#include "../bdna/bdna.h"
#include "../energy/energy.h"
#include "../tools/tools.h"

int monomerlist[10000];
int ionlist[10000];
int ionlist2[10000];

void add_to_list(int ionN, int index) {
	ionlist[ionN] = index;
} 


void add_to_list2(int ionN, int index) {
	ionlist2[ionN] = index;
} 


int not_in_list2(int ionN, int index) {
	for (int i = 0; i < ionN; i++) if (ionlist2[i] == index) return 0;
	return 1;
}


int not_in_list(int ionN, int index) {
	for (int i = 0; i < ionN; i++) if (ionlist[i] == index) return 0;
	return 1;
}

void cross(double &x, double &y, double &z, double x1, double y1, double z1, double x2, double y2, double z2) {
	x = y1*z2 - z1*y2;
	y = x1*z2 - z1*x2;
	z = x1*y2 - x2*y1;
}

int movepolymer(system_type *s) {
	matrix *W = new matrix[s->dna.nsteps+1];
	matrix A = identity(4);
	W[s->dna.nsteps/2] = A;
	for (int i = s->dna.nsteps/2; i < s->dna.nsteps; i++) {
		A = A * calculateW(s->dna.v[i]);
		W[i+1] = A;
	}
	A = identity(4);
	for (int i = s->dna.nsteps/2-1; i >= 0; i--) {
		A = A * invert(calculateW(s->dna.v[i]));
		W[i] = A;
	}
	int cloth[s->Nions];
	double dis;
	double ix,iy,iz;
	double dx,dy,dz, distance;
	for (int i = 0; i < s->Nions; i++) {
		dis = 10000.0;
		cloth[i] = -1;
		for (int j = 0; j < s->dna.nsteps+1; j++) {
			ix = s->ions[i].x; iy = s->ions[i].y; iz = s->ions[i].z;
			dx = W[j](1,4); dy = W[j](2,4); dz = W[j](3,4);
			distance = (ix-dx)*(ix-dx)+(iy-dy)*(iy-dy)+(iz-dz)*(iz-dz);
			if (distance < s->pivot_r*s->pivot_r) {
				if (distance < dis) {
					cloth[i] = j;
					dis = distance;
				}
			}
		}
	}
	
	double piv_overall = 1.0*drand48()/sqrt(s->dna.nsteps);
	double piv = piv_overall*drand48();
	for (int i = 0; i < s->dna.nsteps; i++) {
		if (drand48() < 0.1) piv = piv_overall*drand48();
		s->dna.v[i].setv(1,1, s->dna.v[i](1,1)+piv*1.0*(drand48()-0.5));
		s->dna.v[i].setv(2,1, s->dna.v[i](2,1)+piv*10.0*(drand48()-0.5));
		s->dna.v[i].setv(3,1, s->dna.v[i](3,1)+piv*4.0*(drand48()-0.5));
	}
	
	matrix Q = identity(4);
	A = identity(4);
	double x1,xx1,y1,yy1,z1,zz1;
	for (int i = s->dna.nsteps/2+1; i < s->dna.nsteps+1; i++) {
		A = A * calculateW(s->dna.v[i-1]);
		for (int j = 0; j < s->Nions; j++) {
			if (cloth[j] == i) {
				Q = invert(W[i])*A;
				x1 = s->ions[j].x - W[i](1,4);
				y1 = s->ions[j].y - W[i](2,4);
				z1 = s->ions[j].z - W[i](3,4);
				xx1 = x1*W[i](1,1)+y1*W[i](2,1)+z1*W[i](3,1);
				yy1 = x1*W[i](1,2)+y1*W[i](2,2)+z1*W[i](3,2);
				zz1 = x1*W[i](1,3)+y1*W[i](2,3)+z1*W[i](3,3);
				x1 = Q(1,1)*xx1+Q(1,2)*yy1+Q(1,3)*zz1 + Q(1,4);
				y1 = Q(2,1)*xx1+Q(2,2)*yy1+Q(2,3)*zz1 + Q(2,4);
				z1 = Q(3,1)*xx1+Q(3,2)*yy1+Q(3,3)*zz1 + Q(3,4);
				s->ions[j].x = W[i](1,1)*x1+W[i](1,2)*y1+W[i](1,3)*z1 + W[i](1,4);
				s->ions[j].y = W[i](2,1)*x1+W[i](2,2)*y1+W[i](2,3)*z1 + W[i](2,4);
				s->ions[j].z = W[i](3,1)*x1+W[i](3,2)*y1+W[i](3,3)*z1 + W[i](3,4);
			}
		}
	}
	A = identity(4);
	for (int i = s->dna.nsteps/2-1; i >= 0; i--) {
		A = A * invert(calculateW(s->dna.v[i]));
		for (int j = 0; j < s->Nions; j++) {
			if (cloth[j] == i) {
				Q = invert(W[i])*A;
				x1 = s->ions[j].x - W[i](1,4);
				y1 = s->ions[j].y - W[i](2,4);
				z1 = s->ions[j].z - W[i](3,4);
				xx1 = x1*W[i](1,1)+y1*W[i](2,1)+z1*W[i](3,1);
				yy1 = x1*W[i](1,2)+y1*W[i](2,2)+z1*W[i](3,2);
				zz1 = x1*W[i](1,3)+y1*W[i](2,3)+z1*W[i](3,3);
				x1 = Q(1,1)*xx1+Q(1,2)*yy1+Q(1,3)*zz1 + Q(1,4);
				y1 = Q(2,1)*xx1+Q(2,2)*yy1+Q(2,3)*zz1 + Q(2,4);
				z1 = Q(3,1)*xx1+Q(3,2)*yy1+Q(3,3)*zz1 + Q(3,4);
				s->ions[j].x = W[i](1,1)*x1+W[i](1,2)*y1+W[i](1,3)*z1 + W[i](1,4);
				s->ions[j].y = W[i](2,1)*x1+W[i](2,2)*y1+W[i](2,3)*z1 + W[i](2,4);
				s->ions[j].z = W[i](3,1)*x1+W[i](3,2)*y1+W[i](3,3)*z1 + W[i](3,4);
			}
		}
	}
	

// is detailed balance OK?
        A = identity(4);
        W[s->dna.nsteps/2] = A;
        for (int i = s->dna.nsteps/2; i < s->dna.nsteps; i++) {
                A = A * calculateW(s->dna.v[i]);
                W[i+1] = A;
        }
        A = identity(4);
        for (int i = s->dna.nsteps/2-1; i >= 0; i--) {
                A = A * invert(calculateW(s->dna.v[i]));
                W[i] = A;
        }
        for (int i = 0; i < s->Nions; i++) {
                if (cloth[i] == -1)
                for (int j = 0; j < s->dna.nsteps+1; j++) {
                        ix = s->ions[i].x; iy = s->ions[i].y; iz = s->ions[i].z;
                        dx = W[j](1,4); dy = W[j](2,4); dz = W[j](3,4);
                        distance = (ix-dx)*(ix-dx)+(iy-dy)*(iy-dy)+(iz-dz)*(iz-dz);
                        if (distance < s->pivot_r*s->pivot_r) {
				delete [] W;
                        	return 0;
			}
                }
        }

	delete [] W;
	return 1;
}

// clothed pivot move - remember that index (Nmonomers / 2) is fixed at the origin
int movepolymer3(system_type *s, float anglemax, int detailed) {

// pick which half of the polymer to move
	
	int m, m2;
	double d, d2;
	double x1, y1, z1, xx1, yy1, zz1;
	double vx, vy, vz, vr;

	double theta;
	
	int ionN = 0;
	int ionN2 = 0;
	int monomerN = 0;
	int added = 0;
	
//	double test = calculateESenergy(s);
	
	float *ph;
// do the second half first, since the ordering is positive

	int Ok;

	do {
		
		Ok = 0;
		m = (int)(s->dna.nsteps*drand48());
		m2 = (int)(s->dna.nsteps*drand48());

		if ((m < s->dna.nsteps/2) && (m2 < s->dna.nsteps/2)) {
			if (m > m2) {
  			  int temp = m2;
			  m2 = m;
			  m = temp;
			}
			Ok = 1;
		} else if ((m2 >= s->dna.nsteps/2) && (m >= s->dna.nsteps/2)) {
			if (m > m2) {
				int temp = m2;
				m2 = m;
				m = temp;
			}
			Ok = 1;
		}
		if (abs(m2 - m) < 4) Ok = 0;
		
	} while (!Ok);
	
	for (int i = m+1; i < m2; i++) monomerlist[monomerN++] = i;
	for (int i = m2; i < m2+s->dna.nsteps-monomerN; i++) {
		if (i >= s->dna.nsteps) monomerlist[monomerN+i-m2] = i-s->dna.nsteps;
		else monomerlist[monomerN+i-m2] = i;
	}

	ph = s->dna.add_phosphates();

		// check to see what ions we need to add to the cloth
				for (int j = 0; j < s->Nions; j++) {
					if (not_in_list(ionN, j)) {
						added = 0;
						for (int i = 0; (i < monomerN) && !added; i++) {
						if (((d2 = ((ph[9*monomerlist[i]] - s->ions[j].x) * (ph[9*monomerlist[i]] - s->ions[j].x) + (ph[9*monomerlist[i]+1] - s->ions[j].y) * (ph[9*monomerlist[i]+1] - s->ions[j].y) + 
						(ph[9*monomerlist[i]+2] - s->ions[j].z) * (ph[9*monomerlist[i]+2] - s->ions[j].z))) < s->pivot_r * s->pivot_r)) {
							added = 1;
							for (int k = monomerN; (k < s->dna.nsteps) && added; k++) {
								if (((ph[9*monomerlist[k]] - s->ions[j].x) * (ph[9*monomerlist[k]] - s->ions[j].x) + (ph[9*monomerlist[k]+1] - s->ions[j].y) * (ph[9*monomerlist[k]+1] - s->ions[j].y) + 
									(ph[9*monomerlist[k]+2] - s->ions[j].z) * (ph[9*monomerlist[k]+2] - s->ions[j].z)) < d2) added = 0;
							}
							if (added) add_to_list(ionN++, j);
						}
						}
					}
				}




		matrix M1 = calculateW(s->dna.v[m]);
		matrix W = M1;
		for (int i = 0; i < monomerN; i++) W = W * calculateW(s->dna.v[monomerlist[i]]);
		W = W * calculateW(s->dna.v[m2]);
		vx = W(1,4);
		vy = W(2,4);
		vz = W(3,4);
		vr = sqrt(vx*vx+vy*vy+vz*vz);
		vx /= vr;
		vy /= vr;
		vz /= vr;

		matrix Q = identity(4);
		theta = anglemax * 2.0 * (drand48() - 0.5) * M_PI / 180.0;
		Q.setv(1,1, vx*vx+(1.0-vx*vx)*cos(theta));
	  	Q.setv(2,1, vx*vy*(1.0-cos(theta))+vz*sin(theta));
	  	Q.setv(3,1, vx*vz*(1.0-cos(theta))-vy*sin(theta));
	  	Q.setv(1,2, vy*vx*(1.0-cos(theta))-vz*sin(theta));
	  	Q.setv(2,2, vy*vy+(1.0-vy*vy)*cos(theta));
	  	Q.setv(3,2, vy*vz*(1.0-cos(theta))+vx*sin(theta));
	  	Q.setv(1,3, vz*vx*(1.0-cos(theta))+vy*sin(theta));
	  	Q.setv(2,3, vz*vy*(1.0-cos(theta))-vx*sin(theta));
	  	Q.setv(3,3, vz*vz+(1.0-vz*vz)*cos(theta));

		W = M1;
		for (int i = 0; i < monomerN; i++) W = W * calculateW(s->dna.v[monomerlist[i]]);
		W = W * calculateW(s->dna.v[m2]);
		
		matrix WW = identity(4);
		if (m >= s->dna.nsteps/2) for (int i = s->dna.nsteps/2; i < m; i++) WW = WW * calculateW(s->dna.v[i]);
		else {
			for (int i = m; i < s->dna.nsteps/2; i++) WW = WW * calculateW(s->dna.v[i]);
			WW = invert(WW);
		}
		s->dna.v[m] = calculatetp(Q*M1);

//		writematrix(stdout, s->dna.v[m]);
		matrix M2 = calculateW(s->dna.v[m])*invert(M1);
		matrix Wnew = invert(Q*M1)*W;
		for (int i = 0; i < monomerN; i++) Wnew = invert(calculateW(s->dna.v[monomerlist[i]])) * Wnew;
		s->dna.v[m2] = calculatetp(Wnew);
//		printf("\n");
//		writematrix(stdout, s->dna.v[m2]);
//		printf("\n");
		
		for (int i = 0; i < ionN; i++) {
			x1 = s->ions[ionlist[i]].x - WW(1,4);
			y1 = s->ions[ionlist[i]].y - WW(2,4);
			z1 = s->ions[ionlist[i]].z - WW(3,4);
			xx1 = x1*WW(1,1)+y1*WW(2,1)+z1*WW(3,1);
			yy1 = x1*WW(1,2)+y1*WW(2,2)+z1*WW(3,2);
			zz1 = x1*WW(1,3)+y1*WW(2,3)+z1*WW(3,3);
			x1 = M2(1,1)*xx1+M2(1,2)*yy1+M2(1,3)*zz1 + M2(1,4);
			y1 = M2(2,1)*xx1+M2(2,2)*yy1+M2(2,3)*zz1 + M2(2,4);
			z1 = M2(3,1)*xx1+M2(3,2)*yy1+M2(3,3)*zz1 + M2(3,4);
			s->ions[ionlist[i]].x = WW(1,1)*x1+WW(1,2)*y1+WW(1,3)*z1 + WW(1,4);
			s->ions[ionlist[i]].y = WW(2,1)*x1+WW(2,2)*y1+WW(2,3)*z1 + WW(2,4);
			s->ions[ionlist[i]].z = WW(3,1)*x1+WW(3,2)*y1+WW(3,3)*z1 + WW(3,4);
		}
		
		delete [] ph;
	
	return 1;

}


// clothed pivot move - remember that index (Nmonomers / 2) is fixed at the origin
int movepolymer2(system_type *s, float anglemax, int detailed) {


	int half = (int)(2.0*drand48());
	
	int m;
	double d, d2;
	double x1, y1, z1;
	double xx1, yy1, zz1;

	double theta;
	
	int ionN = 0;
	int ionN2 = 0;
	int added = 0;
	
//	double test = calculateESenergy(s);
	
	float *ph;
// do the second half first, since the ordering is positive
	if (half == 0) {

		m = s->dna.nsteps/2 + (int)((s->dna.nsteps - s->dna.nsteps/2)*drand48());
		matrix W = identity(4);
		for (int i = s->dna.nsteps/2; i < m; i++) W = W * calculateW(s->dna.v[i]);

//		printf("pivot %d\n", m);

		ph = s->dna.add_phosphates();

// check to see what ions we need to add to the cloth
		for (int j = 0; j < s->Nions; j++) {
			if (not_in_list(ionN, j)) {
				added = 0;
				for (int i = m; (i <= s->dna.nsteps) && !added; i++) {
				if (((d2 = ((ph[9*i] - s->ions[j].x) * (ph[9*i] - s->ions[j].x) + (ph[9*i+1] - s->ions[j].y) * (ph[9*i+1] - s->ions[j].y) + 
				(ph[9*i+2] - s->ions[j].z) * (ph[9*i+2] - s->ions[j].z))) < s->pivot_r * s->pivot_r)) {
					added = 1;
					for (int k = 0; (k < m) && added; k++) {
						if (((ph[9*k] - s->ions[j].x) * (ph[9*k] - s->ions[j].x) + (ph[9*k+1] - s->ions[j].y) * (ph[9*k+1] - s->ions[j].y) + 
							(ph[9*k+2] - s->ions[j].z) * (ph[9*k+2] - s->ions[j].z)) < d2) added = 0;
					}
					if (added) add_to_list(ionN++, j);
				}
				}
			}
		}


		matrix M1 = calculateW(s->dna.v[m]);
		theta = anglemax * 0.2 * (drand48() - 0.5);
		s->dna.v[m].setv(1,1, s->dna.v[m](1,1)+theta);
		theta = anglemax * 2.0 * (drand48() - 0.5);
		s->dna.v[m].setv(2,1, s->dna.v[m](2,1)+theta);
		theta = anglemax * (drand48() - 0.5);
		s->dna.v[m].setv(3,1, s->dna.v[m](3,1)+theta);
		matrix M2 = invert(calculateW(s->dna.v[m]))*M1;
		
		for (int i = 0; i < ionN; i++) {
			x1 = s->ions[ionlist[i]].x - W(1,4);
			y1 = s->ions[ionlist[i]].y - W(2,4);
			z1 = s->ions[ionlist[i]].z - W(3,4);
			xx1 = x1*W(1,1)+y1*W(2,1)+z1*W(3,1);
			yy1 = x1*W(1,2)+y1*W(2,2)+z1*W(3,2);
			zz1 = x1*W(1,3)+y1*W(2,3)+z1*W(3,3);
			x1 = M2(1,1)*xx1+M2(1,2)*yy1+M2(1,3)*zz1 + M2(1,4);
			y1 = M2(2,1)*xx1+M2(2,2)*yy1+M2(2,3)*zz1 + M2(2,4);
			z1 = M2(3,1)*xx1+M2(3,2)*yy1+M2(3,3)*zz1 + M2(3,4);
			s->ions[ionlist[i]].x = W(1,1)*x1+W(1,2)*y1+W(1,3)*z1 + W(1,4);
			s->ions[ionlist[i]].y = W(2,1)*x1+W(2,2)*y1+W(2,3)*z1 + W(2,4);
			s->ions[ionlist[i]].z = W(3,1)*x1+W(3,2)*y1+W(3,3)*z1 + W(3,4);
		}
//		printf("%f %f %f", ph[9*(m-1)], ph[9*(m-1)+1], ph[9*(m-1)+2]);
//		printf("  %f %f %f", ph[9*(m+1)], ph[9*(m+1)+1], ph[9*(m+1)+2]);

		delete [] ph;


	} else {

// do the first half
		m = (int)((s->dna.nsteps / 2) * drand48());
		ph = s->dna.add_phosphates();
//		printf("pivot %d\n", m);
		matrix W = identity(4);
		for (int i = s->dna.nsteps/2-1; i > m; i--) {
			W = W * invert(calculateW(s->dna.v[i]));
		}
		
// check to see what ions we need to add to the cloth
		for (int j = 0; j < s->Nions; j++) {
		 	if (not_in_list(ionN, j)) {
				added = 0;
				for (int i = 0; (i <= m) && !added; i++) {
					if (((d2 = ((ph[9*i] - s->ions[j].x) * (ph[9*i] - s->ions[j].x) + (ph[9*i+1] - s->ions[j].y) * (ph[9*i+1] - s->ions[j].y) + 
						(ph[9*i+2] - s->ions[j].z) * (ph[9*i+2] - s->ions[j].z))) < s->pivot_r * s->pivot_r)) {
						added = 1;
						for (int k = m+1; (k <= s->dna.nsteps) && added; k++) {
							if (((ph[9*k] - s->ions[j].x) * (ph[9*k] - s->ions[j].x) + (ph[9*k+1] - s->ions[j].y) * (ph[9*k+1] - s->ions[j].y) + 
								(ph[9*k+2] - s->ions[j].z) * (ph[9*k+2] - s->ions[j].z)) < d2) added = 0;
						}
						if (added) add_to_list(ionN++, j);
					}
				}
			}
		}
		

		matrix M1 = calculateW(s->dna.v[m]);
		theta = anglemax * 0.2 * (drand48() - 0.5);
		s->dna.v[m].setv(1,1, s->dna.v[m](1,1)+theta);
		theta = anglemax * 2.0 * (drand48() - 0.5);
		s->dna.v[m].setv(2,1, s->dna.v[m](2,1)+theta);
		theta = anglemax * (drand48() - 0.5);
		s->dna.v[m].setv(3,1, s->dna.v[m](3,1)+theta);

		matrix M2 = invert(calculateW(s->dna.v[m]))*M1;
//		writematrix(stdout, M2);
		for (int i = 0; i < ionN; i++) {
			x1 = s->ions[ionlist[i]].x - W(1,4);
			y1 = s->ions[ionlist[i]].y - W(2,4);
			z1 = s->ions[ionlist[i]].z - W(3,4);
			xx1 = x1*W(1,1)+y1*W(2,1)+z1*W(3,1);
			yy1 = x1*W(1,2)+y1*W(2,2)+z1*W(3,2);
			zz1 = x1*W(1,3)+y1*W(2,3)+z1*W(3,3);
			x1 = M2(1,1)*xx1+M2(1,2)*yy1+M2(1,3)*zz1 + M2(1,4);
			y1 = M2(2,1)*xx1+M2(2,2)*yy1+M2(2,3)*zz1 + M2(2,4);
			z1 = M2(3,1)*xx1+M2(3,2)*yy1+M2(3,3)*zz1 + M2(3,4);
			s->ions[ionlist[i]].x = W(1,1)*x1+W(1,2)*y1+W(1,3)*z1 + W(1,4);
			s->ions[ionlist[i]].y = W(2,1)*x1+W(2,2)*y1+W(2,3)*z1 + W(2,4);
			s->ions[ionlist[i]].z = W(3,1)*x1+W(3,2)*y1+W(3,3)*z1 + W(3,4);
		}
		
		if (detailed) for (int j = 0; j < s->Nions; j++) {
			if (not_in_list2(ionN2, j)) {
				added = 0;
				for (int i = 0; (i <= m) && !added; i++) {
				if (((d2 = ((ph[9*i] - s->ions[j].x) * (ph[9*i] - s->ions[j].x) + (ph[9*i+1] - s->ions[j].y) * (ph[9*i+1] - s->ions[j].y) + 
					(ph[9*i+2] - s->ions[j].z) * (ph[9*i+2] - s->ions[j].z))) < s->pivot_r * s->pivot_r)) {
						added = 1;
						for (int k = m+1; (k <= s->dna.nsteps) && added; k++) {
							if (((ph[9*k] - s->ions[j].x) * (ph[9*k] - s->ions[j].x) + (ph[9*k+1] - s->ions[j].y) * (ph[9*k+1] - s->ions[j].y) + 
								(ph[9*k+2] - s->ions[j].z) * (ph[9*k+2] - s->ions[j].z)) < d2) added = 0;
						}
						if (added) add_to_list2(ionN2++, j);
					}
			}
		}
		} else {
				ionN2 = ionN;
				for (int i = 0; i < ionN2; i++) add_to_list2(i, ionlist[i]);
		}
		
		if (ionN != ionN2) {
		//	if (ionN2 < ionN) printf("%d missing ions of %d, at %d, first half!\n", ionN - ionN2, ionN, m);
			delete [] ph;
			return 0;
		}

		delete [] ph;

	}

	return 1;
	
}


// displace an ion
int moveion(system_type *s, int q, double &dE, double dis) {

	float dx = dis * 2.0 * (drand48() - 0.5);
	float dy = dis * 2.0 * (drand48() - 0.5);
	float dz = dis * 2.0 * (drand48() - 0.5);

	double d;
	double K = 0.329*sqrt(s->salt);
	
	dE = 0.0;

	float xx, yy, zz;	

	for (int i = 0; i < s->Nions; i++) {
		if (i != q) {
		      if (s->boxtype == 1) {
			d = sqrt((s->ions[i].x - s->ions[q].x) * (s->ions[i].x - s->ions[q].x) + (s->ions[i].y - s->ions[q].y) * (s->ions[i].y - s->ions[q].y) + (s->ions[i].z - s->ions[q].z) * (s->ions[i].z - s->ions[q].z));
			dE -= (double)(s->ions[i].charge * s->ions[q].charge) * exp(-K*d) / d;
		      }
		      if (s->boxtype == 2) {
						xx = fabsf(s->ions[i].x - s->ions[q].x);
                        yy = fabsf(s->ions[i].y - s->ions[q].y);
                        zz = fabsf(s->ions[i].z - s->ions[q].z);
						if (xx > s->cell_x/2.0) xx = s->cell_x - xx;
                        if (yy > s->cell_y/2.0) yy = s->cell_y - yy;
                        if (zz > s->cell_z/2.0) zz = s->cell_z - zz;
						d = sqrt(xx*xx+yy*yy+zz*zz);
                        dE -= (double)(s->ions[i].charge * s->ions[q].charge) * exp(-K*d) / d;
		      }
		}
	}
	for (int i = 0; i < s->Natoms; i++) {
	      if (s->boxtype == 1) {
		d = sqrt((s->atoms[i].x - s->ions[q].x) * (s->atoms[i].x - s->ions[q].x) + (s->atoms[i].y - s->ions[q].y) * (s->atoms[i].y - s->ions[q].y) + (s->atoms[i].z - s->ions[q].z) * (s->atoms[i].z - s->ions[q].z));
		dE -= (double)(s->atoms[i].charge * s->ions[q].charge) * exp(-K*d) / d;
	      }
                      if (s->boxtype == 2) {
                        xx = fabsf(s->atoms[i].x - s->ions[q].x);
                        yy = fabsf(s->atoms[i].y - s->ions[q].y);
                        zz = fabsf(s->atoms[i].z - s->ions[q].z);
                        if (xx > s->cell_x/2.0) xx = s->cell_x - xx;
                        if (yy > s->cell_y/2.0) yy = s->cell_y - yy;
                        if (zz > s->cell_z/2.0) zz = s->cell_z - zz;
                        d = sqrt(xx*xx+yy*yy+zz*zz);
                        dE -= (double)(s->atoms[i].charge * s->ions[q].charge) * exp(-K*d) / d;
                      }

	}

	s->ions[q].x += dx;
	s->ions[q].y += dy;
	s->ions[q].z += dz;

	if (s->boxtype == 2) {
	  if (s->ions[q].x > s->cell_x/2.0) s->ions[q].x -= s->cell_x;
	  if (s->ions[q].x < -s->cell_x/2.0) s->ions[q].x += s->cell_x;
      if (s->ions[q].y > s->cell_y/2.0) s->ions[q].y -= s->cell_y;
      if (s->ions[q].y < -s->cell_y/2.0) s->ions[q].y += s->cell_y;
      if (s->ions[q].z > s->cell_z/2.0) s->ions[q].z -= s->cell_z;
      if (s->ions[q].z < -s->cell_z/2.0) s->ions[q].z += s->cell_z;
	}

	if ((s->boxtype == 1) && sqrt(s->ions[q].x * s->ions[q].x + s->ions[q].y * s->ions[q].y + s->ions[q].z * s->ions[q].z) > s->cell_radius - s->ions[q].r) {
		dE = 1e10;
		return 0;
	}

	for (int i = 0; i < s->Nions; i++) {
		if (i != q) {
			if (s->boxtype == 1) {
			d = sqrt((s->ions[i].x - s->ions[q].x) * (s->ions[i].x - s->ions[q].x) + (s->ions[i].y - s->ions[q].y) * (s->ions[i].y - s->ions[q].y) + (s->ions[i].z - s->ions[q].z) * (s->ions[i].z - s->ions[q].z));
			if (d < s->ions[i].r + s->ions[q].r) {
				dE = 1e10;
				return 0;
			}
			dE += (double)(s->ions[i].charge * s->ions[q].charge) * exp (-K*d) / d;
        	}
	        if (s->boxtype == 2) {
						xx = fabsf(s->ions[i].x - s->ions[q].x);
			            yy = fabsf(s->ions[i].y - s->ions[q].y);
			            zz = fabsf(s->ions[i].z - s->ions[q].z);
						if (xx > s->cell_x/2.0) xx = s->cell_x - xx;
			            if (yy > s->cell_y/2.0) yy = s->cell_y - yy;
			            if (zz > s->cell_z/2.0) zz = s->cell_z - zz;
						d = sqrt(xx*xx+yy*yy+zz*zz);
						if (d < s->ions[i].r + s->ions[q].r) {
							dE = 1e10;
							return 0;
						}
			            dE += (double)(s->ions[i].charge * s->ions[q].charge) * exp(-K*d) / d;
			}
		}
	}
	
	for (int i = 0; i < s->Natoms; i++) {
		if (s->boxtype == 1) {
		d = sqrt((s->atoms[i].x - s->ions[q].x) * (s->atoms[i].x - s->ions[q].x) + (s->atoms[i].y - s->ions[q].y) * (s->atoms[i].y - s->ions[q].y) + (s->atoms[i].z - s->ions[q].z) * (s->atoms[i].z - s->ions[q].z));
		if (d < s->atoms[i].radius + s->ions[q].r) {
			dE = 1e10;
			return 0;
		}
		dE += (double)(s->atoms[i].charge * s->ions[q].charge) * exp (-K*d) / d;
		}
		if (s->boxtype == 2) {
		                        xx = fabsf(s->atoms[i].x - s->ions[q].x);
		                        yy = fabsf(s->atoms[i].y - s->ions[q].y);
		                        zz = fabsf(s->atoms[i].z - s->ions[q].z);
		                        if (xx > s->cell_x/2.0) xx = s->cell_x - xx;
		                        if (yy > s->cell_y/2.0) yy = s->cell_y - yy;
		                        if (zz > s->cell_z/2.0) zz = s->cell_z - zz;
		                        d = sqrt(xx*xx+yy*yy+zz*zz);
								if (d < s->atoms[i].radius + s->ions[q].r) {
									dE = 1e10;
									return 0;
								}
		                        dE += (double)(s->atoms[i].charge * s->ions[q].charge) * exp(-K*d) / d;
		}
	}
	
	dE = K_ES * dE / DIELECTRIC;
	
	return 1;

}

