#ifndef _MCMOVES_H
#define _MCMOVES_H

#include "../input/input.h"

int moveion(system_type *s, int q, double &dE, double dis);
int movepolymer(system_type *s);
int movepolymer2(system_type *s, float anglemax, int detailed);
int movepolymer3(system_type *s, float anglemax, int detailed);

#endif

