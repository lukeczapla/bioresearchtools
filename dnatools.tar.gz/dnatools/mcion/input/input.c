#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "input.h"

int n_iontypes;
ion_type *iontypes;

system_type *copysystem(system_type *s) {

	system_type *x = new system_type;
	
	x->pivot_r = s->pivot_r;
	x->pivot_P = s->pivot_P;
	x->d_max = s->d_max;
	x->angle_max = s->angle_max;
	x->cell_radius = s->cell_radius;
	x->polymer_charge = s->polymer_charge;
	x->salt = s->salt;
	x->Nions = s->Nions;
        x->Natoms = s->Natoms;
	x->cell_x = s->cell_x;
        x->cell_y = s->cell_y;
        x->cell_z = s->cell_z;
	x->boxtype = s->boxtype;


	x->ions = new ion[x->Nions];
        x->atoms = new atom[x->Natoms];
	x->dna = s->dna;
	strcpy(x->seqfile, s->seqfile);

	for (int i = 0; i < x->Nions; i++) {
		x->ions[i].x = s->ions[i].x;
		x->ions[i].y = s->ions[i].y;
		x->ions[i].z = s->ions[i].z;
		x->ions[i].charge = s->ions[i].charge;
		x->ions[i].r = s->ions[i].r;
	}

        for (int i = 0; i < x->Natoms; i++) {
		x->atoms[i].x = s->atoms[i].x;
		x->atoms[i].y = s->atoms[i].y;
                x->atoms[i].z = s->atoms[i].z;
                x->atoms[i].radius = s->atoms[i].radius;
                x->atoms[i].charge = s->atoms[i].charge;
		x->atoms[i].chain = s->atoms[i].chain;
        }

	return x;
	
}

void copychange(system_type *s1, system_type *s2) {
	
	for (int i = 0; i < s1->Nions; i++) {
		s1->ions[i].x = s2->ions[i].x;
		s1->ions[i].y = s2->ions[i].y;
		s1->ions[i].z = s2->ions[i].z;
	}

}


// readinput opens the input file "filename" and sets up the system parameters
// 
//
system_type *readinput(char *filename) {

// open the input file
	FILE *f = fopen(filename, "r");
	if (f == NULL) {
		printf("error opening input file %s\n", filename);
		exit(0);
	}

	system_type *s = new system_type;
	
	fscanf(f, "%f %f %f %f %f %d", &s->pivot_r, &s->pivot_P, &s->d_max, &s->angle_max, &s->salt, &s->boxtype);
	if (s->boxtype == 1)
	  fscanf(f, "%f", &s->cell_radius);
	if (s->boxtype == 2)
	  fscanf(f, "%f %f %f", &s->cell_x, &s->cell_y, &s->cell_z);

// read the polymer chain information
	fscanf(f, "%s", s->seqfile);

        s->atoms = readatoms(s->seqfile, s->Natoms);

        s->polymer_charge = 0.0;
        for (int i = 0; i < s->Natoms; i++) s->polymer_charge += (double)s->atoms[i].charge;
        s->polymer_charge = round(s->polymer_charge);

	printf("total charge of biomolecule system = %f e\n", s->polymer_charge);

// read the ion information
	fscanf(f, "%d", &n_iontypes);
	
	iontypes = new ion_type[n_iontypes];
	
	s->Nions = 0;
	for (int i = 0; i < n_iontypes; i++) {
		fscanf(f, "%d %f %f %s", &iontypes[i].N, &iontypes[i].charge, &iontypes[i].r, iontypes[i].name);
		if (iontypes[i].N == 0) {
			iontypes[i].N = -(int)lroundf(s->polymer_charge / iontypes[i].charge);
			printf("%d ions (%s) with charge = %f (e) and radius = %f\n", iontypes[i].N, iontypes[i].name, iontypes[i].charge, iontypes[i].r);
		} else {
			printf("%d ions (%s) with charge = %f (e) and radius = %f\n", iontypes[i].N, iontypes[i].name, iontypes[i].charge, iontypes[i].r);
		}
		s->Nions += iontypes[i].N;
	}

	s->ions = new ion[s->Nions];
	int ionN = 0;
	for (int i = 0; i < n_iontypes; i++) {
		for (int j = 0; j < iontypes[i].N; j++) {
			s->ions[ionN].charge = iontypes[i].charge;
			s->ions[ionN].r = iontypes[i].r; 
			s->ions[ionN].iontype = i;
			ionN++;
		}
	}

// clean stuff up and return the goods
	fclose(f);
	return s;

}

void writeions(const char *fname, system_type *s) {
	FILE *f = fopen(fname, "w");
	int nn = 1;
	for (int i = 0; i < s->Nions; i++) {
		if ((i != 0) && (s->ions[i-1].iontype != s->ions[i].iontype)) nn = 1;
		fprintf(f, "ATOM  %5d%5s%4s  %4d    %8.3f%8.3f%8.3f%6.2f%6.2f\n", i+1, iontypes[s->ions[i].iontype].name, iontypes[s->ions[i].iontype].name, nn, s->ions[i].x,s->ions[i].y, s->ions[i].z, s->ions[i].r, s->ions[i].charge);

		nn++;

	}
	fclose(f);
}

atom *readatoms(const char *fname, int &N) {
 
    atom *atoms = new atom[5000];

    FILE *f = fopen(fname, "r");
    char atom[8];
    char anum[7];
    char at[7];
    char res[6];
    char cchain[5];
    char resn[6];
    char none[6];
    char segname[11];
    float x, y, z;
    float charge, radius;
    char s[257];
    char *p;
    N = 0;

    do {
      p = fgets(s, 256, f);
      strcpy(atom, "      ");
      strcpy(cchain, "  ");
      strcpy(res, "    ");
      strcpy(resn, "    ");
      strcpy(at, "     ");      
      strcpy(anum, "     ");
      strcpy(none, "    ");
      strcpy(segname, "          ");
      sscanf(s, "%6c%5c%5c%4c%2c%4c%4c%8f%8f%8f%6f%6f%10c", atom, anum, at, res, cchain, resn, none, &x, &y, &z, &radius, &charge, segname);
      if (strcmp(atom, "ATOM  ") == 0) {
      atoms[N].x = x;
      atoms[N].y = y;
      atoms[N].z = z;
      atoms[N].charge = charge;
      atoms[N].radius = radius;
      char *chain = strstr(segname, "DNA");
      atoms[N].chain = chain[3];
      N++;
//      if ((strstr(segname, "DNAC") != NULL) || (strstr(segname, "DNAD") != NULL)) {
//  y += 25.0;
//}
//      fprintf(stdout, "%6s%5s%5s%4s%2s%4s%4s%8.3f%8.3f%8.3f%6.2f%6.2f%10s\n", atom, anum, at, res, cchain, resn, none, x, y, z, radius, charge, segname);
      }

    } while ((p != NULL));
    fclose(f);
//    for (int i = 0; i < N; i++) {
//      printf("%lf %lf %lf , %lf %lf, %c\n", atoms[i].x, atoms[i].y, atoms[i].z, atoms[i].radius, atoms[i].charge, atoms[i].chain);
//    }
//    printf("%d atoms in system\n", N);
   return atoms;
}


int gvolume(system_type *s) {
  gpoint points[100000];
  int Np = 0;
  int vol = 0;
  int found;
  float d;
  for (int i = 0; i < s->Natoms; i++) {
    float X1 = s->atoms[i].x;
    float Y1 = s->atoms[i].y;
    float Z1 = s->atoms[i].z;
    int xx = (int)X1;
    int yy = (int)Y1;
    int zz = (int)Z1;
    for (int x = xx-3; x <= xx+3; x++) for (int y = yy-3; y <= yy+3; y++) for (int z = zz-3; z <= zz+3; z++) {
      d = sqrt((X1-(float)x)*(X1-(float)x)+(Y1-(float)y)*(Y1-(float)y)+(Z1-(float)z)*(Z1-(float)z));
      if (d < s->atoms[i].radius) { 
        found = 0;
	for (int j = 0; (j < Np) && (!found); j++) {
	  if ((points[j].x == x) && (points[j].y == y) && (points[j].z == z)) found = 1;
	}
	if (!found) {
	  points[Np].x = x; points[Np].y = y; points[Np].z = z; Np++;
	}
      }
    }
  }

  return Np;
}


// these functions create "trajectory" files
// writeconfig either appends the new configuration to existing trajectory or writes the new system
// readconfig reads record "n" from the trajectory
/*
void writeconfig(char *filename, system_type *s, int append) {
	FILE *f;
	if (append) f = fopen(filename, "a");
	else f = fopen(filename, "w");
	if (!append) fwrite(s, 6*sizeof(float)+2*sizeof(int), 1, f);
	fwrite(s->monomers, sizeof(monomer), s->Nmonomers, f);
	fwrite(s->ions, sizeof(ion), s->Nions, f);
	fwrite(s->bonds, sizeof(bond), s->Nmonomers-1, f);
	fclose(f);
}

system_type *readconfig(char *filename, int n) {
	FILE *f = fopen(filename, "r");
	if (f == NULL) return NULL;
	system_type *s = new system_type;
	if (fread(s, 6*sizeof(float)+2*sizeof(int), 1, f) != 1) {
		fclose(f); return NULL;
	}
	s->monomers = new monomer[s->Nmonomers];
	s->ions = new ion[s->Nions];
	s->bonds = new bond[s->Nmonomers-1];
	for (int i = 0; i < n; i++) {
		if (fread(s->monomers, sizeof(monomer), s->Nmonomers, f) != (size_t)s->Nmonomers) {
			fclose(f); return NULL;
		}
		if (fread(s->ions, sizeof(ion), s->Nions, f) != (size_t)s->Nions) {
			fclose(f); return NULL;
		}
		if (fread(s->bonds, sizeof(bond), s->Nmonomers-1, f) != (size_t)s->Nmonomers-1) {
			fclose(f); return NULL;
		}
	}
	fclose(f);
	return s;
}
*/
