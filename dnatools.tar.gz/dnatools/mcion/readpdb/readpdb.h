#ifndef _H_READPDB_
#define _H_READPDB_

struct atom {
  float x;
  float y;
  float z;
  float charge;
  float radius;
  char chain;
};

atom *returnsystem(const char *fname, int &N);

#endif

