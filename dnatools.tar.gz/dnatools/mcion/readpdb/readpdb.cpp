#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "readpdb.h"

atom *atoms;

atom *returnsystem(const char *fname, int &N) {
 
    atoms = new atom[5000];

    FILE *f = fopen(fname, "r");
    char atom[8];
    char anum[7];
    char at[7];
    char res[6];
    char cchain[5];
    char resn[6];
    char none[6];
    char segname[11];
    float x, y, z, xn, yn, zn;
    float charge, radius;
    char s[257];
    char *p;
    N = 0;

    do {
      p = fgets(s, 256, f);
      strcpy(atom, "      ");
      strcpy(cchain, "  ");
      strcpy(res, "    ");
      strcpy(resn, "    ");
      strcpy(at, "     ");      
      strcpy(anum, "     ");
      strcpy(none, "    ");
      strcpy(segname, "          ");
      sscanf(s, "%6c%5c%5c%4c%2c%4c%4c%8f%8f%8f%6f%6f%10c", atom, anum, at, res, cchain, resn, none, &x, &y, &z, &radius, &charge, segname);
      if (strcmp(atom, "ATOM  ") == 0) {
      atoms[N].x = x;
      atoms[N].y = y;
      atoms[N].z = z;
      atoms[N].charge = charge;
      atoms[N].radius = radius;
      char *chain = strstr(segname, "DNA");
      atoms[N].chain = chain[3];
      N++;
//      if ((strstr(segname, "DNAC") != NULL) || (strstr(segname, "DNAD") != NULL)) {
//  y += 25.0;
//}
//      fprintf(stdout, "%6s%5s%5s%4s%2s%4s%4s%8.3f%8.3f%8.3f%6.2f%6.2f%10s\n", atom, anum, at, res, cchain, resn, none, x, y, z, radius, charge, segname);
      }

    } while ((strcmp(atom, "ATOM  ") == 0) && (p != NULL));
    fclose(f);
//    for (int i = 0; i < N; i++) {
//      printf("%lf %lf %lf , %lf %lf, %c\n", atoms[i].x, atoms[i].y, atoms[i].z, atoms[i].radius, atoms[i].charge, atoms[i].chain);
//    }
//    printf("%d atoms in system\n", N);
   return atoms;
}


