#ifndef _ENERGY_H
#define _ENERGY_H

#include "../input/input.h"


// K_ES converts electrostaic energy in J to k_B*T for T = 300 K, 
// which could then be scaled by a "beta", relative to T = 300 K
#define K_ES 5.57e2

#define DIELECTRIC 78.3

// 1 radian = 57.29578 degrees
#define RADIANS_TO_DEGREES 57.2957795
#define DEGREES_TO_RADIANS 0.0174532952

void rescalebonds(system_type *s);
double calculateESenergy(system_type *s);

double calculatesystemenergy(system_type *s);

double calculatepolymerenergy(system_type *s);

double calculateenergy(system_type *s);

#endif

