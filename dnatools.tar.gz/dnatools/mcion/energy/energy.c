#include <stdio.h>
#include <math.h>
#include "energy.h"


// calculate the electrostatic energy of the system
double calculateESenergy(system_type *s) {

	double E = 0.0;
	double d;

	double K = 0.329*sqrt(s->salt);

	float ix, iy, iz, jx, jy, jz, xx, yy, zz;
		
	for (int i = 0; i < s->Nions; i++) {
		for (int j = i+1; j < s->Nions; j++) {
			if (s->boxtype == 1) {
			ix = s->ions[i].x;
			iy = s->ions[i].y;
			iz = s->ions[i].z;
			jx = s->ions[j].x;
			jy = s->ions[j].y;
			jz = s->ions[j].z;
			d = sqrt((ix-jx)*(ix-jx) + (iy-jy)*(iy-jy) + (iz-jz)*(iz-jz));
			if (d < s->ions[i].r + s->ions[j].r) {
				return 1e10;
			}
			E += (double)(s->ions[i].charge * s->ions[j].charge) * exp(-K*d) / d;
			}
			if (s->boxtype == 2) {
							xx = fabsf(s->ions[i].x - s->ions[j].x);
	                        yy = fabsf(s->ions[i].y - s->ions[j].y);
	                        zz = fabsf(s->ions[i].z - s->ions[j].z);
							if (xx > s->cell_x/2.0) xx = s->cell_x - xx;
	                        if (yy > s->cell_y/2.0) yy = s->cell_y - yy;
	                        if (zz > s->cell_z/2.0) zz = s->cell_z - zz;
							d = sqrt(xx*xx+yy*yy+zz*zz);
							if (d < s->ions[i].r + s->ions[j].r) {
								return 1e10;
							}
	                        E += (double)(s->ions[i].charge * s->ions[j].charge) * exp(-K*d) / d;
			}
		}
	}
	
	
	for (int i = 0; i < s->Natoms; i++) {
		for (int j = 0; j < s->Nions; j++) {
			if (s->boxtype == 1) {
			jx = s->ions[j].x;
			jy = s->ions[j].y;
			jz = s->ions[j].z;
			ix = s->atoms[i].x;
			iy = s->atoms[i].y;
			iz = s->atoms[i].z;
			d = sqrt((ix-jx)*(ix-jx) + (iy-jy)*(iy-jy) + (iz-jz)*(iz-jz));
			if (d < (s->atoms[i].radius + s->ions[j].r)) {
				return 1e10;
			}
			E += (double)(s->atoms[i].charge * s->ions[j].charge) * exp(-K*d) / d;
			}
			if (s->boxtype == 2) {
			
                     xx = fabsf(s->atoms[i].x - s->ions[j].x);
                     yy = fabsf(s->atoms[i].y - s->ions[j].y);
                     zz = fabsf(s->atoms[i].z - s->ions[j].z);
                     if (xx > s->cell_x/2.0) xx = s->cell_x - xx;
                     if (yy > s->cell_y/2.0) yy = s->cell_y - yy;
                     if (zz > s->cell_z/2.0) zz = s->cell_z - zz;
                     d = sqrt(xx*xx+yy*yy+zz*zz);
						if (d < s->atoms[i].radius + s->ions[j].r) {
							return 1e10;
						}
                     E += (double)(s->atoms[i].charge * s->ions[j].charge) * exp(-K*d) / d;
                                
			}
		}
	}
	return K_ES * E / DIELECTRIC;
	
}


double calculatesystemenergy(system_type *s) {

	double E = 0.0;
	double d;

	double K = 0.329*sqrt(s->salt);

	float ix, iy, iz, jx, jy, jz, xx, yy, zz;
			
	
	for (int i = 0; i < s->Natoms; i++) {
		for (int j = 0; j < s->Nions; j++) {
			if (s->boxtype == 1) {
			jx = s->ions[j].x;
			jy = s->ions[j].y;
			jz = s->ions[j].z;
			ix = s->atoms[i].x;
			iy = s->atoms[i].y;
			iz = s->atoms[i].z;
			d = sqrt((ix-jx)*(ix-jx) + (iy-jy)*(iy-jy) + (iz-jz)*(iz-jz));
			if (d < (s->atoms[i].radius + s->ions[j].r)) {
				return 1e10;
			}
			E += (double)(s->atoms[i].charge * s->ions[j].charge) * exp(-K*d) / d;
			}
			if (s->boxtype == 2) {
			
                     xx = fabsf(s->atoms[i].x - s->ions[j].x);
                     yy = fabsf(s->atoms[i].y - s->ions[j].y);
                     zz = fabsf(s->atoms[i].z - s->ions[j].z);
                     if (xx > s->cell_x/2.0) xx = s->cell_x - xx;
                     if (yy > s->cell_y/2.0) yy = s->cell_y - yy;
                     if (zz > s->cell_z/2.0) zz = s->cell_z - zz;
                     d = sqrt(xx*xx+yy*yy+zz*zz);
						if (d < s->atoms[i].radius + s->ions[j].r) {
							return 1e10;
						}
                     E += (double)(s->atoms[i].charge * s->ions[j].charge) * exp(-K*d) / d;
                                
			}
		}
	}
	return K_ES * E / DIELECTRIC;
	
}


double calculatepolymerenergy(system_type *s) {
	return s->dna.calculate_elenergy();	
}


double calculateenergy(system_type *s) {
//	printf("%lf %lf\n", calculateESenergy(s), calculatepolymerenergy(s));
	return calculateESenergy(s);
}
