char inputfile[128];
char savefile[128];
long int Neq;
int calcP;
int usevis;

unsigned short key[3];

#include "jsocket/jsocket.h"

float *add_phosphates(matrix *v, int nsteps) {
	float *s = new float[9*(nsteps+1)];
	matrix temp = identity(4);
	matrix M;
	for (int i = nsteps/2; i < nsteps; i++) {
		M = temp;
		s[9*i] = temp(1,4);
		s[9*i+1] = temp(2,4);
		s[9*i+2] = temp(3,4);
	    s[9*i+3] = M(1,4)-3.0*M(1,1)+8.9*M(1,2)-0.4*M(1,3);
	    s[9*i+4] = M(2,4)-3.0*M(2,1)+8.9*M(2,2)-0.4*M(2,3);
	    s[9*i+5] = M(3,4)-3.0*M(3,1)+8.9*M(3,2)-0.4*M(3,3);
	    s[9*i+6] = M(1,4)-3.0*M(1,1)-8.9*M(1,2)+0.4*M(1,3);
	    s[9*i+7] = M(2,4)-3.0*M(2,1)-8.9*M(2,2)+0.4*M(2,3);
	    s[9*i+8] = M(3,4)-3.0*M(3,1)-8.9*M(3,2)+0.4*M(3,3);
		temp = temp*calculateW(v[i]);
	}

	M = temp;
	s[9*nsteps] = temp(1,4);
	s[9*nsteps+1] = temp(2,4);
	s[9*nsteps+2] = temp(3,4);
    s[9*nsteps+3] = M(1,4)-3.0*M(1,1)+8.9*M(1,2)-0.4*M(1,3);
    s[9*nsteps+4] = M(2,4)-3.0*M(2,1)+8.9*M(2,2)-0.4*M(2,3);
    s[9*nsteps+5] = M(3,4)-3.0*M(3,1)+8.9*M(3,2)-0.4*M(3,3);
    s[9*nsteps+6] = M(1,4)-3.0*M(1,1)-8.9*M(1,2)+0.4*M(1,3);
    s[9*nsteps+7] = M(2,4)-3.0*M(2,1)-8.9*M(2,2)+0.4*M(2,3);
    s[9*nsteps+8] = M(3,4)-3.0*M(3,1)-8.9*M(3,2)+0.4*M(3,3);

	temp = identity(4);
	for (int i = nsteps/2-1; i >= 0; i--) {
		temp = temp*invert(calculateW(v[i]));
		M = temp;
	    s[9*i+3] = M(1,4)-3.0*M(1,1)+8.9*M(1,2)-0.4*M(1,3);
	    s[9*i+4] = M(2,4)-3.0*M(2,1)+8.9*M(2,2)-0.4*M(2,3);
	    s[9*i+5] = M(3,4)-3.0*M(3,1)+8.9*M(3,2)-0.4*M(3,3);
	    s[9*i+6] = M(1,4)-3.0*M(1,1)-8.9*M(1,2)+0.4*M(1,3);
	    s[9*i+7] = M(2,4)-3.0*M(2,1)-8.9*M(2,2)+0.4*M(2,3);
	    s[9*i+8] = M(3,4)-3.0*M(3,1)-8.9*M(3,2)+0.4*M(3,3);

		s[9*i] = M(1,4);
		s[9*i+1] = M(2,4);
		s[9*i+2] = M(3,4);
	}
	return s;
}


void *runvisualization(void *x) {
	system_type *s = (system_type *)x;

	double *cell = new double[3];
	cell[0] = 2000.0;
	cell[1] = 2000.0;
	cell[2] = 2000.0;
	int size = s->Natoms + s->Nions;
	int *indices = new int[size];
	for (int i = 0; i < s->Natoms; i++) {
		indices[i] = 0;
	}
	int color = 1;
	int index = s->Natoms;
	indices[index] = color;
	for (int i = 1; i < s->Nions; i++) {
		if (s->ions[i].charge != s->ions[i-1].charge) color++;
		indices[index+i] = color;
	}
	double *coords = new double[3*(s->Natoms+s->Nions)];
	int end = 0;

	sleep(2);
	while (1) {
                for (int i = 0; i < s->Natoms; i++) {
			coords[3*i] = s->atoms[i].x;
                        coords[3*i+1] = s->atoms[i].y;
                        coords[3*i+2] = s->atoms[i].z;
		}
		for (int i = 0; i < s->Nions; i++) {
			coords[3*s->Natoms+3*i] = s->ions[i].x;
			coords[3*s->Natoms+3*i+1] = s->ions[i].y;
			coords[3*s->Natoms+3*i+2] = s->ions[i].z;
		}
		jsocket *js = GetJSocket( "localhost", 7001, 0 );
		if (js != NULL) {
			if (WriteJSocket(js->socket, cell, 3*sizeof(double)) == -1) end = 1;
			if (WriteJSocket(js->socket, &size, sizeof(int)) == -1) end = 1;
			if (WriteJSocket(js->socket, indices, size*sizeof(int)) == -1) end = 1;
			if (WriteJSocket(js->socket, coords, 3*size*sizeof(double)) == -1) end = 1;
			FreeJSocket(js);
		}
		sleep(2);
	}


	
}

void printhelp() {
	printf("Usage: ./wlmc [extra parameters]\n\n");
	printf("-i input-file[input.dat]: specify input file\n");
	printf("-e number[1000000]: specify number of equilibration ion moves\n");
	printf("-k x y z[random]: specify random number key (three 16-bit integers)\n");
	printf("-v: turn on connection to local visualization server\n");
}

void parsecmdline(int argc, char **argv) {
	strcpy(inputfile, "input.dat");
	strcpy(savefile, "");
	usevis = 0;
	calcP = 0;
	Neq = 1000000;

	key[0] = (unsigned short)getpid();
	key[1] = (unsigned short)time(NULL);
	key[2] = (unsigned short)getuid();

	for (int i = 1; i < argc; i++) {
		if (strcmp(argv[i], "-i") == 0) {
			strcpy(inputfile, argv[i+1]);
			i++;
		} else if (strcmp(argv[i], "-k") == 0) {
			sscanf(argv[i+1], "%hu", &key[0]);
			sscanf(argv[i+2], "%hu", &key[1]);
			sscanf(argv[i+3], "%hu", &key[2]);
			i += 3;
		} else if (strcmp(argv[i], "-e") == 0) {
			sscanf(argv[i+1], "%ld", &Neq);
			i++;
		} else if (strcmp(argv[i], "-v") == 0) {
			usevis = 1;
		} else if (strcmp(argv[i], "-w") == 0) {
			strcpy(savefile, argv[i+1]);
			i++;
		} else if (strcmp(argv[i], "-P") == 0) {
			calcP = 1;
		}
		else {
			printf("bad command line parameter %s\n", argv[i]);
			printhelp();
			exit(0);
		}
	}

}


