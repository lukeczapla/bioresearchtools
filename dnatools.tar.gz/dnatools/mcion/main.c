#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <unistd.h>
#include <time.h>
#include <pthread.h>

#include "init/init.h"
#include "mc/mc.h"
#include "socket/socket.h"
#include "parameters/parameters.h"
#include "energy/energy.h"
#include "tools/tools.h"

#include "wlmc_args.c"

void randomize(unsigned short *key) {
	printf("Key = %d %d %d\n", key[0], key[1], key[2]);
	seed48(key);
}

int main(int argc, char **argv) {

	parsecmdline(argc, argv);
	
	randomize(key);
	
	system_type *s = readinput(inputfile);

	if (s->boxtype == 1) {
	float V = 4.0 * 3.1415 * powf(s->cell_radius, 3.0)/ 3.0;
	printf("box radius = %f, volume = %e cubic Ång, 1 particle = %e mM, 1 mM = %lf particles\n", s->cell_radius, V, 1660600.0 / V, (1.0 / (1660600.0 / V)));
	}
	if (s->boxtype == 2) {
	float V = s->cell_x * s->cell_y * s->cell_z;
	int mV;
        printf("molecular volume = %d cubic Ång\n", mV = gvolume(s));
	V = V - (float)mV;
	printf("volume = %e cubic Ång, 1 particle = %e mM, 1 mM = %lf particles\n", V, 1660600.0 / V, (1.0 / (1660600.0 / V)));
	}

	printf("\ninitializing system: placing the biomolecule and the ions (this could take awhile)\n");
	initsystem(s);
	
	if (usevis) {
		printf("spawning visualization client to connect to local port 7001\n");
		pthread_t thread;
    	pthread_create(&thread, NULL, runvisualization, (void *)s);
	}
	
	printf("\nrunning system simulation, %d ions, %d atoms\n", s->Nions, s->Natoms);

	runsimulation(s, Neq, savefile);
	
	delete s;
	
	return 0;
}


