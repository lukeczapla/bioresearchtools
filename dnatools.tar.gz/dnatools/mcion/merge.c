#include <stdio.h>
#include <stdlib.h>

main() {
  FILE *f1, *f2, *f3, *f4;
  f1 = fopen("data1", "r");
  f2 = fopen("data2", "r");
  f3 = fopen("data3", "r");
  f4 = fopen("data4", "r");
  double a, b, c, d;
  double e, f;
  for (int i = 0 ; i < 20000; i++) {
    e = 0.0; f = 0.0;
    fscanf(f1, "%le %le %le %le", &a, &b, &c, &d);
    e += c; f += d;
    fscanf(f2, "%le %le %le %le", &a, &b, &c, &d);
    e += c; f += d;
    fscanf(f3, "%le %le %le %le", &a, &b, &c, &d);
    e += c; f += d;
    fscanf(f4, "%le %le %le %le", &a, &b, &c, &d);
    e += c; f += d;
    printf("%lf %lf %lf %lf\n", a, b, e/4.0, f/4.0);
  }
  fclose(f1);
  fclose(f2);
  fclose(f3);
  fclose(f4);
}
