#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "init.h"
#include "../mc/mc.h"
#include "../tools/tools.h"
#include "../energy/energy.h"

// initsystem(system *s) takes the system argument and positions ions and the polymer
// the polymer is placed on z-axis with the middle monomer at (0, 0, 0)
// the ions are distributed randomly
void initsystem(system_type *s) {


	float x, y, z;
	x = 0.0;
	y = 0.0;
	z = 0.0;

	float theta;




// position ions in random locations
	float R, phi;
	int overlap = 0;
	float d;
	for (int i = 0; i < s->Nions; i++) {
	// generate a random position, where the angles are randomly distributed and p(R) ~= R^2
		do {
			if (overlap) overlap = 0;
			double pp;

			if (s->boxtype == 1) do {
			  s->ions[i].x = 2.0*(drand48()-0.5)*(s->cell_radius - s->ions[i].r);
                          s->ions[i].y = 2.0*(drand48()-0.5)*(s->cell_radius - s->ions[i].r);
                          s->ions[i].z = 2.0*(drand48()-0.5)*(s->cell_radius - s->ions[i].r);
			  pp = sqrt(s->ions[i].x*s->ions[i].x+s->ions[i].y*s->ions[i].y+s->ions[i].z*s->ions[i].z);
			} while (pp > s->cell_radius - s->ions[i].r);
			if (s->boxtype == 2) {
			  s->ions[i].x = (drand48()-0.5)*(s->cell_x);
                          s->ions[i].y = (drand48()-0.5)*(s->cell_y);
                          s->ions[i].z = (drand48()-0.5)*(s->cell_z);
			}
		// check overlap with both polymer monomer units and other ions;
			for (int j = 0; (j < s->Natoms) && (!overlap); j++) {
				d = sqrt((s->atoms[j].x-s->ions[i].x)*(s->atoms[j].x-s->ions[i].x)+(s->atoms[j].y-s->ions[i].y)*(s->atoms[j].y-s->ions[i].y)+(s->atoms[j].z-s->ions[i].z)*(s->atoms[j].z-s->ions[i].z));
				if (d < s->ions[i].r + s->atoms[j].radius) overlap = 1;
			}
			for (int j = 0; (j < i) && (!overlap); j++) {
				if (distance(s->ions[i], s->ions[j]) < s->ions[i].r + s->ions[j].r) overlap = 1;
			}
		} while (overlap);
	}

}

