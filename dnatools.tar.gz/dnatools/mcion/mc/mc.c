#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "mc.h"
#include "../energy/energy.h"
#include "../mcmoves/mcmoves.h"
#include "../tools/tools.h"

#define FOREVER 1

double dUstar;

int getbin(double r, double z, double th) {
  z += 100.0;
  int index1 = (int)(z/2.0);
//  printf("%d\n", 200*index1 + (int)(z/2.0));
  return 500*index1 + 10*(int)(r/2.0) + (int)(th / 36.0);
}

void return_r_z_theta(int v, double &theta, double &r, double &z) {
  theta = (double)(v % 10)*36.0 + 18.0;
  r = 2.0*(double)((v % 500) / 10)+1.0;
  z = 2.0*(double)(v / 500)-99.0;
}
 
void clear(data_type *d) {
	for (int i = 0; i < d->size; i++) d->Ustar[i] = 0;
}


float calculatemeasure(system_type *s, parameter_type *p) {

	float m = 0.0;

	if (p->measure == 1) {
	// end-to-end distance
		return s->dna.calculateEE();
	}
	
	if (p->measure == 2) {
	// radius of gyration
		return s->dna.calculateR();
	}
	
	if (p->measure == 3) {
		return s->dna.calculateEEp();
	}
	return m;
}

int bin(parameter_type *p, float v) {
	if ((v > p->start) && (v < p->end)) return (int)(p->Nbins * ((v - p->start) / (p->end - p->start)));
	else if (v <= p->start) return 0;
	else return (p->Nbins - 1);
}


double penalty(system_type *s, parameter_type *p, data_type *d, float v) {
	if ((v > p->start) && (v < p->end)) return (dUstar * d->Ustar[bin(p, v)]);
// if outside the bins, return "infinity", which is 1e6 here (an unreasonable penalty) :)
	return 1e8;
}


int accept(double dE) {

	// if the new energy is lower, accept
	if (dE < 0.0) return 1;
	
	// if the random number between 0 and 1 is less than exp(-dE), where dE is positive, accept
	if (drand48() < exp(-dE)) return 1;
	
	// otherwise, reject
	return 0;
	
}


void runpersistence(system_type *s, long int Neq) {

	system_type *change = copysystem(s);
	printf("equilibrating system (polymer and ions), %ld moves\n", Neq);

	double Eold = calculateenergy(s);
	double dE;
	int valid;

	matrix *W = new matrix[10];

	for (int i = 0; i < 10; i++) {
		W[i] = identity(4);
		W[i].setv(1,1, 0.0);
		W[i].setv(2,2, 0.0);
		W[i].setv(3,3, 0.0);
		W[i].setv(4,4, 0.0);
	}
	for (long int i = 0; i < Neq; i++) {
	
		if (i % (s->Nions+1) != 0) {
  			valid = moveion(change, (i % (s->Nions)) - 1, dE, s->d_max*10.0);
		} else {
			valid = movepolymer(change);
			dE = calculateenergy(change)-calculateenergy(s);
		}
		if (valid && accept(dE)) {
			copychange(s, change);
			Eold += dE;
		} else {
			copychange(change, s);
		}
	}

	int i = 0;
	long int updates = 0;
	printf("E = %lf (%lf) system = %lf\n", Eold, calculateenergy(s), calculatesystemenergy(s));

	while (1) {

	if (i % (s->Nions+1) != 0) {
		valid = moveion(change, (i % (s->Nions)) - 1, dE, s->d_max);
	} else {
		valid = movepolymer(change);
		dE = calculateenergy(change)-calculateenergy(s);
	}
	if (valid && accept(dE)) {
		if (i % (s->Nions+1) == 0) {
			for (int i = 0; i < 10; i++) W[i] = W[i]+calculateW(s->dna.v[s->dna.nsteps/2-5+i]);
			updates++;
		}
		copychange(s, change);
		Eold += dE;
	} else {
		copychange(change, s);
		if (i % (s->Nions+1) == 0) {
			for (int i = 0; i < 10; i++) W[i] = W[i]+calculateW(s->dna.v[s->dna.nsteps/2-5+i]);
			updates++;
		}
	}		
	
	i++;
	if (i == 10000) {
		i = 0;
		double avgP = 0.0;
		for (int j = 0; j < 10; j++) {
			matrix A = (1.0/(double)updates)*W[j];
			matrix PQ = identity(4);
			for (int j = 0; j < 10000; j++) PQ = PQ*A;
			avgP += PQ(3,4);
		}
		printf("P = %lf\n", avgP/10.0);
		printf("E = %lf (%lf)\n", Eold, calculateenergy(s));
	}
	}
}

// runsimulation: takes the system and the parameters and the data socket and runs the simulation
// THIS IS THE MAIN PART OF THE CODE WHERE ALL THE "FUN" HAPPENS!!!
void runsimulation(system_type *s, long int Neq, char *savefile) {

//	printf("%d\n", s->Nions);
	system_type *change = copysystem(s);
	printf("starting\n");



// request the parameters that start the simulation
	
	double Eold;
	
	float measureold, measurenew;
	
// initialize bins for computing persistence length
	
	
	int valid;
	
	copychange(change, s);
	
	double dE = 0.0;
	
	printf("calculating starting energy\n");
	Eold = calculateenergy(s);
	printf("system starting energy = %lf kT, measure = %f\n", Eold, measureold);
	
	long int Naccept = 0;
	long int Ntrial = 0;

/*
	printf("equilibrating system ions, %ld moves\n", Neq);
	for (long int i = 0; i < Neq; i++) {
	
		valid = moveion(change, (int)(s->Nions*drand48()), dE);
		
		if (valid && accept(dE)) {
			copychange(s, change);
			Eold += dE;
		} else {
			copychange(change, s);
		}
	}
*/	

	printf("equilibrating system ions, %ld moves (%d ions, %d atoms)\n", Neq, s->Nions, s->Natoms);
	for (long int i = 0; i < Neq; i++) {
	
		if (drand48() < 0.5) {
			valid = moveion(change, (int)(s->Nions*drand48()), dE, s->d_max);
		} else valid = moveion(change, (int)(s->Nions*drand48()), dE, 10.0*s->d_max);
		if (valid && accept(dE)) {
			copychange(s, change);
			Eold += dE;
		} else {
			copychange(change, s);
		}
                if ((i % 1000) == 0) {
                  Eold = calculateenergy(s);
		  printf("%d %lf\n", (int)(i / 1000), Eold);
                }
	}
	
	printf("\nsystem starting energy = %lf kT (corrected to %lf kT), measure = %f\n\n", Eold, calculateenergy(s), measureold);
	Eold = calculateenergy(s);
	writeions("ions.pdb", s);
	
	int counter = 0;
	
	if (strcmp(savefile, "") != 0) {
//		writeconfig(savefile, s, 0);
	}
	
	printf("starting simulation\n");
	
	
	while (FOREVER) {
		
		for (int i = 0; i < 10*(s->Nions); i++) {

			if (drand48() < 0.5) {
				valid = moveion(change, (int)(s->Nions*drand48()), dE, s->d_max);
			} else valid = moveion(change, (int)(s->Nions*drand48()), dE, 10.0*s->d_max);
			measurenew = measureold;

			Ntrial++;

			if (valid && accept(dE)) {
				Naccept++;
				copychange(s, change);
				Eold += dE;
			} else {
				copychange(change, s);
			}
			
		}
		
		// print the system parameters every 10000 iterations, which is 100000 pivots
		counter++;
		if (counter == 10) {
			printf("Energy = %lf (%lf) system = %lf and acceptance rate = %lf\n", Eold, calculateenergy(s), calculatesystemenergy(s), (double)Naccept/(double)Ntrial);
			counter = 0;
		}
		
		// send data "d" and get updated data "upd" from the server, clearing "d" to start over

	}
	
	delete change;

}

