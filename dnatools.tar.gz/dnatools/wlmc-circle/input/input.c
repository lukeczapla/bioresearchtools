#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "input.h"

system_type *copysystem(system_type *s) {

	system_type *x = new system_type;
	
	x->pivot_r = s->pivot_r;
	x->pivot_P = s->pivot_P;
	x->d_max = s->d_max;
	x->angle_max = s->angle_max;
	x->cell_radius = s->cell_radius;
	x->polymer_charge = s->polymer_charge;
	x->Nions = s->Nions;

	x->ions = new ion[x->Nions];
	x->dna = s->dna;

	for (int i = 0; i < s->Nions; i++) {
		x->ions[i].x = s->ions[i].x;
		x->ions[i].y = s->ions[i].y;
		x->ions[i].z = s->ions[i].z;
		x->ions[i].charge = s->ions[i].charge;
		x->ions[i].r = s->ions[i].r;
	}

	return x;
	
}

void copychange(system_type *s1, system_type *s2) {
	
	for (int i = 0; i < s1->dna.nsteps; i++) s1->dna.v[i] = s2->dna.v[i];

	for (int i = 0; i < s1->Nions; i++) {
		s1->ions[i].x = s2->ions[i].x;
		s1->ions[i].y = s2->ions[i].y;
		s1->ions[i].z = s2->ions[i].z;
	}

}


// readinput opens the input file "filename" and sets up the system parameters
// 
//
system_type *readinput(char *filename) {

// open the input file
	FILE *f = fopen(filename, "r");
	if (f == NULL) {
		printf("error opening input file %s\n", filename);
		exit(0);
	}

	system_type *s = new system_type;
	
	fscanf(f, "%f %f %f %f", &s->pivot_r, &s->pivot_P, &s->d_max, &s->angle_max);
	fscanf(f, "%f", &s->cell_radius);

	char seqfile[256];

// read the polymer chain information
	fscanf(f, "%s", seqfile);

	dna mydna(seqfile);

	s->dna.initialize_bdna(mydna);

	s->polymer_charge = -2.0 * s->dna.nsteps;
	
	printf("total charge of polymer = %f e\n", s->polymer_charge);

// read the ion information
	int n_iontypes;
	fscanf(f, "%d", &n_iontypes);
	
	ion_type *iontypes = new ion_type[n_iontypes];
	
	s->Nions = 0;
	for (int i = 0; i < n_iontypes; i++) {
		fscanf(f, "%d %f %f", &iontypes[i].N, &iontypes[i].charge, &iontypes[i].r);
		if (iontypes[i].N == 0) {
			iontypes[i].N = -(int)lroundf(s->polymer_charge / iontypes[i].charge);
			printf("%d ions with charge = %f (e) and radius = %f\n", iontypes[i].N, iontypes[i].charge, iontypes[i].r);
		} else {
			printf("%d ions with charge = %f (e) and radius = %f\n", iontypes[i].N, iontypes[i].charge, iontypes[i].r);
		}
		s->Nions += iontypes[i].N;
	}

	s->ions = new ion[s->Nions];
	int ionN = 0;
	for (int i = 0; i < n_iontypes; i++) {
		for (int j = 0; j < iontypes[i].N; j++) {
			s->ions[ionN].charge = iontypes[i].charge;
			s->ions[ionN].r = iontypes[i].r; 
			ionN++;
		}
	}

// clean stuff up and return the goods
	fclose(f);
	return s;

}


// these functions create "trajectory" files
// writeconfig either appends the new configuration to existing trajectory or writes the new system
// readconfig reads record "n" from the trajectory
/*
void writeconfig(char *filename, system_type *s, int append) {
	FILE *f;
	if (append) f = fopen(filename, "a");
	else f = fopen(filename, "w");
	if (!append) fwrite(s, 6*sizeof(float)+2*sizeof(int), 1, f);
	fwrite(s->monomers, sizeof(monomer), s->Nmonomers, f);
	fwrite(s->ions, sizeof(ion), s->Nions, f);
	fwrite(s->bonds, sizeof(bond), s->Nmonomers-1, f);
	fclose(f);
}

system_type *readconfig(char *filename, int n) {
	FILE *f = fopen(filename, "r");
	if (f == NULL) return NULL;
	system_type *s = new system_type;
	if (fread(s, 6*sizeof(float)+2*sizeof(int), 1, f) != 1) {
		fclose(f); return NULL;
	}
	s->monomers = new monomer[s->Nmonomers];
	s->ions = new ion[s->Nions];
	s->bonds = new bond[s->Nmonomers-1];
	for (int i = 0; i < n; i++) {
		if (fread(s->monomers, sizeof(monomer), s->Nmonomers, f) != (size_t)s->Nmonomers) {
			fclose(f); return NULL;
		}
		if (fread(s->ions, sizeof(ion), s->Nions, f) != (size_t)s->Nions) {
			fclose(f); return NULL;
		}
		if (fread(s->bonds, sizeof(bond), s->Nmonomers-1, f) != (size_t)s->Nmonomers-1) {
			fclose(f); return NULL;
		}
	}
	fclose(f);
	return s;
}
*/
