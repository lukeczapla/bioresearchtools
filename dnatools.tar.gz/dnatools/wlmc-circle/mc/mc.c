#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "mc.h"
#include "../energy/energy.h"
#include "../mcmoves/mcmoves.h"
#include "../tools/tools.h"

#define FOREVER 1

double dUstar;

void clear(data_type *d) {
	for (int i = 0; i < d->size; i++) d->Ustar[i] = 0;
}


float calculatemeasure(system_type *s, parameter_type *p) {

	float m = 0.0;

	if (p->measure == 1) {
	// end-to-end distance
		return s->dna.calculateEE();
	}
	
	if (p->measure == 2) {
	// radius of gyration
		return s->dna.calculateR();
	}
	
	if (p->measure == 3) {
		return s->dna.calculateEEp();
	}
	return m;
}

int bin(parameter_type *p, float v) {
	if ((v > p->start) && (v < p->end)) return (int)(p->Nbins * ((v - p->start) / (p->end - p->start)));
	else if (v <= p->start) return 0;
	else return (p->Nbins - 1);
}


double penalty(system_type *s, parameter_type *p, data_type *d, float v) {
	if ((v > p->start) && (v < p->end)) return (dUstar * d->Ustar[bin(p, v)]);
// if outside the bins, return "infinity", which is 1e6 here (an unreasonable penalty) :)
	return 1e6;
}


int accept(double dE) {

	// if the new energy is lower, accept
	if (dE < 0.0) return 1;
	
	// if the random number between 0 and 1 is less than exp(-dE), where dE is positive, accept
	if (drand48() < exp(-dE)) return 1;
	
	// otherwise, reject
	return 0;
	
}


// runsimulation: takes the system and the parameters and the data socket and runs the simulation
// THIS IS THE MAIN PART OF THE CODE WHERE ALL THE "FUN" HAPPENS!!!
void runsimulation(system_type *s, parameter_type *p, socket_type *c, long int Neq, char *savefile) {

	system_type *change = copysystem(s);
	printf("starting\n");
	data_type *d = new data_type;
	data_type *upd;
	
// request the parameters that start the simulation
	d->size = p->Nbins;
	d->dUstar = p->dUstar;
	clear(d);
	upd = requestupdateparameters(c, d);

	
	double Eold;
	double Uold, Unew;
	
	float measureold, measurenew;
	
// initialize bins for computing persistence length
	float *P = new float[p->Nbins];
	int *Pi = new int[p->Nbins];
	for (int i = 0; i < p->Nbins; i++) {
		P[i] = 0.0; Pi[i] = 0;
	}
	
	measureold = calculatemeasure(s, p);
	Uold = penalty(s, p, upd, measureold);
	Unew = Uold;
	
	int valid;
	copychange(change, s);
	
	double dE = 0.0;
	
	printf("calculating starting energy\n");
	Eold = calculateenergy(s);
	printf("system starting energy = %lf kT, measure = %f\n", Eold, measureold);
	
	long int Naccept = 0;
	long int Ntrial = 0;
	int Naccept_p = 0;
	long int Ntrial_p = 0;
	printf("equilibrating system ions, %ld moves\n", Neq);
	for (long int i = 0; i < Neq; i++) {
	
		valid = moveion(change, (int)(s->Nions*drand48()), dE);
		
		if (valid && accept(dE)) {
			copychange(s, change);
			Eold += dE;
		} else {
			copychange(change, s);
		}
	}
	
	measureold = calculatemeasure(s, p);
	measurenew = measureold;

	printf("equilibrating system (polymer and ions), %ld moves\n", Neq);
	for (long int i = 0; i < Neq; i++) {
	
		if (i % (s->Nions/5+1) != 0) {
  			valid = moveion(change, (int)(s->Nions*drand48()), dE);
			Unew = Uold;
		} else {
			valid = movepolymer(change, dE, s->angle_max, 0);
			measurenew = calculatemeasure(change, p);
			Unew = penalty(change, p, upd, measurenew);
		}
		if (valid && accept(dE + Unew - Uold)) {
			copychange(s, change);
			Eold += dE;
			Uold = Unew;
			measureold = measurenew;
		} else {
			copychange(change, s);
		}
	}

	printf("getting into a valid polymer state\n");
	
	while (measureold >= p->end) {
		for (long int i = 0; i <= 2*s->Nions; i++) {
			if (i % (s->Nions/5+1) != 0) {
				valid = moveion(change, (int)(drand48()*s->Nions), dE);
				measurenew = measureold;
				Unew = Uold;
			}
			else {
				valid = movepolymer(change, dE, s->angle_max, 0);
				measurenew = calculatemeasure(change, p);
				Unew = penalty(change, p, upd, measurenew);
			}
			if (valid && accept(dE + Unew - Uold)) {
				copychange(s, change);
				Eold += dE;
				Uold = Unew;
				measureold = measurenew;
			} else {
				copychange(change, s);
			}
		}
	}
	
	printf("\nWang-Landau system starting energy = %lf kT (corrected to %lf kT), measure = %f\n\n", Eold, calculateenergy(s), measureold);
	Eold = calculateenergy(s);
	
	int counter = 0;
	int done = 0;

	upd = requestupdateparameters(c, d);
	dUstar = upd->dUstar;
	Uold = penalty(s, p, upd, measureold);
	
	if (strcmp(savefile, "") != 0) {
//		writeconfig(savefile, s, 0);
	}
	
	int *updates = new int[p->Nbins];
	for (int i = 0; i < p->Nbins; i++) {
		updates[i] = 0;
	}
	
	double avgtwist = 0.0;
	
	printf("starting Wang-Landau simulation\n");
	
	while (FOREVER) {
		
		for (int i = 0; i < 10*(s->Nions/5+1); i++) {

			if (i % (s->Nions/5+1) == 0) {
//				printf("%ld\n", Ntrial_p);
				Ntrial_p++;
				valid = movepolymer(change, dE, s->angle_max, 0);
			//	printf("dE = %lf, valid\n", dE + Unew - Uold);
				measurenew = calculatemeasure(change, p);
				Unew = penalty(change, p, upd, measurenew);
			}
			else {
				valid = moveion(change, (int)(s->Nions * drand48()), dE);
				measurenew = measureold;
				Unew = Uold;
			}

			Ntrial++;

			if (valid && accept(dE + Unew - Uold)) {
				Naccept++;
				copychange(s, change);
				Eold += dE;
				if (i % (s->Nions/5+1) == 0) {
					Naccept_p++;
					if (!done) {
						upd->Ustar[bin(p, measurenew)]++;
						d->Ustar[bin(p, measurenew)]++;
						updates[bin(p, measurenew)]++;
						avgtwist += s->dna.v[s->dna.nsteps/2](3,1);
						Uold = Unew + dUstar;
					} else Uold = Unew;
					measureold = measurenew;
				}
			} else {
				copychange(change, s);
				if ((i % (s->Nions/5+1) == 0) && (!done)) {
					upd->Ustar[bin(p, measureold)]++;
					d->Ustar[bin(p, measureold)]++;
					updates[bin(p, measureold)]++;
					avgtwist += s->dna.v[s->dna.nsteps/2](3,1);
					Uold += dUstar;
				}
			}
			
		}
		
		// print the system parameters every 10000 iterations, which is 100000 pivots
		counter++;
		if (counter == 100) {
			printf("Measure = %f, Energy = %lf, Acceptance rate = %lf, Pivot acceptance = %f, avgtwist = %lf\n", measureold, Eold, (double)Naccept/(double)Ntrial, (double)Naccept_p/(double)Ntrial_p, avgtwist/(double)Ntrial_p);
			for (int i = 0; i < d->size; i++) {
				printf("%lf ", dUstar * upd->Ustar[i]);
			}
			printf("\n");
			if (strcmp(savefile, "") != 0) {
	//			writeconfig(savefile, s, 1);
			}
			counter = 0;
		}
		
		// send data "d" and get updated data "upd" from the server, clearing "d" to start over
		delete upd;
		upd = requestupdateparameters(c, d);
		if (upd->key != d->key) {
			printf("keys do not match! requesting parameters\n");
			p = requestreturnparameters(c);
			d->key = upd->key;
			d->size = p->Nbins;
		}
		clear(d);
		d->dUstar = upd->dUstar;
		dUstar = upd->dUstar;
		Uold = penalty(s, p, upd, measureold);

		if (upd->dUstar < p->dUstartol) {
		//	done = 1;
		}
	}
	
	delete [] P;
	delete [] Pi;
	delete change;

}

