#ifndef _MC_H
#define _MC_H

#include "../parameters/parameters.h"
#include "../input/input.h"

float calculatemeasure(system_type *s, parameter_type *p);

void runsimulation(system_type *s, parameter_type *p, socket_type *c, long int Neq, char *savefile);

#endif

