#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <unistd.h>
#include <time.h>
#include <pthread.h>

#include "init/init.h"
#include "mc/mc.h"
#include "socket/socket.h"
#include "parameters/parameters.h"
#include "energy/energy.h"
#include "tools/tools.h"

#include "wlmc_args.c"

void randomize(unsigned short *key) {
	printf("Key = %d %d %d\n", key[0], key[1], key[2]);
	seed48(key);
}

int main(int argc, char **argv) {

	parsecmdline(argc, argv);
	
	randomize(key);
	
	system_type *s = readinput(inputfile);

	float V = 4.0 * 3.1415 * powf(s->cell_radius, 3.0)/ 3.0;
	printf("box radius = %f, volume = %e cubic Ång, 1 particle = %e mM, 1 mM = %ld particles\n", s->cell_radius, V, 1660600.0 / V, (long)(1.0 / (1660600.0 / V)));

	printf("\ninitializing system: placing the polymer and the ions (this could take awhile)\n");
	initsystem(s);
	
	printf("contacting server\n");
	socket_type *connection = initsocket(host, port);
	printf("requesting parameters\n");
	parameter_type *params = requestreturnparameters(connection);
	
	if (usevis) {
		printf("spawning visualization client to connect to local port 7001\n");
		pthread_t thread;
    	pthread_create(&thread, NULL, runvisualization, (void *)s);
	}
	
	printf("\nrunning system simulation\n");
	runsimulation(s, params, connection, Neq, savefile);
	
	delete params;
	delete connection;
	delete s;
	
	return 0;
}


