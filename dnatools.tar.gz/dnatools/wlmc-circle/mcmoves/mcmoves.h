#ifndef _MCMOVES_H
#define _MCMOVES_H

#include "../input/input.h"

int moveion(system_type *s, int q, double &dE);
int movepolymer(system_type *s, double &dE, float anglemax, int detailed);

#endif

