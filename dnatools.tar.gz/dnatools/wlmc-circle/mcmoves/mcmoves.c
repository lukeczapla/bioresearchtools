#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mcmoves.h"
#include "../bdna/bdna.h"
#include "../energy/energy.h"
#include "../tools/tools.h"

int monomerlist[10000];
int ionlist[10000];
int ionlist2[10000];

void add_to_list(int ionN, int index) {
	ionlist[ionN] = index;
} 


void add_to_list2(int ionN, int index) {
	ionlist2[ionN] = index;
} 


int not_in_list2(int ionN, int index) {
	for (int i = 0; i < ionN; i++) if (ionlist2[i] == index) return 0;
	return 1;
}


int not_in_list(int ionN, int index) {
	for (int i = 0; i < ionN; i++) if (ionlist[i] == index) return 0;
	return 1;
}

void cross(double &x, double &y, double &z, double x1, double y1, double z1, double x2, double y2, double z2) {
	x = y1*z2 - z1*y2;
	y = x1*z2 - z1*x2;
	z = x1*y2 - x2*y1;
}


// clothed pivot move - remember that index (Nmonomers / 2) is fixed at the origin
int movepolymer(system_type *s, double &dE, float anglemax, int detailed) {

	dE = 0.0;

	double E = calculatepolymerenergy(s);
	double dEs = 0.0;
// pick which half of the polymer to move
	
	int m, m2;
	double d, d2;
	double x1, y1, z1, xx1, yy1, zz1;
	double vx, vy, vz, vr;

	double theta;
	
	int ionN = 0;
	int ionN2 = 0;
	int monomerN = 0;
	int added = 0;
	
//	double test = calculateESenergy(s);
	
	float *ph;
// do the second half first, since the ordering is positive

	int Ok;

	do {
		
		Ok = 1;
		m = (int)(s->dna.nsteps*drand48());
		m2 = (int)(s->dna.nsteps*drand48());

		while (abs(m2 - m) < 2) m2 ++;
		while (m2 >= s->dna.nsteps) {
			m2--; m--;
		}

		if ((m < s->dna.nsteps/2) && (s->dna.nsteps/2 <= m2)) {
			int temp = m2;
			m2 = m;
			m = temp;
			if (m - m2 < s->dna.nsteps/2) Ok = 0;
		} else if (!((m2 < s->dna.nsteps/2) && (s->dna.nsteps/2 <= m))) {
			if ((m > m2)) {
				int temp = m2;
				m2 = m;
				m = temp;
			}
		} else {
			if (m - m2 < s->dna.nsteps/2) Ok = 0;
		}
	
	} while (!Ok);
	
	if (m >= s->dna.nsteps/2) {
		for (int i = m+1; i < ((m2 > s->dna.nsteps/2) ? m2 : s->dna.nsteps); i++) monomerlist[monomerN++] = i;
		if (m2 < s->dna.nsteps/2) for (int i = 0; i < m2; i++) monomerlist[monomerN++] = i;
		for (int i = m2; i < m2+s->dna.nsteps-monomerN; i++) {
			if (i >= s->dna.nsteps) monomerlist[monomerN+i-m2] = i-s->dna.nsteps;
			else monomerlist[monomerN+i-m2] = i;
		}
	} else {
		for (int i = m+1; i < m2; i++) monomerlist[monomerN++] = i;
		for (int i = m2; i < m2+s->dna.nsteps-monomerN; i++) {
			if (i >= s->dna.nsteps) monomerlist[monomerN+i-m2] = i-s->dna.nsteps;
			else monomerlist[monomerN+i-m2] = i;
		}
	}

	ph = s->dna.add_phosphates();

		// check to see what ions we need to add to the cloth
				for (int j = 0; j < s->Nions; j++) {
					if (not_in_list(ionN, j)) {
						added = 0;
						for (int i = 0; (i < monomerN) && !added; i++) {
						if (((d2 = ((ph[9*monomerlist[i]] - s->ions[j].x) * (ph[9*monomerlist[i]] - s->ions[j].x) + (ph[9*monomerlist[i]+1] - s->ions[j].y) * (ph[9*monomerlist[i]+1] - s->ions[j].y) + 
						(ph[9*monomerlist[i]+2] - s->ions[j].z) * (ph[9*monomerlist[i]+2] - s->ions[j].z))) < s->pivot_r * s->pivot_r)) {
							added = 1;
							for (int k = monomerN; (k < s->dna.nsteps) && added; k++) {
								if (((ph[9*monomerlist[k]] - s->ions[j].x) * (ph[9*monomerlist[k]] - s->ions[j].x) + (ph[9*monomerlist[k]+1] - s->ions[j].y) * (ph[9*monomerlist[k]+1] - s->ions[j].y) + 
									(ph[9*monomerlist[k]+2] - s->ions[j].z) * (ph[9*monomerlist[k]+2] - s->ions[j].z)) < d2) added = 0;
							}
							if (added) add_to_list(ionN++, j);
						}
						}
					}
				}



//		printf("pivot %d\n", m);

		// interactions of the moved part of the chain with unmoved things
		for (int i = 0; i < monomerN; i++) {
			for (int j = monomerN; j < s->dna.nsteps; j++) {
				x1 = ph[9*monomerlist[i]+3]-ph[9*monomerlist[j]+3];
				y1 = ph[9*monomerlist[i]+4]-ph[9*monomerlist[j]+4];
				z1 = ph[9*monomerlist[i]+5]-ph[9*monomerlist[j]+5];
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= 1.0 / d;
				x1 = ph[9*monomerlist[i]+6]-ph[9*monomerlist[j]+6];
				y1 = ph[9*monomerlist[i]+7]-ph[9*monomerlist[j]+7];
				z1 = ph[9*monomerlist[i]+8]-ph[9*monomerlist[j]+8];
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= 1.0 / d;
				x1 = ph[9*monomerlist[i]+6]-ph[9*monomerlist[j]+3];
				y1 = ph[9*monomerlist[i]+7]-ph[9*monomerlist[j]+4];
				z1 = ph[9*monomerlist[i]+8]-ph[9*monomerlist[j]+5];
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= 1.0 / d;
				x1 = ph[9*monomerlist[i]+3]-ph[9*monomerlist[j]+6];
				y1 = ph[9*monomerlist[i]+4]-ph[9*monomerlist[j]+7];
				z1 = ph[9*monomerlist[i]+5]-ph[9*monomerlist[j]+8];
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= 1.0 / d;
			}
			for (int j = 0; j < s->Nions; j++) {
				if (not_in_list(ionN, j)) {
					x1 = ph[9*monomerlist[i]+3] - s->ions[j].x;
					y1 = ph[9*monomerlist[i]+4] - s->ions[j].y;
					z1 = ph[9*monomerlist[i]+5] - s->ions[j].z;
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					dEs -= (double)(-1.0*s->ions[j].charge) / d;
					x1 = ph[9*monomerlist[i]+6] - s->ions[j].x;
					y1 = ph[9*monomerlist[i]+7] - s->ions[j].y;
					z1 = ph[9*monomerlist[i]+8] - s->ions[j].z;
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					dEs -= (double)(-1.0*s->ions[j].charge) / d;
				}
			}
		}

		for (int j = 0; j < s->Nions; j++) {
			if (not_in_list(ionN, j)) {
				x1 = ph[9*m+3] - s->ions[j].x;
				y1 = ph[9*m+4] - s->ions[j].y;
				z1 = ph[9*m+5] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= (double)(-1.0*s->ions[j].charge) / d;
				x1 = ph[9*m+6] - s->ions[j].x;
				y1 = ph[9*m+7] - s->ions[j].y;
				z1 = ph[9*m+8] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= (double)(-1.0*s->ions[j].charge) / d;
				x1 = ph[9*m2+3] - s->ions[j].x;
				y1 = ph[9*m2+4] - s->ions[j].y;
				z1 = ph[9*m2+5] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= (double)(-1.0*s->ions[j].charge) / d;
				x1 = ph[9*m2+6] - s->ions[j].x;
				y1 = ph[9*m2+7] - s->ions[j].y;
				z1 = ph[9*m2+8] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= (double)(-1.0*s->ions[j].charge) / d;
			}
		}


		// interaction of pivoted phosphates with the rest of the moved chain
		for (int i = monomerN; i < s->dna.nsteps; i++) {
			if (monomerlist[i] != m) {
			x1 = ph[9*monomerlist[i]+3]-ph[9*m+3];
			y1 = ph[9*monomerlist[i]+4]-ph[9*m+4];
			z1 = ph[9*monomerlist[i]+5]-ph[9*m+5];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs -= 1.0 / d;
			x1 = ph[9*monomerlist[i]+6]-ph[9*m+6];
			y1 = ph[9*monomerlist[i]+7]-ph[9*m+7];
			z1 = ph[9*monomerlist[i]+8]-ph[9*m+8];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs -= 1.0 / d;
			x1 = ph[9*monomerlist[i]+6]-ph[9*m+3];
			y1 = ph[9*monomerlist[i]+7]-ph[9*m+4];
			z1 = ph[9*monomerlist[i]+8]-ph[9*m+5];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs -= 1.0 / d;
			x1 = ph[9*monomerlist[i]+3]-ph[9*m+6];
			y1 = ph[9*monomerlist[i]+4]-ph[9*m+7];
			z1 = ph[9*monomerlist[i]+5]-ph[9*m+8];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs -= 1.0 / d;
			}
			if (monomerlist[i] != m2) {
			x1 = ph[9*monomerlist[i]+3]-ph[9*m2+3];
			y1 = ph[9*monomerlist[i]+4]-ph[9*m2+4];
			z1 = ph[9*monomerlist[i]+5]-ph[9*m2+5];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs -= 1.0 / d;
			x1 = ph[9*monomerlist[i]+6]-ph[9*m2+6];
			y1 = ph[9*monomerlist[i]+7]-ph[9*m2+7];
			z1 = ph[9*monomerlist[i]+8]-ph[9*m2+8];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs -= 1.0 / d;
			x1 = ph[9*monomerlist[i]+6]-ph[9*m2+3];
			y1 = ph[9*monomerlist[i]+7]-ph[9*m2+4];
			z1 = ph[9*monomerlist[i]+8]-ph[9*m2+5];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs -= 1.0 / d;
			x1 = ph[9*monomerlist[i]+3]-ph[9*m2+6];
			y1 = ph[9*monomerlist[i]+4]-ph[9*m2+7];
			z1 = ph[9*monomerlist[i]+5]-ph[9*m2+8];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs -= 1.0 / d;
			}
		}
		
		
		// interaction of unmoved part of the chain with moved ions
		for (int i = monomerN; i < s->dna.nsteps; i++) {
			for (int j = 0; j < ionN; j++) {
				x1 = ph[9*monomerlist[i]+3] - s->ions[ionlist[j]].x;
				y1 = ph[9*monomerlist[i]+4] - s->ions[ionlist[j]].y;
				z1 = ph[9*monomerlist[i]+5] - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= (double)(-1.0 * s->ions[ionlist[j]].charge) / d;
				x1 = ph[9*monomerlist[i]+6] - s->ions[ionlist[j]].x;
				y1 = ph[9*monomerlist[i]+7] - s->ions[ionlist[j]].y;
				z1 = ph[9*monomerlist[i]+8] - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= (double)(-1.0 * s->ions[ionlist[j]].charge) / d;
			}
		}
		
		// interaction of unmoved ions with moved ions
		for (int i = 0; i < s->Nions; i++) {
			if (not_in_list(ionN, i)) for (int j = 0; j < ionN; j++) {
				x1 = s->ions[i].x - s->ions[ionlist[j]].x;
				y1 = s->ions[i].y - s->ions[ionlist[j]].y;
				z1 = s->ions[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs -= (double)(s->ions[i].charge * s->ions[ionlist[j]].charge) / d;			
			}
		}

		matrix M1 = calculateW(s->dna.v[m]);
		matrix W = M1;
		for (int i = 0; i < monomerN; i++) W = W * calculateW(s->dna.v[monomerlist[i]]);
		W = W * calculateW(s->dna.v[m2]);
		vx = W(1,4);
		vy = W(2,4);
		vz = W(3,4);
		vr = sqrt(vx*vx+vy*vy+vz*vz);
		vx /= vr;
		vy /= vr;
		vz /= vr;

		matrix Q = identity(4);
		theta = anglemax * 2.0 * (drand48() - 0.5) * M_PI / 180.0;
		Q.setv(1,1, vx*vx+(1.0-vx*vx)*cos(theta));
	  	Q.setv(2,1, vx*vy*(1.0-cos(theta))+vz*sin(theta));
	  	Q.setv(3,1, vx*vz*(1.0-cos(theta))-vy*sin(theta));
	  	Q.setv(1,2, vy*vx*(1.0-cos(theta))-vz*sin(theta));
	  	Q.setv(2,2, vy*vy+(1.0-vy*vy)*cos(theta));
	  	Q.setv(3,2, vy*vz*(1.0-cos(theta))+vx*sin(theta));
	  	Q.setv(1,3, vz*vx*(1.0-cos(theta))+vy*sin(theta));
	  	Q.setv(2,3, vz*vy*(1.0-cos(theta))-vx*sin(theta));
	  	Q.setv(3,3, vz*vz+(1.0-vz*vz)*cos(theta));

		W = M1;
		for (int i = 0; i < monomerN; i++) W = W * calculateW(s->dna.v[monomerlist[i]]);
		W = W * calculateW(s->dna.v[m2]);
		
		s->dna.v[m] = calculatetp(Q*M1);
//		writematrix(stdout, s->dna.v[m]);
		matrix M2 = calculateW(s->dna.v[m])*invert(M1);
		matrix Wnew = invert(Q*M1)*W;
		for (int i = 0; i < monomerN; i++) Wnew = invert(calculateW(s->dna.v[monomerlist[i]])) * Wnew;
		s->dna.v[m2] = calculatetp(Wnew);
//		printf("\n");
//		writematrix(stdout, s->dna.v[m2]);
//		printf("\n");
		W = identity(4);
		for (int i = s->dna.nsteps/2; i < (m >= s->dna.nsteps/2 ? m : m+s->dna.nsteps); i++) W = W * calculateW(s->dna.v[i % s->dna.nsteps]);
		for (int i = 0; i < ionN; i++) {
			x1 = s->ions[ionlist[i]].x - W(1,4);
			y1 = s->ions[ionlist[i]].y - W(2,4);
			z1 = s->ions[ionlist[i]].z - W(3,4);
			xx1 = x1*W(1,1)+y1*W(2,1)+z1*W(3,1);
			yy1 = x1*W(1,2)+y1*W(2,2)+z1*W(3,2);
			zz1 = x1*W(1,3)+y1*W(2,3)+z1*W(3,3);
			x1 = M2(1,1)*xx1+M2(1,2)*yy1+M2(1,3)*zz1 + M2(1,4);
			y1 = M2(2,1)*xx1+M2(2,2)*yy1+M2(2,3)*zz1 + M2(2,4);
			z1 = M2(3,1)*xx1+M2(3,2)*yy1+M2(3,3)*zz1 + M2(3,4);
			s->ions[ionlist[i]].x = W(1,1)*x1+W(1,2)*y1+W(1,3)*z1 + W(1,4);
			s->ions[ionlist[i]].y = W(2,1)*x1+W(2,2)*y1+W(2,3)*z1 + W(2,4);
			s->ions[ionlist[i]].z = W(3,1)*x1+W(3,2)*y1+W(3,3)*z1 + W(3,4);
		}
		
		
//		printf("%f %f %f", ph[9*(m-1)], ph[9*(m-1)+1], ph[9*(m-1)+2]);
//		printf("  %f %f %f", ph[9*(m+1)], ph[9*(m+1)+1], ph[9*(m+1)+2]);

		delete [] ph;
		ph = s->dna.add_phosphates();
//		printf(" : %f %f %f", ph[9*(m-1)], ph[9*(m-1)+1], ph[9*(m-1)+2]);
//		printf("  %f %f %f\n", ph[9*(m+1)], ph[9*(m+1)+1], ph[9*(m+1)+2]);
		
		if (detailed) {
		for (int j = 0; j < s->Nions; j++) {	
				if (not_in_list2(ionN2, j)) {
					added = 0;
					for (int i = 0; (i < monomerN) && !added; i++) {
					if (((d2 = ((ph[9*monomerlist[i]] - s->ions[j].x) * (ph[9*monomerlist[i]] - s->ions[j].x) + (ph[9*monomerlist[i]+1] - s->ions[j].y) * (ph[9*monomerlist[i]+1] - s->ions[j].y) + 
					(ph[9*monomerlist[i]+2] - s->ions[j].z) * (ph[9*monomerlist[i]+2] - s->ions[j].z))) < s->pivot_r * s->pivot_r)) {
						added = 1;
						for (int k = monomerN; (k < s->dna.nsteps) && added; k++) {
							if (((ph[9*monomerlist[k]] - s->ions[j].x) * (ph[9*monomerlist[k]] - s->ions[j].x) + (ph[9*monomerlist[k]+1] - s->ions[j].y) * (ph[9*monomerlist[k]+1] - s->ions[j].y) + 
								(ph[9*monomerlist[k]+2] - s->ions[j].z) * (ph[9*monomerlist[k]+2] - s->ions[j].z)) < d2) added = 0;
						}
						if (added) add_to_list2(ionN2++, j);
					}
					}
				}
		}
//		printf("%d %d\n", m, m2);
		if (ionN != ionN2) {
		//	if (ionN2 < ionN) printf("%d missing ions of %d at %d to %d, !\n", ionN - ionN2, ionN, m, m2);
			delete [] ph;
			dE = 1e100;
			return 0;
		}
	} else {
		ionN2 = ionN;
		for (int i = 0; i < ionN2; i++) add_to_list2(i, ionlist[i]);
	}

		
//
		// interactions of the moved part of the chain with unmoved things
		for (int i = 0; i < monomerN; i++) {
			for (int j = monomerN; j < s->dna.nsteps; j++) {
				if ((abs(monomerlist[i]-monomerlist[j]) > 30) && (abs(monomerlist[i]-monomerlist[j]) < s->dna.nsteps-30)) {
					x1 = ph[9*monomerlist[i]]-ph[9*monomerlist[j]];
					y1 = ph[9*monomerlist[i]+1]-ph[9*monomerlist[j]+1];
					z1 = ph[9*monomerlist[i]+2]-ph[9*monomerlist[j]+2];
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					if (d < 21.0) {
						dE = 1e20;
						delete [] ph;
						return 0;
					}
				}
				x1 = ph[9*monomerlist[i]+3]-ph[9*monomerlist[j]+3];
				y1 = ph[9*monomerlist[i]+4]-ph[9*monomerlist[j]+4];
				z1 = ph[9*monomerlist[i]+5]-ph[9*monomerlist[j]+5];
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += 1.0 / d;
				x1 = ph[9*monomerlist[i]+6]-ph[9*monomerlist[j]+6];
				y1 = ph[9*monomerlist[i]+7]-ph[9*monomerlist[j]+7];
				z1 = ph[9*monomerlist[i]+8]-ph[9*monomerlist[j]+8];
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += 1.0 / d;
				x1 = ph[9*monomerlist[i]+6]-ph[9*monomerlist[j]+3];
				y1 = ph[9*monomerlist[i]+7]-ph[9*monomerlist[j]+4];
				z1 = ph[9*monomerlist[i]+8]-ph[9*monomerlist[j]+5];
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += 1.0 / d;
				x1 = ph[9*monomerlist[i]+3]-ph[9*monomerlist[j]+6];
				y1 = ph[9*monomerlist[i]+4]-ph[9*monomerlist[j]+7];
				z1 = ph[9*monomerlist[i]+5]-ph[9*monomerlist[j]+8];
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += 1.0 / d;
			}
			for (int j = 0; j < s->Nions; j++) {
				if (not_in_list(ionN, j)) {
					x1 = ph[9*monomerlist[i]] - s->ions[j].x;
					y1 = ph[9*monomerlist[i]+1] - s->ions[j].y;
					z1 = ph[9*monomerlist[i]+2] - s->ions[j].z;
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					if (d < 10.5 + s->ions[j].r) {
						dE = 1e20;
						delete [] ph;
						return 0;
					}
					x1 = ph[9*monomerlist[i]+3] - s->ions[j].x;
					y1 = ph[9*monomerlist[i]+4] - s->ions[j].y;
					z1 = ph[9*monomerlist[i]+5] - s->ions[j].z;
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					dEs += (double)(-1.0*s->ions[j].charge) / d;
					x1 = ph[9*monomerlist[i]+6] - s->ions[j].x;
					y1 = ph[9*monomerlist[i]+7] - s->ions[j].y;
					z1 = ph[9*monomerlist[i]+8] - s->ions[j].z;
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					dEs += (double)(-1.0*s->ions[j].charge) / d;
				}
			}
		}
		
		for (int j = 0; j < s->Nions; j++) {
			if (not_in_list(ionN, j)) {
				x1 = ph[9*m] - s->ions[j].x;
				y1 = ph[9*m+1] - s->ions[j].y;
				z1 = ph[9*m+2] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				if (d < 10.5 + s->ions[j].r) {
					dE = 1e20;
					delete [] ph;
					return 0;
				}
				x1 = ph[9*m+3] - s->ions[j].x;
				y1 = ph[9*m+4] - s->ions[j].y;
				z1 = ph[9*m+5] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += (double)(-1.0*s->ions[j].charge) / d;
				x1 = ph[9*m+6] - s->ions[j].x;
				y1 = ph[9*m+7] - s->ions[j].y;
				z1 = ph[9*m+8] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += (double)(-1.0*s->ions[j].charge) / d;
				x1 = ph[9*m2] - s->ions[j].x;
				y1 = ph[9*m2+1] - s->ions[j].y;
				z1 = ph[9*m2+2] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				if (d < 10.5 + s->ions[j].r) {
					dE = 1e20;
					delete [] ph;
					return 0;
				}
				x1 = ph[9*m2+3] - s->ions[j].x;
				y1 = ph[9*m2+4] - s->ions[j].y;
				z1 = ph[9*m2+5] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += (double)(-1.0*s->ions[j].charge) / d;
				x1 = ph[9*m2+6] - s->ions[j].x;
				y1 = ph[9*m2+7] - s->ions[j].y;
				z1 = ph[9*m2+8] - s->ions[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += (double)(-1.0*s->ions[j].charge) / d;
			}
		}

		
		// interaction of unmoved part of the chain with moved ions
		for (int i = monomerN; i < s->dna.nsteps; i++) {
			for (int j = 0; j < ionN; j++) {
				x1 = ph[9*monomerlist[i]] - s->ions[ionlist2[j]].x;
				y1 = ph[9*monomerlist[i]+1] - s->ions[ionlist2[j]].y;
				z1 = ph[9*monomerlist[i]+2] - s->ions[ionlist2[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				if (d < 10.5 + s->ions[ionlist2[j]].r) {
					dE = 1e20;
					delete [] ph;
					return 0;
				}
				x1 = ph[9*monomerlist[i]+3] - s->ions[ionlist2[j]].x;
				y1 = ph[9*monomerlist[i]+4] - s->ions[ionlist2[j]].y;
				z1 = ph[9*monomerlist[i]+5] - s->ions[ionlist2[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += (double)(-1.0 * s->ions[ionlist2[j]].charge) / d;
				x1 = ph[9*monomerlist[i]+6] - s->ions[ionlist2[j]].x;
				y1 = ph[9*monomerlist[i]+7] - s->ions[ionlist2[j]].y;
				z1 = ph[9*monomerlist[i]+8] - s->ions[ionlist2[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dEs += (double)(-1.0 * s->ions[ionlist2[j]].charge) / d;
			}
		}
		
		// interaction of unmoved ions with moved ions
		for (int i = 0; i < s->Nions; i++) {
			if (not_in_list(ionN, i)) for (int j = 0; j < ionN; j++) {
				x1 = s->ions[i].x - s->ions[ionlist2[j]].x;
				y1 = s->ions[i].y - s->ions[ionlist2[j]].y;
				z1 = s->ions[i].z - s->ions[ionlist2[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				if (d < s->ions[i].r + s->ions[ionlist2[j]].r) {
					dE = 1e20;
					delete [] ph;
					return 0;
				}
				dEs += (double)(s->ions[i].charge * s->ions[ionlist2[j]].charge) / d;			
			}
		}

		// interaction of pivoted phosphates with the rest of the unmoved chain

		for (int i = monomerN; i < s->dna.nsteps; i++) {
			if (monomerlist[i] != m) {
			x1 = ph[9*monomerlist[i]+3]-ph[9*m+3];
			y1 = ph[9*monomerlist[i]+4]-ph[9*m+4];
			z1 = ph[9*monomerlist[i]+5]-ph[9*m+5];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs += 1.0 / d;
			x1 = ph[9*monomerlist[i]+6]-ph[9*m+6];
			y1 = ph[9*monomerlist[i]+7]-ph[9*m+7];
			z1 = ph[9*monomerlist[i]+8]-ph[9*m+8];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs += 1.0 / d;
			x1 = ph[9*monomerlist[i]+6]-ph[9*m+3];
			y1 = ph[9*monomerlist[i]+7]-ph[9*m+4];
			z1 = ph[9*monomerlist[i]+8]-ph[9*m+5];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs += 1.0 / d;
			x1 = ph[9*monomerlist[i]+3]-ph[9*m+6];
			y1 = ph[9*monomerlist[i]+4]-ph[9*m+7];
			z1 = ph[9*monomerlist[i]+5]-ph[9*m+8];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs += 1.0 / d;
			}
			if (monomerlist[i] != m2) {
			x1 = ph[9*monomerlist[i]+3]-ph[9*m2+3];
			y1 = ph[9*monomerlist[i]+4]-ph[9*m2+4];
			z1 = ph[9*monomerlist[i]+5]-ph[9*m2+5];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs += 1.0 / d;
			x1 = ph[9*monomerlist[i]+6]-ph[9*m2+6];
			y1 = ph[9*monomerlist[i]+7]-ph[9*m2+7];
			z1 = ph[9*monomerlist[i]+8]-ph[9*m2+8];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs += 1.0 / d;
			x1 = ph[9*monomerlist[i]+6]-ph[9*m2+3];
			y1 = ph[9*monomerlist[i]+7]-ph[9*m2+4];
			z1 = ph[9*monomerlist[i]+8]-ph[9*m2+5];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs += 1.0 / d;
			x1 = ph[9*monomerlist[i]+3]-ph[9*m2+6];
			y1 = ph[9*monomerlist[i]+4]-ph[9*m2+7];
			z1 = ph[9*monomerlist[i]+5]-ph[9*m2+8];
			d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
			dEs += 1.0 / d;
			}
		}

	
	delete [] ph;
	dE = K_ES * dEs / DIELECTRIC + calculatepolymerenergy(s) - E;
//	printf("%d %d: %lf %lf\n", m, m2, K_ES*dEs/DIELECTRIC, calculatepolymerenergy(s)-E);
	
	return 1;

}


// displace an ion
int moveion(system_type *s, int q, double &dE) {

//	printf("We have %d ions\n", s->Nions);
	
	float dx = s->d_max * 2.0 * (drand48() - 0.5);
	float dy = s->d_max * 2.0 * (drand48() - 0.5);
	float dz = s->d_max * 2.0 * (drand48() - 0.5);

	double d;
	
	float *dnac = s->dna.add_phosphates();
	
	dE = 0.0;
	
	for (int i = 0; i < s->Nions; i++) {
		if (i != q) {
			d = sqrt((s->ions[i].x - s->ions[q].x) * (s->ions[i].x - s->ions[q].x) + (s->ions[i].y - s->ions[q].y) * (s->ions[i].y - s->ions[q].y) + (s->ions[i].z - s->ions[q].z) * (s->ions[i].z - s->ions[q].z));
			dE -= (double)(s->ions[i].charge * s->ions[q].charge) / d;
		}
	}
	for (int i = 0; i < s->dna.nsteps; i++) {
		d = sqrt((dnac[9*i+3] - s->ions[q].x) * (dnac[9*i+3] - s->ions[q].x) + (dnac[9*i+4] - s->ions[q].y) * (dnac[9*i+4] - s->ions[q].y) + (dnac[9*i+5] - s->ions[q].z) * (dnac[9*i+5] - s->ions[q].z));
		dE -= (double)(-1.0 * s->ions[q].charge) / d;
		d = sqrt((dnac[9*i+6] - s->ions[q].x) * (dnac[9*i+6] - s->ions[q].x) + (dnac[9*i+7] - s->ions[q].y) * (dnac[9*i+7] - s->ions[q].y) + (dnac[9*i+8] - s->ions[q].z) * (dnac[9*i+8] - s->ions[q].z));
		dE -= (double)(-1.0 * s->ions[q].charge) / d;
	}

	s->ions[q].x += dx;
	s->ions[q].y += dy;
	s->ions[q].z += dz;

	if (sqrt(s->ions[q].x * s->ions[q].x + s->ions[q].y * s->ions[q].y + s->ions[q].z * s->ions[q].z) > s->cell_radius - s->ions[q].r) {
		dE = 0.0;
		delete [] dnac;
		return 0;
	}

	for (int i = 0; i < s->Nions; i++) {
		if (i != q) {
			d = sqrt((s->ions[i].x - s->ions[q].x) * (s->ions[i].x - s->ions[q].x) + (s->ions[i].y - s->ions[q].y) * (s->ions[i].y - s->ions[q].y) + (s->ions[i].z - s->ions[q].z) * (s->ions[i].z - s->ions[q].z));
			if (d < s->ions[i].r + s->ions[q].r) {
				dE = 1e100;
				delete [] dnac;
				return 0;
			}
			dE += (double)(s->ions[i].charge * s->ions[q].charge) / d;
		}
	}
	
	for (int i = 0; i < s->dna.nsteps; i++) {
		d = sqrt((dnac[9*i] - s->ions[q].x) * (dnac[9*i] - s->ions[q].x) + (dnac[9*i+1] - s->ions[q].y) * (dnac[9*i+1] - s->ions[q].y) + (dnac[9*i+2] - s->ions[q].z) * (dnac[9*i+2] - s->ions[q].z));
		if (d < 10.5 + s->ions[q].r) {
			dE = 1e100;
			delete [] dnac;
			return 0;
		}
		d = sqrt((dnac[9*i+3] - s->ions[q].x) * (dnac[9*i+3] - s->ions[q].x) + (dnac[9*i+4] - s->ions[q].y) * (dnac[9*i+4] - s->ions[q].y) + (dnac[9*i+5] - s->ions[q].z) * (dnac[9*i+5] - s->ions[q].z));
		dE += (double)(-1.0 * s->ions[q].charge) / d;
		d = sqrt((dnac[9*i+6] - s->ions[q].x) * (dnac[9*i+6] - s->ions[q].x) + (dnac[9*i+7] - s->ions[q].y) * (dnac[9*i+7] - s->ions[q].y) + (dnac[9*i+8] - s->ions[q].z) * (dnac[9*i+8] - s->ions[q].z));
		dE += (double)(-1.0 * s->ions[q].charge) / d;
	}
	
	dE = K_ES * dE / DIELECTRIC;
	
	delete [] dnac;

	return 1;

}


