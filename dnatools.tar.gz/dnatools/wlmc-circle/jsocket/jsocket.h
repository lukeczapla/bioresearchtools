#ifndef JSOCKET_INCLUDED

	#include <sys/socket.h>
	#include <sys/select.h>
	#include <sys/types.h>
	#include <netinet/in.h>
	#include <netdb.h>
	#include <arpa/inet.h>

	#include <stdio.h>
	#include <unistd.h>
	#include <stdlib.h>
	#include <string.h>
	#include <errno.h>
	
	typedef struct
	{
		int socket;
		struct addrinfo * ai;
	} jsocket;

	jsocket * GetJSocket( char * address, int port, int bind_socket );
	void FreeJSocket( jsocket * js );
	
	/*
		If we have a bound socket, this will listen for incoming connections for the specified time period.
		It will immediately return the socket descriptor where a connection occurs, and will return 0 where
		no connections occurred in the waiting period. Errors return -1.
	*/
	int ListenJSocket( jsocket * js, struct sockaddr_storage * s_in, socklen_t * s_len, int secs, int musecs );
	
	/*
		Read and write to a socket; these routines will correctly handle large buffers!
	*/
	int ReadJSocket( int socket, void * buf, int nbytes );
	int WriteJSocket( int socket, void * buf, int nbytes );

	/*
		Return some info on the socket.
	*/
	int get_socketaddr_info( struct sockaddr_storage * ss, int *family, int *port, char * IP, int IP_max );
	int GetJSocketInfo( jsocket * js, int *family, int *port, char * IP, int IP_max );

	/*
		Little utility function to get the IP of the current machine. Returns IPv4 by default, but can be set to IPv6
		by changing a single line in the code.
	*/
	int GetMyIP( char * IP, int maxIP );

#define JSOCKET_INCLUDED
#endif
