#ifndef _INIT_H
#define _INIT_H

#include "../input/input.h"

void initsystem(system_type *s);

#endif

