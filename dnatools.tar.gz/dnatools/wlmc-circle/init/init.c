#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "init.h"
#include "../tools/tools.h"
#include "../energy/energy.h"

// initsystem(system *s) takes the system argument and positions ions and the polymer
// the polymer is placed on z-axis with the middle monomer at (0, 0, 0)
// the ions are distributed randomly
void initsystem(system_type *s) {


	float x, y, z;
	x = 0.0;
	y = 0.0;
	z = 0.0;

	float theta;

// position monomer units, with random bending that is very small

	s->dna.set_circle();

	float *ph = s->dna.add_phosphates();

// position ions in random locations
	float R, phi;
	int overlap = 0;
	float d;
	for (int i = 0; i < s->Nions; i++) {
	// generate a random position, where the angles are randomly distributed and p(R) ~= R^2
		do {
			if (overlap) overlap = 0;
			R = (s->cell_radius - s->ions[i].r) * sqrtf(drand48());
			phi = M_PI * drand48();
			theta = 2.0 * M_PI * drand48();
			do {
			  s->ions[i].x = R*2.0*(drand48()-0.5);
			  s->ions[i].y = R*2.0*(drand48()-0.5);
			  s->ions[i].z = R*2.0*(drand48()-0.5);
			} while (s->ions[i].x*s->ions[i].x + s->ions[i].y*s->ions[i].y + s->ions[i].z*s->ions[i].z > R*R);
		// check overlap with both polymer monomer units and other ions;
			for (int j = 0; (j < s->dna.nsteps) && (!overlap); j++) {
				d = sqrt((ph[9*j]-s->ions[i].x)*(ph[9*j]-s->ions[i].x)+(ph[9*j+1]-s->ions[i].y)*(ph[9*j+1]-s->ions[i].y)+(ph[9*j+2]-s->ions[i].z)*(ph[9*j+2]-s->ions[i].z));
				if (d < s->ions[i].r + 10.5) overlap = 1;
			}
			for (int j = 0; (j < i) && (!overlap); j++) {
				if (distance(s->ions[i], s->ions[j]) < s->ions[i].r + s->ions[j].r) overlap = 1;
			}
		} while (overlap);
	}

	delete [] ph;
	
}

