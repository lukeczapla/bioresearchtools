#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <unistd.h>
#include <time.h>
#include <pthread.h>


#include "socket/socket.h"
#include "parameters/parameters.h"
#include "pdna/pdna.h"
#include "mc/mc.h"

#include "wlmc_args.c"

void randomize(unsigned short *key) {
	printf("Key = %d %d %d\n", key[0], key[1], key[2]);
	seed48(key);
}

int main(int argc, char **argv) {

	parsecmdline(argc, argv);
	
	randomize(key);
	
	printf("\ninitializing system: placing the polymer and proteins\n");
	dna mydna(inputfile);
	pdna *b = new pdna();
	b->initialize_bdna(mydna);
	b->initialize_params(beta);
	b->init_proteins();
	
	printf("contacting server\n");
	socket_type *connection = initsocket(host, port);
	printf("requesting parameters\n");
	parameter_type *params = requestreturnparameters(connection);
	

	printf("Finding starting configuration between %f and %f\n", params->start, params->end);

	double E1, E2;

	b->generate_config();
	b->convert_steps();
	printf("%lf %lf %lf\n", b->calculate_twist_open(), b->calculate_writhe_open(), mold(b, params));

    while (((mold(b, params) < params->start) || (mold(b, params) > params->end)) && (params->measure != 3)) {
		b->move(1.0);
		if (b->dE(E1, E2) > 0.0) b->accept();
		else b->revert();
	};
		
	printf("End-to-end = %d percent\n", b->oldEE());
		
	
	printf("\nrunning system simulation\n");
	runsimulation(b, params, connection, beta, host, node, Neq, savefile, Nc);
	delete params;
	delete connection;
	delete b;
	
	return 0;
}


