#include <stdio.h>

#include "socket/socket.h"
#include "parameters/parameters.h"

int main() {
        socket_type *c = initsocket("127.0.0.1", 7002);
	force_update(c);

        return 0;
}

