#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <mpi.h>

#include "pdna/pdna.h"
#include "mc/mc.h"

#include "wlmc_args.c"

void randomize(unsigned short *key) {
	printf("Key = %d %d %d\n", key[0], key[1], key[2]);
	seed48(key);
}

int main(int argc, char **argv) {

        MPI_Init(&argc, &argv);

        int rank, size;
        MPI_Comm_rank(MPI_COMM_WORLD, &rank);
        MPI_Comm_size(MPI_COMM_WORLD, &size);


	parsecmdline(argc, argv);
	
	randomize(key);
	
	printf("\ninitializing system: placing the polymer and proteins\n");
	dna mydna(inputfile);
	pdna *b = new pdna();
	b->initialize_bdna(mydna);
	b->initialize_params(beta);
	b->init_proteins();

        printf("contacting server\n");
        socket_type *connection = initsocket(host, port);
        printf("requesting parameters\n");
        parameter_type *params = requestreturnparameters(connection);
	
	printf("Finding starting configuration between %f and %f\n", params->start, params->end);

	double E1, E2;

	b->generate_config();
	b->convert_steps();
	b->revert();
	b->placeN(2);
        b->accept();
        b->dE(E1, E2);
        printf("%lf\n", mold(b, params));

    while (((mold(b, params) < params->start) || (mold(b, params) > params->end))) {
		b->move(1.0);
		if (accept(b->dE(E1, E2))) b->accept();
		else b->revert();
	};
		
	printf("End-to-end = %d percent\n", b->oldEE());
		

	printf("\nrunning system simulation\n");
	runsimulation(b, params, connection, beta, rank, Neq, savefile, Nc);
	delete b;

        MPI_Finalize();
	
	return 0;
}


