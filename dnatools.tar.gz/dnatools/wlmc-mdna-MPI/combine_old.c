// This program will combine the data from the nodes and save the total histogram

#define NBINS 380

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
	if (argc != 3) {
		printf("format: ./combine [dna_length] [number_of_nodes]\n");
		return -1;
	}
	int nsteps,nodes;
	sscanf(argv[1], "%d", &nsteps);
	sscanf(argv[2], "%d", &nodes);

	FILE *f;
	char fname[64];
	int bin, ns;
	double avgN, avgE, dUstar; 

	int totalns[NBINS]; 
	double totalp[NBINS];
	double totalE[NBINS];
	double E[NBINS];

	sprintf(fname, "data-%dbp", nsteps);
	f = fopen(fname, "r");

	if (f == NULL) {
		printf("file not found: %s\n", fname);
		return -1;
	}

	for (int i = 0; i < NBINS; i++) {
		totalns[i] = 0;
		totalp[i] = 0.0;
		totalE[i] = 0.0;
		fscanf(f, "%d %lf\n", &bin, &E[i]);
	}
	fclose(f);

	for (int i = 0; i < nodes; i++) {
		sprintf(fname, "protein-histogram-%dbp-%d", nsteps, i);
		f = fopen(fname, "r");
		if (f == NULL) {
			printf("file not found: %s\n", fname);
			return -1;
		}
		for (int j = 0; j < NBINS; j++) {
			fscanf(f, "%d %le %le %d", &bin, &avgN, &avgE, &ns);
			if (j != bin-1) {
				printf("an error occurred\n");
				return -1;
			}
			totalE[j] += avgE*ns;
			totalns[j] += ns;
			totalp[j] += avgN*(double)ns;
		}
		fclose(f);
	}

	for (int i = 0; i < NBINS; i++) {
		printf("%d %lf %lf %lf %lf %d %lf\n", i+1, 1.0*(double)i/4.0 + 0.125, (double)nsteps*3.4*((double)i/4.0 + 0.125)/100.0, -E[i], totalp[i] / (double)totalns[i], totalns[i], totalE[i] / (double)totalns[i]);
	}

}
