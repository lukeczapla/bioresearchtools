#include "misc.h"

/*
	Convert null terminated character array into an integer. Checks for bad input string, and produces error where failed.
*/
int StringToInt( char * str, int base, char * file, int lineno )
{
	char *endptr;
	char message[1024];
	int returned;
	
	#ifdef DEBUG
		if( str == NULL ) JERROR( "NULL string passed as input" );
		if( file == NULL ) JERROR( "NULL file name passed as input" );
	#endif
	
	returned = strtol( str, &endptr, 10 );
	if( *endptr != '\0' )
	{
		sprintf( message, "Unable to convert '%s' (%s, line %d) into an integer of base %d", str, file, lineno, base );
		JERROR( message );
	}
	return returned;
}
/*
	Convert null terminated character array into a double precision floating point. Checks for bad input string, and produces error where failed.
*/
double StringToDouble( char * str, char * file, int lineno )
{
	char *endptr;
	char message[1024];
	double returned;

	#ifdef DEBUG
		if( str == NULL ) JERROR( "NULL string passed" );
		if( file == NULL ) JERROR( "NULL file name passed" );
	#endif

	returned = strtod( str, &endptr );
	if( *endptr != '\0' )
	{
		sprintf( message, "Unable to convert '%s' (%s, line %d) into a double", str, file, lineno );
		JERROR( message );
	}
	return returned;
}
/*
	Check if character 'test' is a member of "delimiters"
*/
int IsDelim( char test, char * delimiters, int ndelim )
{
	int i;

	#ifdef DEBUG
		if( delimiters == NULL ) JERROR( "NULL delimiter string passed" );
	#endif

	for( i=0; i<ndelim; i++ )
		if( test == delimiters[i] ) return 1;
	return 0;
}
/*
	Chops up "str", and stores the substrings in the array "pointers". If too many substrings are present to store in
	the "pointers" array, this routine will just do as many as possible.
	NOTE - THIS IS DESTRUCTIVE! "str" WILL BE MANGLED AS A RESULT!
*/
int TokenizeString( char * str, char * delimiters, char ** pointers, int maxptrs )
{
	int ntoks, len, ndelim, i;
	
	#ifdef DEBUG
		if( str == NULL ) JERROR( "NULL string passed" );
		if( delimiters == NULL ) JERROR( "NULL delimiters string passed" );
		if( pointers == NULL ) JERROR( "NULL pointers array passed" );
		if( maxptrs < 1 ) JERROR( "maxptrs < 1" );
	#endif

	len = strlen( str );
	ndelim = strlen( delimiters );
	
	ntoks = 0;
	i = 0; /* current string position */
	while(1)
	{
		/* skip and zero any leading delimiters - should only matter on first iteration. */
		while( IsDelim(str[i],delimiters,ndelim) && i < len ) { str[i] = '\0'; i++; }
		if( i >= len ) return ntoks;
		/* store start of string */
		pointers[ntoks] = &str[i];
		/* skip until next delimiter or end of string found */
		while( !IsDelim(str[i],delimiters,ndelim) && i < len ) { i++; }
		ntoks++;
		if( ntoks >= maxptrs ) return ntoks;
		if( i >= len ) return ntoks;
	}
}



/*
	The ran1() function from Numerical Recipes in C: The Art of Scientific Computing ( ISBN: 0-521-43108-5 ).
	Call with idum as negative number to start, then do not alter idum between calls!
*/
#define IA 16807 
#define IM 2147483647 
#define AM (1.0/IM) 
#define IQ 127773 
#define IR 2836 
#define NTAB 32 
#define NDIV (1+(IM-1)/NTAB) 
#define EPS 1.2e-7 
#define RNMX (1.0-EPS)
float ran1( long *idum )
{
	int j; 
	long k; 
	static long iy = 0; 
	static long iv[NTAB]; 
	float temp;
	
	if( *idum <= 0 || !iy )
	{
		/* initialize */
		if (-(*idum) < 1) *idum=1; /* prevent idum == 0 */
		else *idum =-(*idum);

		for( j = NTAB+7; j >= 0; j--)
		{
			/* Load the shuffle table ( after 8 warm-ups ) */
			k = (*idum) / IQ; 
			*idum = IA*(*idum-k*IQ)-IR*k; 
			if( *idum < 0 ) *idum += IM; 
			if( j < NTAB ) iv[j] = *idum; 
		} 
		iy = iv[0]; 
	}
	
	k = (*idum) / IQ; /* Start here when not initializing */
	*idum=IA*(*idum-k*IQ)-IR*k; /* Compute idum = (IA*idum) % IM without overflows by Schrage's method */
	if( *idum < 0 ) *idum += IM; 
	j = iy / NDIV; /* Will be in the range 0..NTAB-1. */
	iy = iv[j]; /* Output previously stored value and refill the shuffle table */
	iv[j] = *idum; 
	if( (temp = AM*iy) > RNMX ) return RNMX; /* Because users don’t expect end point values. */
	else return temp; 
}
#undef IA 
#undef IM
#undef AM
#undef IQ
#undef IR
#undef NTAB
#undef NDIV
#undef EPS
#undef RNMX


/*
	Selects uniformly distributed point on unit sphere using ran1() above.

		Based on Eqns. 6,7,8 from http://mathworld.wolfram.com/SpherePointPicking.html
		Note - not quite correct for open/closed limits of ranges, but hey.
*/
void UniformSpherePoint( double * rvec, long * seed )
{
	double u, theta;
	
	#ifdef DEBUG
		if( rvec == NULL ) JERROR( "NULL rvec passed" );
		if( seed == NULL ) JERROR( "NULL seed passed" );
	#endif
	
	u = (ran1(seed)-0.5) * 2.0;		/* u \elem [-1,1] */
	u = sqrt( 1 - u*u );
	theta = ran1(seed) * 2.0*M_PI;	/* theta \elem [0,2pi) */
	rvec[0] = u * cos( theta );
	rvec[1] = u * sin( theta );
	rvec[2] = u;
}
