#include "mc.h"

/*
	Return the site type ( ie. the index into the site_type array in the simulation ), given the name of the site type.
	Returns -1 where type not recognised.
*/
int GetSiteTypeFromName( MCSim * sim, char * name )
{
	int i;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( name == NULL ) JERROR( "NULL name passed" );
	#endif

	for( i=0; i<sim->n_site_templates; i++ )
		if( strcasecmp(name, sim->site_templates[i].name) == 0 ) return i;
	return -1;
}
/*
	Return the molecule type ( ie. the index into the molecule_type array in the simulation ), given the name of the molecule type.
	Returns -1 where type not recognised.
*/
int GetMoleculeTypeFromName( MCSim * sim, char * name )
{
	int i;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( name == NULL ) JERROR( "NULL name passed" );
	#endif

	for( i=0; i<sim->n_molecule_templates; i++ )
		if( strcasecmp(name, sim->molecule_templates[i].name) == 0 ) return i;
	return -1;
}


/*
	Applies minimum image convention to vector src, according to cell and PBC - where values of 1 == apply PBC,
	0 == dont apply. Other values of MIC[x] WILL BREAK!
*/
void MIC( int n, double * src, double * dst, double * cell, int * PBC )
{
	int i, j;
	double prefactors[3];
	
	#ifdef DEBUG
		if( n < 1 ) JERROR( "n < 1" );
		if( src == NULL ) JERROR( "NULL src pointer" );
		if( dst == NULL ) JERROR( "NULL dst pointer" );
		if( cell == NULL ) JERROR( "NULL cell pointer" );
		if( PBC == NULL ) JERROR( "NULL PBC pointer" );
		if( PBC[0] < 0 || PBC[0] > 1 ) JERROR( "Bad PBCx parameter; should be 0 or 1." );
		if( PBC[1] < 0 || PBC[1] > 1 ) JERROR( "Bad PBCy parameter; should be 0 or 1." );
		if( PBC[2] < 0 || PBC[2] > 1 ) JERROR( "Bad PBCz parameter; should be 0 or 1." );
	#endif

	prefactors[0] = cell[0]*PBC[0];
	prefactors[1] = cell[1]*PBC[1];
	prefactors[2] = cell[2]*PBC[2];

	j = 0;
	for( i=0; i<n; i++ )
	{
		dst[j+0] = src[j+0] - prefactors[0] * round( src[j+0]/cell[0] );
		dst[j+1] = src[j+1] - prefactors[1] * round( src[j+1]/cell[1] );
		dst[j+2] = src[j+2] - prefactors[2] * round( src[j+2]/cell[2] );
		j += 3;
	}
}

/*
	Returns r^2 between sites i and j, and the MIC vector between i and j ( in form of j_vec-i_vec ) in "dest".
*/
double GetSeparationSquaredAndVectorMIC( double * r1, double * r2, double * dest, double * cell, int * PBC )
{
	#ifdef DEBUG
		if( dest == NULL ) JERROR( "NULL dest pointer" );
		if( cell == NULL ) JERROR( "NULL cell pointer" );
		if( PBC == NULL ) JERROR( "NULL PBC pointer" );
		if( PBC[0] < 0 || PBC[0] > 1 ) JERROR( "Bad PBCx parameter; should be 0 or 1." );
		if( PBC[1] < 0 || PBC[1] > 1 ) JERROR( "Bad PBCy parameter; should be 0 or 1." );
		if( PBC[2] < 0 || PBC[2] > 1 ) JERROR( "Bad PBCz parameter; should be 0 or 1." );
	#endif

	dest[0] = r2[0] - r1[0];
	dest[1] = r2[1] - r1[1];
	dest[2] = r2[2] - r1[2];

	MIC( 1, dest, dest, cell, PBC );

	return (dest[0]*dest[0]) + (dest[1]*dest[1]) + (dest[2]*dest[2]);
}


/*
	Makes an empty sim. Easy starting point to construct your own sim structures at runtime,
	but this is not really advisable.
	
	Write an input text file instead, and only change the params you need to change at runtime.
*/
MCSim * MakeEmptySim()
{
	MCSim * sim;
	int i, j, k;
	
	sim = (MCSim *)malloc( sizeof(MCSim) );
	if( sim == NULL ) JERROR( "Unable to allocate sim structure" );

	sim->n_site_templates = 0;
	sim->n_molecule_templates = 0;
	sim->n_charged_plane_templates = 0;
	
	sim->n_sites = 0;
	sim->max_sites = 0;
	sim->site_coords = NULL;
	sim->site_template_indices = NULL;

	sim->LJ_eps_table = NULL;
	sim->LJ_sig_table = NULL;
	
	/*
		Some default parameters for the sim.
	*/
	sim->T = 298.0;
	sim->e1 = 1.0;
	sim->LJ_cut = 10.0;
	sim->LJ_corr = 1;
	sim->delta_r = 2.0;
	sim->ran1_seed = -1;
	
	sim->cell[0] = sim->cell[1] = sim->cell[2] = 10.0;
	sim->PBC[0] = sim->PBC[1] = sim->PBC[2] = 1;
	
	sim->current_step = sim->max_steps = sim->save_every = 0;
	sim->accepted = sim->rejected = 0;
	
	sim->reduced_eps = sim->reduced_sig = 1.0;
		
	/*
		wipe everything in static arrays.
	*/
	for( i=0; i<MAX_SITE_TEMPLATES; i++ )
	{
		sprintf( sim->site_templates[i].name, "site_%d", i );
		sim->site_templates[i].count = 0;
		sim->site_templates[i].q = 0.0;
		sim->site_templates[i].hard_sphere_radius = 0.0;
		sim->site_templates[i].LJ_eps = 0.0;
		sim->site_templates[i].LJ_sig = 0.0;
	}
	for( i=0; i<MAX_MOLECULE_TEMPLATES; i++ )
	{
		sprintf( sim->molecule_templates[i].name, "molecule_%d", i );
		sim->molecule_templates[i].count = 0;
		sim->molecule_templates[i].length = 1;
		sim->molecule_templates[i].site_templates[i] = i;
		sim->molecule_templates[i].n_bonds = 0;
		sim->molecule_templates[i].n_angles = 0;

		for( j=0; j<MAX_MOLECULE_SITES; j++ )
			for( k=0; k<MAX_SITE_BONDS; k++ )
				sim->molecule_templates[i].fast_bound[j][k] = -1;
	}
	for( i=0; i<MAX_CHARGEDPLANE_TEMPLATES; i++ )
	{
		sim->charged_plane_templates[i].axis = 0;
		sim->charged_plane_templates[i].pos = 0.0;
		sim->charged_plane_templates[i].sigma = 0.0;
	}
	
	return sim;
}
/*
	Allocates the arrays, sets the site type indices etc.
	VERY IMPORTANT TO CALL THIS WHERE YOU DEFINE THE SIM AT RUNTIME!
*/
void InitialiseSim( MCSim * sim, double T )
{
	int i, j, k, l;
	double q_acc;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
	#endif
	
	if( sim->site_template_indices != NULL ) free( sim->site_template_indices );
	if( sim->site_coords != NULL ) free( sim->site_coords );
	if( sim->LJ_eps_table != NULL ) free( sim->LJ_eps_table );
	if( sim->LJ_sig_table != NULL ) free( sim->LJ_sig_table );

	sim->T = T;

	/*
		Set up total site count, and individual site counts
	*/
	sim->n_sites = 0;
	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		sim->n_sites += sim->molecule_templates[i].count * sim->molecule_templates[i].length;
	}
	sim->max_sites = sim->n_sites;
	
	/*
		Allocate arrays
	*/
	sim->site_template_indices = (int *)malloc( sizeof(int)*sim->n_sites );
	if( sim->site_template_indices == NULL ) JERROR( "Unable to allocate site type array" );

	sim->site_coords = (double *)malloc( sizeof(double)*sim->n_sites*3 );
	if( sim->site_coords == NULL ) JERROR( "Unable to allocate site coord array" );
	
	sim->LJ_eps_table = (double *)malloc( sizeof(double)*sim->n_site_templates*sim->n_site_templates );
	if( sim->LJ_eps_table == NULL ) JERROR( "Unable to allocate LJ eps table" );

	sim->LJ_sig_table = (double *)malloc( sizeof(double)*sim->n_site_templates*sim->n_site_templates );
	if( sim->LJ_sig_table == NULL ) JERROR( "Unable to allocate LJ sig table" );
	
	/*
		Set up site type indices, and individual site counts
	*/
	for( i=0; i<sim->n_site_templates; i++ ) sim->site_templates[i].count = 0;
	k = 0;
	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		for( j=0; j<sim->molecule_templates[i].count; j++ )
		{
			for( l=0; l<sim->molecule_templates[i].length; l++ )
			{
				sim->site_template_indices[k] = sim->molecule_templates[i].site_templates[l];
				sim->site_templates[ sim->molecule_templates[i].site_templates[l] ].count++;
				k++;
			}
		}
	}

	/*
		Zero coords array
	*/
	for( i=0; i<sim->n_sites; i++ )
	{
		sim->site_coords[(i*3)+0] = 0.0;
		sim->site_coords[(i*3)+1] = 0.0;
		sim->site_coords[(i*3)+2] = 0.0;
	}

	/*
		Check sanity on certain parameters
	*/
	if( T < 1.0 ) printf( "*** WARNING: T is very low (%f K); this could be unphysical ***\n", T );

	for( i=0; i<sim->n_site_templates; i++ )
	{
		if( sim->site_templates[i].hard_sphere_radius > 0.0 && sim->site_templates[i].LJ_eps > 0.0 )
			printf( "*** WARNING: Both hard sphere and Lennard-Jones appears to be defined for site type %s ***\n", sim->site_templates[i].name );
	}
	if( sim->PBC[0] < 0 || sim->PBC[0] > 1 ) printf( "*** WARNING: Periodic boundry condition on x axis (%d) is suspicious. Expecting 0 or 1 ***\n", sim->PBC[0] );
	if( sim->PBC[1] < 0 || sim->PBC[1] > 1 ) printf( "*** WARNING: Periodic boundry condition on y axis (%d) is suspicious. Expecting 0 or 1 ***\n", sim->PBC[1] );
	if( sim->PBC[2] < 0 || sim->PBC[2] > 1 ) printf( "*** WARNING: Periodic boundry condition on z axis (%d) is suspicious. Expecting 0 or 1 ***\n", sim->PBC[2] );

	for( i=0; i<sim->n_site_templates; i++ )
	{
		if( sim->site_templates[i].hard_sphere_radius > sim->LJ_cut ) printf( "*** WARNING: hard sphere radius for site %s (%e) is larger than the simulation LJ cutoff (%e) ***\n", sim->site_templates[i].name, sim->site_templates[i].hard_sphere_radius, sim->LJ_cut );
	}
	
	/*
		Check the system is electroneutral, and warn if not.
	*/
	q_acc = 0.0;
	for( i=0; i<sim->n_site_templates; i++ ) q_acc += sim->site_templates[i].q*sim->site_templates[i].count;
	for( i=0; i<sim->n_charged_plane_templates; i++ )
	{
		if( sim->charged_plane_templates[i].axis == 0 ) q_acc += sim->charged_plane_templates[i].sigma*sim->cell[1]*sim->cell[2];
		else if( sim->charged_plane_templates[i].axis == 1 ) q_acc += sim->charged_plane_templates[i].sigma*sim->cell[0]*sim->cell[2];
		else q_acc += sim->charged_plane_templates[i].sigma*sim->cell[0]*sim->cell[1];
	}
	if( fabs(q_acc) > 1e-10 )
	{
		printf( "*** WARNING: system has net charge of %.2f ECU ***\n", q_acc );
		printf( "\tDiscrete charges:\n" );
		q_acc = 0.0;
		for( i=0; i<sim->n_site_templates; i++ )
		{
			printf( "\t\t%s : %.2f * %d = %.2f\n", sim->site_templates[i].name, sim->site_templates[i].q, sim->site_templates[i].count, sim->site_templates[i].q*sim->site_templates[i].count );
			q_acc += sim->site_templates[i].q*sim->site_templates[i].count;
		}
		printf( "\t\ttotal = %.2f\n", q_acc );
		q_acc = 0.0;
		printf( "\tCharged planes:\n" );
		for( i=0; i<sim->n_charged_plane_templates; i++ )
		{
			if( sim->charged_plane_templates[i].axis == 0 )
			{
				printf( "\t\taxis %d, sigma %e * %.2f * %.2f = %.2f\n", 0, sim->charged_plane_templates[i].sigma, sim->cell[1], sim->cell[2], sim->charged_plane_templates[i].sigma*sim->cell[1]*sim->cell[2] );
				q_acc += sim->charged_plane_templates[i].sigma*sim->cell[1]*sim->cell[2];
			}
			else if( sim->charged_plane_templates[i].axis == 1 )
			{
				printf( "\t\taxis %d, sigma %e * %.2f * %.2f = %.2f\n", 1, sim->charged_plane_templates[i].sigma, sim->cell[1], sim->cell[2], sim->charged_plane_templates[i].sigma*sim->cell[0]*sim->cell[2] );
				q_acc += sim->charged_plane_templates[i].sigma*sim->cell[0]*sim->cell[2];
			}
			else
			{
				printf( "\t\taxis %d, sigma %e * %.2f * %.2f = %.2f\n", 2, sim->charged_plane_templates[i].sigma, sim->cell[1], sim->cell[2], sim->charged_plane_templates[i].sigma*sim->cell[0]*sim->cell[1] );
				q_acc += sim->charged_plane_templates[i].sigma*sim->cell[0]*sim->cell[1];
			}
		}
		printf( "\t\ttotal = %.2f\n", q_acc );
	}

	/*
		Set up Lennard-Jones table for the interactions between the sites.
	*/
	RebuildLJTable( sim );
	
}
void FreeSim( MCSim * sim )
{
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
	#endif
	
	free( sim->site_coords );
	free( sim->site_template_indices );

	free( sim->LJ_eps_table );
	free( sim->LJ_sig_table );

	free( sim );
}
void AddSiteInfo( MCSim * sim, char * name, double q, double hsr, double LJ_eps, double LJ_sig )
{
	int i;
	
	i = sim->n_site_templates;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( i < 0 || i > MAX_SITE_TEMPLATES ) JERROR( "Bad index" );
	#endif
	
	strcpy( sim->site_templates[i].name, name );
	sim->site_templates[i].q = q;
	sim->site_templates[i].hard_sphere_radius = hsr;
	sim->site_templates[i].LJ_eps = LJ_eps;
	sim->site_templates[i].LJ_sig = LJ_sig;
	
	sim->n_site_templates++;
}
void AddMoleculeInfo( MCSim * sim, char * name, int count )
{
	int i;
	
	i = sim->n_molecule_templates;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( name == NULL ) JERROR( "NULL name passed" );
	#endif
	
	strcpy( sim->molecule_templates[i].name, name );
	sim->molecule_templates[i].count = count;
	sim->molecule_templates[i].length = 0;
	sim->molecule_templates[i].n_bonds = 0;
	sim->molecule_templates[i].n_angles = 0;

	sim->n_molecule_templates++;
}
void AddMoleculeInfo( MCSim * sim, char * name, int count, int length, int * sites, int n_bonds, int * bonds, int n_angles, int * angles )
{
	int i, j, k, s1, s2, s3;
	
	i = sim->n_molecule_templates;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( name == NULL ) JERROR( "NULL name passed" );
		if( length < 0 || length > MAX_MOLECULE_SITES ) JERROR( "Bad length" );
		if( i < 0 || i > MAX_MOLECULE_TEMPLATES ) JERROR( "Bad index" );
		if( n_bonds < 0 || n_bonds > MAX_MOLECULE_BONDS ) JERROR( "Bad bond number" );
		if( n_angles < 0 || n_angles > MAX_MOLECULE_ANGLES ) JERROR( "Bad angle number" );
	#endif
	
	strcpy( sim->molecule_templates[i].name, name );
	sim->molecule_templates[i].count = count;
	sim->molecule_templates[i].length = length;
	sim->molecule_templates[i].n_bonds = n_bonds;
	sim->molecule_templates[i].n_angles = n_angles;
	
	if( sites != NULL )
	{
		for( j=0; j<length; j++ ) sim->molecule_templates[i].site_templates[j] = sites[j];
	}
	
	for( j=0; j<n_bonds; j++ )
	{
		if( bonds != NULL )
		{
			s1 = bonds[(j*2)+0];
			s2 = bonds[(j*2)+1];
			
			if( s1 < 0 || s1 >= length || s2 < 0 || s2 >= length )
			{
				printf( "In molecule %s (%d), bond %d (%d -> %d)\n", name, i, j, s1, s2 );
				JERROR( "Bad bond site index" );
			}
			
			sim->molecule_templates[i].bonds[(j*2)+0] = s1;
			sim->molecule_templates[i].bonds[(j*2)+1] = s2;

			/*
				set up symmetrical fast bonding info; this allows the code to
				quickly check whether two sites are directly bound, and ignore nonbonded interactions if so.
				NOTE - this only applies to directly bound sites! It does not affect nonbonded interactions between
				site which are on the ends of an angle potential, for example, although this would be easy to add.
			*/
			k = 0;
			while( k < MAX_SITE_BONDS && sim->molecule_templates[i].fast_bound[s1][k] != -1 ) k++;
			if( k >= MAX_SITE_BONDS )
			{
				printf( "In molecule %s (%d), bond %d (%d->%d); k == %d, MAX_SITE_BONDS = %d\n", name, i, j, s1, s2, k, MAX_SITE_BONDS );
				JERROR( "MAX_SITE_BONDS is too small" );
			}
			sim->molecule_templates[i].fast_bound[s1][k] = s2;

			k = 0;
			while( k < MAX_SITE_BONDS && sim->molecule_templates[i].fast_bound[s2][k] != -1 ) k++;
			if( k >= MAX_SITE_BONDS )
			{
				printf( "In molecule %s (%d), bond %d (%d->%d); k == %d, MAX_SITE_BONDS = %d\n", name, i, j, s1, s2, k, MAX_SITE_BONDS );
				JERROR( "MAX_SITE_BONDS is too small" );
			}
			sim->molecule_templates[i].fast_bound[s2][k] = s1;
		}
		else
		{
			sim->molecule_templates[i].bonds[(j*2)+0] = 0;
			sim->molecule_templates[i].bonds[(j*2)+1] = 0;
		}
		sim->molecule_templates[i].bond_eq[j] = 0.0;
		sim->molecule_templates[i].bond_k[j] = 0.0;
		sim->molecule_templates[i].bond_rigid[j] = 0;
	}

	for( j=0; j<n_angles; j++ )
	{
		if( angles != NULL )
		{
			s1 = angles[(j*3)+0];
			s2 = angles[(j*3)+1];
			s3 = angles[(j*3)+2];
			
			if( s1 < 0 || s1 >= length || s2 < 0 || s2 >= length || s3 < 0 || s3 >= length )
			{
				printf( "In molecule %s (%d), angle %d (%d -> %d -> %d)\n", name, i, j, s1, s2, s3 );
				JERROR( "Bad angle site index" );
			}

			sim->molecule_templates[i].angles[(j*3)+0] = s1;
			sim->molecule_templates[i].angles[(j*3)+1] = s2;
			sim->molecule_templates[i].angles[(j*3)+2] = s3;
		}
		else
		{
			sim->molecule_templates[i].angles[(j*3)+0] = 0;
			sim->molecule_templates[i].angles[(j*3)+1] = 0;
			sim->molecule_templates[i].angles[(j*3)+2] = 0;
		}
		sim->molecule_templates[i].angle_eq[j] = 0.0;
		sim->molecule_templates[i].angle_k[j] = 0.0;
		sim->molecule_templates[i].angle_rigid[j] = 0;
	}
	
	sim->n_molecule_templates++;
}
void AddSiteToMolecule( MCSim * sim, char * molecule_name, char * site_name )
{
	int site_type, i, j;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( molecule_name == NULL ) JERROR( "NULL molecule name passed" );
		if( site_name == NULL ) JERROR( "NULL site name passed" );
	#endif
	
	site_type = GetSiteTypeFromName( sim, site_name );
	if( site_type == -1 )
	{
		printf( "%s(): can't find site %s\n", __func__, site_name );
		JERROR( "Unknown site type" );
	}
	
	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		if( strcasecmp( sim->molecule_templates[i].name, molecule_name ) == 0 )
		{
			j = sim->molecule_templates[i].length;
			
			if( j >= MAX_MOLECULE_SITES-1 ) JERROR( "Too many sites in molecule" );
			sim->molecule_templates[i].site_templates[j] = site_type;
			
			sim->molecule_templates[i].length++;
			return;
		}
	}
	printf( "%s(): no molecule with name matching %s found!\n", __func__, molecule_name );
	JERROR( "Molecule not found" );
}
void AddBondToMolecule( MCSim * sim, char * molecule_name, int site1, int site2, double resting_length, double k, int is_rigid )
{
	int i, type, bond;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( molecule_name == NULL ) JERROR( "NULL molecule name passed" );
		if( resting_length < 0.0 ) JERROR( "Bond resting length is < 0.0" );
		if( k < 0.0 ) JERROR( "Bond k < 0.0" );
	#endif
	
	// convert to zero based indices
	site1 -= 1;
	site2 -= 1;
	
	for( type=0; type<sim->n_molecule_templates; type++ )
	{
		if( strcasecmp( sim->molecule_templates[type].name, molecule_name ) == 0 )
		{
			bond = sim->molecule_templates[type].n_bonds;
			
			if( bond >= MAX_MOLECULE_BONDS-1 ) JERROR( "Too many bonds in molecule" );
			if( site1 < 0 || site1 >= sim->molecule_templates[type].length ) { printf( "%d\n", site1 ); JERROR( "Bad site1 index" ); }
			if( site2 < 0 || site2 >= sim->molecule_templates[type].length ) { printf( "%d\n", site2 ); JERROR( "Bad site2 index" ); }
			
			sim->molecule_templates[type].bonds[(bond*2)+0] = site1;
			sim->molecule_templates[type].bonds[(bond*2)+1] = site2;
			
			sim->molecule_templates[type].bond_eq[bond] = resting_length;
			sim->molecule_templates[type].bond_k[bond] = k;
			sim->molecule_templates[type].bond_rigid[bond] = is_rigid;
			
			sim->molecule_templates[type].n_bonds++;

			/*
				set up symmetrical fast bonding info; this allows the code to
				quickly check whether two sites are directly bound, and ignore nonbonded interactions if so.
				NOTE - this only applies to directly bound sites! It does not affect nonbonded interactions between
				site which are on the ends of an angle potential, for example, although this would be easy to add.
			*/
			i = 0;
			while( i < MAX_SITE_BONDS && sim->molecule_templates[type].fast_bound[site1][i] != -1 ) i++;
			if( i >= MAX_SITE_BONDS )
			{
				printf( "In molecule %s (%d), bond %d->%d; i == %d, MAX_SITE_BONDS = %d\n", sim->site_templates[type].name, type, site1, site2, i, MAX_SITE_BONDS );
				JERROR( "MAX_SITE_BONDS is too small" );
			}
			sim->molecule_templates[type].fast_bound[site1][i] = site2;

			i = 0;
			while( i < MAX_SITE_BONDS && sim->molecule_templates[type].fast_bound[site2][i] != -1 ) i++;
			if( i >= MAX_SITE_BONDS )
			{
				printf( "In molecule %s (%d), bond %d->%d; i == %d, MAX_SITE_BONDS = %d\n", sim->site_templates[type].name, type, site1, site2, i, MAX_SITE_BONDS );
				JERROR( "MAX_SITE_BONDS is too small" );
			}
			sim->molecule_templates[type].fast_bound[site2][i] = site1;

			return;
		}
	}
	printf( "%s(): no molecule with name matching %s found!\n", __func__, molecule_name );
	JERROR( "Molecule not found" );
}
void AddAngleToMolecule( MCSim * sim, char * molecule_name, int site1, int site2, int site3, double resting_angle, double k, int is_rigid )
{
	int i, j;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( molecule_name == NULL ) JERROR( "NULL molecule name passed" );
		if( resting_angle < 0.0 ) JERROR( "Angle resting length is < 0.0" );
		if( k < 0.0 ) JERROR( "Angle k < 0.0" );
	#endif
	
	// convert to zero based indices
	site1 -= 1;
	site2 -= 1;
	site3 -= 1;

	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		if( strcasecmp( sim->molecule_templates[i].name, molecule_name ) == 0 )
		{
			j = sim->molecule_templates[i].n_angles;
			
			if( j >= MAX_MOLECULE_BONDS-1 ) JERROR( "Too many angles in molecule" );
			if( site1 < 0 || site1 >= sim->molecule_templates[i].length ) JERROR( "Bad site1 index" );
			if( site2 < 0 || site2 >= sim->molecule_templates[i].length ) JERROR( "Bad site1 index" );
			if( site3 < 0 || site3 >= sim->molecule_templates[i].length ) JERROR( "Bad site3 index" );
			
			sim->molecule_templates[i].angles[(j*3)+0] = site1;
			sim->molecule_templates[i].angles[(j*3)+1] = site2;
			sim->molecule_templates[i].angles[(j*3)+2] = site3;
			
			sim->molecule_templates[i].angle_eq[j] = resting_angle;
			sim->molecule_templates[i].angle_k[j] = k;
			sim->molecule_templates[i].angle_rigid[j] = is_rigid;
			
			sim->molecule_templates[i].n_angles++;
			return;
		}
	}
	printf( "%s(): no molecule with name matching %s found!\n", __func__, molecule_name );
	JERROR( "Molecule not found" );
}
void AddChargedPlaneInfo( MCSim * sim, int axis, double pos, double sigma )
{
	int i;
	
	i = sim->n_charged_plane_templates;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( axis < 0 || axis >= 3 ) JERROR( "Bad axis" );
		if( i < 0 || i >= MAX_CHARGEDPLANE_TEMPLATES ) JERROR( "Bad index" );
	#endif
	
	sim->charged_plane_templates[i].axis = axis;
	sim->charged_plane_templates[i].pos = pos;
	sim->charged_plane_templates[i].sigma = sigma;
	
	sim->n_charged_plane_templates++;
}

/*
	Lorentz-Berthelot mixing rules for LJ parameters. Could replace with, eg, Kong rules as
	Delhommelle & Millie found that to be better (Mol Phys 99:8:619-625, 2001).
	
	Tabulation allows us to quickly look up the parameters for two sites without having to calculate
	them each time; this offers a significant speedup, as we don't need to evaluate an extra square root
	for every interaction pair.
	
*/
void RebuildLJTable( MCSim * sim )
{
	int i, j;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim pointer" );
	#endif

	for( i=0; i<sim->n_site_templates; i++ )
	{
		for( j=0; j<sim->n_site_templates; j++ )
		{
			sim->LJ_eps_table[ (i*sim->n_site_templates) + j ] = sqrt( sim->site_templates[i].LJ_eps * sim->site_templates[j].LJ_eps );
			sim->LJ_sig_table[ (i*sim->n_site_templates) + j ] = 0.5*( sim->site_templates[i].LJ_sig + sim->site_templates[j].LJ_sig );
			/* matrix is symmetrical, so mirror the entries */
			sim->LJ_eps_table[ (j*sim->n_site_templates) + i ] = sim->LJ_eps_table[ (i*sim->n_site_templates) + j ];
			sim->LJ_sig_table[ (j*sim->n_site_templates) + i ] = sim->LJ_sig_table[ (i*sim->n_site_templates) + j ];
		}
	}
}
/*
	Lookup functions for the Lennard-Jones table.
*/
double GetLJEpsFromTable( MCSim * sim, int type_i, int type_j )
{
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim pointer" );
		if( type_i < 0 || type_j < 0 ) JERROR( "Type index < 0" );
		if( type_i >= sim->n_site_templates || type_j >= sim->n_site_templates ) JERROR( "Type index too big" );
	#endif
	return sim->LJ_eps_table[ (type_i*sim->n_site_templates)+type_j ];
}
double GetLJSigFromTable( MCSim * sim, int type_i, int type_j )
{
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim pointer" );
		if( type_i < 0 || type_j < 0 ) JERROR( "Type index < 0" );
		if( type_i >= sim->n_site_templates || type_j >= sim->n_site_templates ) JERROR( "Type index too big" );
	#endif
	return sim->LJ_sig_table[ (type_i*sim->n_site_templates)+type_j ];
}

/*
	molecule_type is an index into the sim molecule_templates array.
	instance is the specific instance of the molecule of type molecule_type that we wish to return the index of the first site of.
	
	All provided routines ensure that molecules consist of contiguous entries in the site_template_indices[] and site_coords[] arrays.
	Many routines rely on this being the case, so do not change this ordering; all molecules of the same type are also contiguous in these arrays,
	with the site information for each following directly on from one another.
	
	With this being the case, you can easily iterate over the sim->site_coords[] and sim->site_template_indices[] arrays starting at the value returned
	by GetMoleculeStartSite() if you wish to perform an operation on all the sites in a molecule.
*/
int GetMoleculeStartSite( MCSim * sim, int molecule_type, int instance )
{
	int i, offset = 0;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim pointer" );
		if( molecule_type < 0 || molecule_type >= sim->n_molecule_templates )
		{
			printf( "%d: %d;%d\n", sim->n_sites, molecule_type, sim->n_molecule_templates );
			JERROR( "Bad molecule type" );
		}
		if( instance < 0 || (instance > 0 && instance >= sim->molecule_templates[molecule_type].count) )
		{
			printf( "%d: %d;%d (%d;%d)\n", sim->n_sites, molecule_type, sim->n_molecule_templates, instance, sim->molecule_templates[molecule_type].count );
			JERROR( "Bad molecule instance" );
		}
	#endif
	
	if( sim->molecule_templates[molecule_type].count < 1 ) return -1; // no instances of this molecule type currently in the sim!

	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		if( i == molecule_type )
		{
			offset += instance*sim->molecule_templates[i].length;
			return offset;
		}
		else offset += sim->molecule_templates[i].count*sim->molecule_templates[i].length;
	}
	return -1;
}
/*
	Sets molecule type and instance as appropriate, and return start site of the parent molecule;
	if site is the third site in the 6th instance of the 10th molecule type, this will return the
	start site of the molecule, having set *molecule_type = 9 and *molecule_instance = 5.
*/
int GetParentMolecule( MCSim * sim, int site, int *molecule_type, int *molecule_instance )
{
	int i, length, next_type_start_index, type_start_index;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim pointer" );
		if( site < 0 || site >= sim->n_sites )
		{
			printf( "%d: %d\n", site, sim->n_sites );
			JERROR( "Bad site index" );
		}
	#endif
	
	type_start_index = 0; // as first instance of first molecule type is always found at index 0!
	for( i=1; i<sim->n_molecule_templates; i++ )
	{
		next_type_start_index = GetMoleculeStartSite( sim, i, 0 ); // start index of first instance of molecule type i
		if( next_type_start_index > site ) break;
		type_start_index = next_type_start_index;
	}
	/*
		now, i-1 should be the molecule type.
		remember, we checked whether -1 < site < sim->n_sites earlier, so we know site is valid!
		we set i = 1 in the loop above; even if the loop does not execute (ie. only 1 molecule type in sim),
		we still have i=1 and so i-1 will be valid for the molecule type.
	*/
	*molecule_type = i-1;
	length = sim->molecule_templates[*molecule_type].length;
	/*
		molecule instance will be (site-start_site_previous) / sim->site_templates[*molecule_type].length
		ISO c standard rounds down for two positive integers, so no need to use floor() or anything.
	*/
	*molecule_instance = (site-type_start_index) / length;
	return type_start_index + (*molecule_instance)*length;
}
/*
	Temporarily store the coordinates of the specified site. This is useful when we're
	attempting a Monte Carlo move, and we'd like to be able to easily restore the previous
	coordinates if it's rejected.
*/
void PushSiteCoords( MCSim * sim, int site_index )
{
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "Null sim pointer" );
		if( site_index < 0 || site_index >= sim->n_sites ) JERROR( "Bad site index" );
	#endif
	
	sim->stored_coords[0] = sim->site_coords[(site_index*3)+0];
	sim->stored_coords[1] = sim->site_coords[(site_index*3)+1];
	sim->stored_coords[2] = sim->site_coords[(site_index*3)+2];
}
/*
	This restores the previously Push()'d coordinates for a site.
	NOTE - multiple Push()s will overwrite previous data; only the most recent
	Push() can be restored with Pop()! Previous data is lost!
*/
void PopSiteCoords( MCSim * sim, int site_index )
{
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "Null sim pointer" );
		if( site_index < 0 || site_index >= sim->n_sites ) JERROR( "Bad site index" );
	#endif
	
	sim->site_coords[(site_index*3)+0] = sim->stored_coords[0];
	sim->site_coords[(site_index*3)+1] = sim->stored_coords[1];
	sim->site_coords[(site_index*3)+2] = sim->stored_coords[2];
}
/*
	Similar to PushSiteCoords() but for an entire molecule.
*/
void PushMoleculeCoords( MCSim * sim, int mol_type, int mol_instance )
{
	int i, offset;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "Null sim pointer" );
		if( mol_type < 0 || mol_type >= sim->n_molecule_templates ) JERROR( "Bad molecule type" );
		if( mol_instance < 0 || mol_instance >= sim->molecule_templates[mol_type].count ) JERROR( "Bad molecule instance" );
	#endif
	
	offset = GetMoleculeStartSite( sim, mol_type, mol_instance );
	
	for( i=0; i<sim->molecule_templates[mol_type].length; i++ )
	{
		sim->stored_coords[(i*3)+0] = sim->site_coords[((i+offset)*3)+0];
		sim->stored_coords[(i*3)+1] = sim->site_coords[((i+offset)*3)+1];
		sim->stored_coords[(i*3)+2] = sim->site_coords[((i+offset)*3)+2];
	}
}
/*
	Similar to PopSiteCoords() but for an entire molecule.
	NOTE - the same caveats from PopSiteCoords() apply!
	You cannot push both a site and a molecule at the same time! Whichever is
	pushed last will overwrite some or all of the data from the previous call!
*/
void PopMoleculeCoords( MCSim * sim, int mol_type, int mol_instance )
{
	int i, offset;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "Null sim pointer" );
		if( mol_type < 0 || mol_type >= sim->n_molecule_templates ) JERROR( "Bad molecule type" );
		if( mol_instance < 0 || mol_instance >= sim->molecule_templates[mol_type].count ) JERROR( "Bad molecule instance" );
	#endif
	
	offset = GetMoleculeStartSite( sim, mol_type, mol_instance );
	
	for( i=0; i<sim->molecule_templates[mol_type].length; i++ )
	{
		sim->site_coords[((i+offset)*3)+0] = sim->stored_coords[(i*3)+0];
		sim->site_coords[((i+offset)*3)+1] = sim->stored_coords[(i*3)+1];
		sim->site_coords[((i+offset)*3)+2] = sim->stored_coords[(i*3)+2];
	}
}



/*
	Check if i and j are directly bound; relies on the correct setup of the fast_bound array,
	as performed in InitialiseSim().
	
	
	As the bonding of the sites in a molecule does not depend on the positions of the sites,
	it's innate to the defined structure, we can easily use this routine with "external" molecules
	provided we have information on their type.
		Therefore, you can pass zero as the start_index to get external site bound info. This will
	not affect dealing with the molecule that actually starts at offset zero! In this way,
	the calling convention is slightly different to the GetMoleculeEnergy() etc routines.
*/
int AreBound( MCSim * sim, int mol_type, int molecule_start_index, int i, int j )
{
	int local_i, local_j, loop, len;
	int * bonds;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "Null sim pointer" );
		if( mol_type < 0 || mol_type >= sim->n_molecule_templates ) JERROR( "Bad molecule type" );
		if( molecule_start_index < 0 || molecule_start_index >= sim->n_sites ) JERROR( "Bad molecule_start_index" );
	#endif
	
	/*
		Don't check raw site indices, as we may be using this on an external molecule,
		so site indices won't be valid!
	*/

	local_i = i - molecule_start_index;
	local_j = j - molecule_start_index;
	
	len = sim->molecule_templates[mol_type].length;
	
	if( local_i < 0 || local_i >= len ) return 0;
	if( local_j < 0 || local_j >= len ) return 0;
	
	loop = 0;
	bonds = sim->molecule_templates[mol_type].fast_bound[local_i];
	while( loop < MAX_SITE_BONDS && bonds[loop] > -1 )
	{
		if( bonds[loop] == local_j ) return 1;
		loop++;
	}
	return 0;
}







/*
	Adds a single molecule of the specified type into the MCSim.
	
	"molecule_type" is the index into sim->molecule_templates. New molecule will be added before the start of any
	previously existing molecules of this type. The internal arrays will be resized to accomodate the new molecule
	if necessary. Molecule contiguity is, as always, enforced!
*/
void AddMoleculeToSim( MCSim * sim, int molecule_type, double * coords )
{
	int i, start_site, length, reuse_arrays;
	double * new_site_coords = NULL;
	int * new_type_indices = NULL;
	int new_n_sites;
	
	/*
		Could possibly add an expansion delta which the arrays grow by where neccessary. This can slightly speed up the sim,
		but it's hardly worth it, just increase by what we actually need.
		The system will find an upper bound naturally and very quickly, and from there on reallocation should be a rare event.
		Removal of a molecule does not reallocate the arrays!
	*/
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL MCSim pointer passed" );
		if( molecule_type < 0 || sim->n_molecule_templates <= molecule_type ) JERROR( "Bad molecule type passed" );
		if( coords == NULL ) JERROR( "NULL new_coords array passed" );
	#endif

	/*
		Can we reuse the existing information arrays? Are they big enough to be able to store the existing info,
		plus the new molecule?
	*/
	length = sim->molecule_templates[molecule_type].length;
	new_n_sites = sim->n_sites+length;
	if( new_n_sites <= sim->max_sites ) reuse_arrays = 1;
	else reuse_arrays = 0;

	/*
		Determine start_site, which is where we start to insert the new molecule. It's the first entry of this molecule type, new
		molecules are always inserted at the start of the appropriate section. This allows us to use a single molecule template
		to determine all the bonds and angles etc. It's important to keep them organised as the input routines expect the sites
		to appear in the order specified by the molecule entries. If we save this sim with non-ordered info, it won't load again.
	*/
	start_site = GetMoleculeStartSite( sim, molecule_type, 0 );
	/*
		If no molecules of this type exist in the sim, we need to figure out where to start
		inserting the new molecule data!
	*/
	if( start_site < 0 )
	{
		/*
			Examine molecule types which occur before this one; if there are any instances
			present, then set the insertion place to be after the last instance of the closest
			prior molecule type.
			
			Set start_site to be zero initially, that way if we make it through the loop
			without finding any "previous" instances, we have the correct start_site - ie.
			at the very beginning!
		*/
		start_site = 0;
		for( i=molecule_type-1; i >= 0; i-- )
		{
			if( sim->molecule_templates[i].count > 0 )
			{
				start_site = GetMoleculeStartSite( sim, i, 0 ) + sim->molecule_templates[i].count * sim->molecule_templates[i].length;
				break;
			}
		}
	}
	
	/*
		If we're reusing the arrays, make the pointers to the "new arrays" simply point to the the existing arrays.
		The way the loops are organised below ensures this does not damage the existing info when we shuffle it around.
		we obviously don't need to copy the existing initial info, as it's already there.
	*/
	new_site_coords = sim->site_coords;
	new_type_indices = sim->site_template_indices;

	/*
		If we're NOT reusing the current arrays, because they are too small to hold the new information, then we need
		to allocate new arrays and initialise them with the info from the start of the old arrays.
	*/
	if( reuse_arrays == 0 )
	{
		#ifdef DEBUG
/*			printf( "Reallocating arrays; n_sites is %d, previous max_sites is %d and enw max_sites is %d\n", sim->n_sites, sim->max_sites, new_n_sites ); */
		#endif
		/*
			Don't change sim->n_sites yet, as it's used in the next loop. We should, however, change the "max_sites"
			variable to reflect the new maximum array sizes.
		*/
		sim->max_sites = new_n_sites;
		/*
			We could allocate an additional 10% over the neccessary array sizes, that way we
			avoid having to reallocate as many times, but this would be overkill; we don't
			expect to have to keep reallocating often anyway, as the system will quickly
			establish an upper limit, and then shrink and expand in those bounds. As the
			removal of molecules does not reallocate the arrays, this should introduce only
			negligible CPU and OS overhead over the course of a simulation.
		*/
		new_site_coords = (double *)malloc( sizeof(double)*3*sim->max_sites );
		if( new_site_coords == NULL ) JERROR( "Unable to allocate parallel site coords array" );
		new_type_indices = (int *)malloc( sizeof(int)*sim->max_sites );
		if( new_type_indices == NULL ) JERROR( "Unable to allocate parallel site type array" );
				
		/* Copy initial coords and site types up to start_site into the new arrays. Could replace with memcpy(). */
		for( i=0; i<start_site; i++ )
		{
			new_site_coords[(i*3) +0] = sim->site_coords[(i*3) +0];
			new_site_coords[(i*3) +1] = sim->site_coords[(i*3) +1];
			new_site_coords[(i*3) +2] = sim->site_coords[(i*3) +2];

			new_type_indices[i] = sim->site_template_indices[i];
		}
	}
	/*
		Now we copy the next slab of info into the new arrays, but leave a gap of "length" in the middle to accomodate the
		new molecule info. IMPORTANT! WE HAVE TO COPY FROM THE BACK OR WE'LL OVERWITE THE DATA AS WE GO as we might be
		reusing the original arrays - also can't use memcpy(), as if source and dest buffers overlap the behaviour is
		undefined according to c specs.
	*/
	for( i=sim->n_sites-1; i>=start_site; i-- )
	{
		new_site_coords[((i+length)*3) +0] = sim->site_coords[(i*3) +0];
		new_site_coords[((i+length)*3) +1] = sim->site_coords[(i*3) +1];
		new_site_coords[((i+length)*3) +2] = sim->site_coords[(i*3) +2];
		
		new_type_indices[i+length] = sim->site_template_indices[i];
	}
	/*
		Finally, we insert new info from "coords" and molecule type structure, and copy site type
		info from sim->molecule_templates[molecule_type]->site_templates[] to complete the new arrays. Could replace with memcpy().
	*/
	for( i=0; i<length; i++ )
	{
		new_site_coords[((start_site+i)*3) +0] = coords[(i*3) +0];
		new_site_coords[((start_site+i)*3) +1] = coords[(i*3) +1];
		new_site_coords[((start_site+i)*3) +2] = coords[(i*3) +2];
		
		new_type_indices[start_site+i] = sim->molecule_templates[molecule_type].site_templates[i];
		/* remember to update the site counts from this molecule! */
		sim->site_templates[ sim->molecule_templates[molecule_type].site_templates[i] ].count++;
	}

	/*
		If we're NOT reusing the arrays, we need to free the old ones and alter the pointers in
		the MCSim structure to point to the new arrays.
	*/
	if( reuse_arrays == 0 )
	{
		free( sim->site_coords );
		free( sim->site_template_indices );
		sim->site_coords = new_site_coords;
		sim->site_template_indices = new_type_indices;
	}
	
	/* Ensure we have the updated info regarding the number of sites and molecules! */
	sim->molecule_templates[molecule_type].count++;
	sim->n_sites = new_n_sites;
}
void RemoveMoleculeFromSim( MCSim * sim, int molecule_type, int instance )
{
	int i, start_site, length;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL MCSim pointer passed" );
		if( molecule_type < 0 || sim->n_molecule_templates <= molecule_type ) JERROR( "Bad molecule type passed" );
		if( sim->molecule_templates[molecule_type].count <= instance ) JERROR( "Instance < sim count for specified molecule" );
	#endif

	length = sim->molecule_templates[molecule_type].length;
	
	/* Get index of the first site in the molecule to remove */
	start_site = GetMoleculeStartSite( sim, molecule_type, instance );
	
	/*
		Copy all site information for the molecules following the one which we wish to remove "backwards" in the
		arrays to overwrite the selected molecule.
	*/
	for( i=start_site; i<sim->n_sites-length; i++ )
	{
		sim->site_coords[(i*3)+0] = sim->site_coords[((i+length)*3)+0];
		sim->site_coords[(i*3)+1] = sim->site_coords[((i+length)*3)+1];
		sim->site_coords[(i*3)+2] = sim->site_coords[((i+length)*3)+2];

		sim->site_template_indices[i] = sim->site_template_indices[i+length];
	}
	
	sim->molecule_templates[molecule_type].count--;
	sim->n_sites -= length;
	
	/* remember to update the site counts from this molecule! */
	for( i=0; i<sim->molecule_templates[molecule_type].length; i++ )
	{
		sim->site_templates[ sim->molecule_templates[molecule_type].site_templates[i] ].count--;
	}
}

/*
	Get the "local" coords of a specified molecule, relative to the centre of geometry.
	This is useful, as the molecule might have sites all over the place due to periodic boundaries.
	DON'T PASS DEST AS SOURCE ARRAY! Could enforce this using the c keyword "restrict", but that's only C99 and onwards.
*/
void GetMoleculeLocalCoords( MCSim * sim, int molecule_type, int molecule_instance, double * dest_coords, double * dest_COG )
{
	int i, start_site, length;
	double base[3], sep[3], COG[3];
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL MCSim pointer passed" );
		if( dest_coords == NULL ) JERROR( "NULL dest coords pointer passed" );
		if( dest_COG == NULL ) JERROR( "NULL dest COG pointer passed" );
		if( molecule_type < 0 || sim->n_molecule_templates <= molecule_type ) JERROR( "Bad molecule type passed" );
		if( sim->molecule_templates[molecule_type].count <= molecule_instance ) JERROR( "Instance < sim count for specified molecule" );
	#endif

	length = sim->molecule_templates[molecule_type].length;
	start_site = GetMoleculeStartSite( sim, molecule_type, molecule_instance );

	base[0] = sim->site_coords[(start_site*3) + 0];
	base[1] = sim->site_coords[(start_site*3) + 1];
	base[2] = sim->site_coords[(start_site*3) + 2];

	for( i=0; i<length; i++ )
	{
		sep[0] = sim->site_coords[((start_site+i)*3) + 0] - base[0];
		sep[1] = sim->site_coords[((start_site+i)*3) + 1] - base[1];
		sep[2] = sim->site_coords[((start_site+i)*3) + 2] - base[2];
		
		MIC( 1, sep, sep, sim->cell, sim->PBC );
		
		dest_coords[(i*3)+0] = sep[0];
		dest_coords[(i*3)+1] = sep[1];
		dest_coords[(i*3)+2] = sep[2];
	}
	
	/*
		At this point, we should have the molecule in local coords relative to first site.
		We now find the centre of geometry and adjust the local coords to match, as well as adjusting
		the COG from the first site, so we can wrap it appropriately.
	*/
	COG[0] = COG[1] = COG[2] = 0.0;
	for( i=0; i<length; i++ )
	{
		COG[0] += dest_coords[(i*3) +0];
		COG[1] += dest_coords[(i*3) +1];
		COG[2] += dest_coords[(i*3) +2];
	}
	COG[0] = COG[0] / length;
	COG[1] = COG[1] / length;
	COG[2] = COG[2] / length;
	
	dest_COG[0] = base[0] + COG[0];
	dest_COG[1] = base[1] + COG[1];
	dest_COG[2] = base[2] + COG[2];
	MIC( 1, dest_COG, dest_COG, sim->cell, sim->PBC );

	for( i=0; i<length; i++ )
	{
		dest_coords[(i*3) +0] -= COG[0];
		dest_coords[(i*3) +1] -= COG[1];
		dest_coords[(i*3) +2] -= COG[2];
	}
	
	/*
		Hopefully, we now have the coords in dest_coords unwrapped, and relative to the COG of the molecule.
		Also, the dest_COG array includes the COG of the molecule wrapped to the periodic boundaries.
	*/
}

/*
	Rotate a molecule around its centre of geometry on the specified axis by the specified angle.
	"axis" does not have to be normalised.
	Tested to preserve geometry for ULONG_MAX applications of a random rotation.
*/
void RotateMolecule( MCSim * sim, int molecule_type, int molecule_instance, double * axis, double theta )
{
	int i, start_site, length;
	double local_coords[3*MAX_MOLECULE_SITES], COG[3];
	double a, b, c, x, y, z, rx, ry, rz, u, v, w, u2, v2, w2, K, L, ct, st;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL MCSim pointer passed" );
		if( axis == NULL ) JERROR( "NULL axis pointer passed" );
		if( molecule_type < 0 || sim->n_molecule_templates <= molecule_type ) JERROR( "Bad molecule type passed" );
		if( sim->molecule_templates[molecule_type].count <= molecule_instance ) JERROR( "Instance < sim count for specified molecule" );
	#endif

	GetMoleculeLocalCoords( sim, molecule_type, molecule_instance, local_coords, COG );
	length = sim->molecule_templates[molecule_type].length;
	start_site = GetMoleculeStartSite( sim, molecule_type, molecule_instance );

	a = 0.0; /* axis of rotation passes through (a,b,c). Done this way to allow more sophisticated stuff at a later date. */
	b = 0.0;
	c = 0.0;
	
	ct = cos( theta );
	st = sin( theta );

	u = axis[0];
	v = axis[1];
	w = axis[2];
	u2 = u*u;
	v2 = v*v;
	w2 = w*w;
	K = u2 + v2 + w2;
	L = sqrt( K );
	
	/*
		Rotate local coords as specified, converting to global coords afterwards
	*/
	for( i=0; i<length; i++ )
	{
		x = local_coords[(i*3)+0];
		y = local_coords[(i*3)+1];
		z = local_coords[(i*3)+2];

		rx = a*(v2+w2) + u*(-b*v -c*w + u*x + v*y + w*z) + ( (x-a)*(v2+w2) + u*(b*v + c*w - v*y - w*z) ) * ct + L*(b*w - c*v - w*y + v*z)*st;
		rx = rx / K;

		ry = b*(u2+w2) + v*(-a*u -c*w + u*x + v*y + w*z) + ( (y-b)*(u2+w2) + v*(a*u + c*w - u*x - w*z) ) * ct + L*(-a*w + c*u + w*x - u*z)*st;
		ry = ry / K;

		rz = c*(u2+v2) + w*(-a*u -b*v + u*x + v*y + w*z) + ( (z-c)*(u2+v2) + w*(a*u + b*v - u*x - v*y) ) * ct + L*(a*v - b*u - v*x + u*y)*st;
		rz = rz / K;

		local_coords[(i*3)+0] = COG[0] + rx; /* local coords -> global coords */
		local_coords[(i*3)+1] = COG[1] + ry;
		local_coords[(i*3)+2] = COG[2] + rz;
	}
	/*
		Wrap new global coords, and set sim coord array to new positions.
	*/
	MIC( length, local_coords, local_coords, sim->cell, sim->PBC );
	for( i=0; i<length; i++ )
	{
		sim->site_coords[((start_site+i)*3) + 0] = local_coords[(i*3) +0];
		sim->site_coords[((start_site+i)*3) + 1] = local_coords[(i*3) +1];
		sim->site_coords[((start_site+i)*3) + 2] = local_coords[(i*3) +2];
	}
}
/*
	Simply adds to contents of "offset" to the current coords of each site in this molecule.
*/
void TranslateMolecule( MCSim * sim, int molecule_type, int molecule_instance, double * offset )
{
	int i, start_site, length;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL MCSim pointer passed" );
		if( offset == NULL ) JERROR( "NULL offset pointer passed" );
		if( molecule_type < 0 || sim->n_molecule_templates <= molecule_type ) JERROR( "Bad molecule type passed" );
		if( sim->molecule_templates[molecule_type].count <= molecule_instance ) JERROR( "Instance <= sim count for specified molecule" );
	#endif
	
	length = sim->molecule_templates[molecule_type].length;
	start_site = GetMoleculeStartSite( sim, molecule_type, molecule_instance );

	for( i=0; i<length; i++ )
	{
		sim->site_coords[((start_site+i)*3)+0] += offset[0];
		sim->site_coords[((start_site+i)*3)+1] += offset[1];
		sim->site_coords[((start_site+i)*3)+2] += offset[2];
	}
	MIC( length, &sim->site_coords[start_site*3], &sim->site_coords[start_site*3], sim->cell, sim->PBC );
}
