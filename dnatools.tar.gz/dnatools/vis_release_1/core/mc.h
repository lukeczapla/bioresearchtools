#ifndef MC_INCLUDED

	#include <string.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <math.h>
	#include <errno.h>
	#include <limits.h>

	#include "misc.h"
	#include "../util/bins.h"
	#include "../util/jsocket.h"

	/*
		Naming conventions;
		
		All #define'd values in CAPITAL LETTERS
		All typedef'd structures have ConcatinatedCapitalisedWordNames (camel case)
		All variables are lower case, but may have capital letters in appropriate places.
	*/

	#define KB 1.3806504e-23	// Boltzmann's constant
	#define NAV 6.0221415e23	// Avogadro's number
	#define R	(KB*NAV)		// Gas constant. Bracketed entire expression to avoid potential operator precedence weirdness.
	#define E0 8.85418782e-12	// Electrostatic permittivity of free space, in units of C^2/Nm^2 or F/m as F = C^2/Nm ( ie C^2/J ).
	#define E1 78.3				// Approximate relative permittivity of water at room temperature
	#define ELEM_CHARGE 1.60217646e-19	// Elementary charge unit

	#define MAX_TEMPLATE_NAMELEN 20		// max length of a site or molecule name
	#define MAX_SITE_TEMPLATES 10			// max site templates allowed in a sim
	#define MAX_SITE_BONDS 4			// max number of bonds per site
	#define MAX_MOLECULE_TEMPLATES 10		// max molecule templates in a sim
	#define MAX_MOLECULE_SITES 20		// max sites allowed in a molecule
	#define MAX_MOLECULE_BONDS 20		// max bonds allowed ""		""
	#define MAX_MOLECULE_ANGLES 20		// max angles allowed ""	""
	#define MAX_CHARGEDPLANE_TEMPLATES	10	// max charged plane templates in a sim

	#define KRONENBOURG_PORT 1664		// default port for visualiser communications
	
	#define PT_LJ		0
	#define PT_DC		1
	#define PT_BOND		2
	#define PT_ANGLE 	3
	#define MAX_PT		4
	
	/*
			A Site is the smallest entity in a simulation, and contains info on the interactions.
			It also maintains a global count of how many of these sites are present in the simulation.
	*/
	typedef struct
	{
		char name[MAX_TEMPLATE_NAMELEN];
		int count; // total number of instances of this site in the sim.
	
		double q; // charge, in elementary charge units
		double hard_sphere_radius; // where <= 0, hard sphere potential ignored.
		double LJ_eps, LJ_sig; // LJ eps and sigma, if needed. If not, set eps to zero.
	} Site;
	
	/*
			A Molecule describes the structure of a group of sites via bonds and
			angles. Molecules are the primary entity for manipulating a MC sim
			at runtime.
	*/
	typedef struct
	{
		char name[MAX_TEMPLATE_NAMELEN];
		int count;	// total number of instances of this molecule in the sim

		int length;								// length of molecule, in sites
		int site_templates[MAX_MOLECULE_SITES];		// indices into the site_templates array
	
		int n_bonds;
		int bonds[MAX_MOLECULE_BONDS*2];	// 2*n_bonds in length. [ i,j, k,l ... ] where i,j are bound sites.
		double bond_eq[MAX_MOLECULE_BONDS];	// resting lengths; absolute for rigid bonds, else energy minimum for harmonics.
		double bond_k[MAX_MOLECULE_BONDS];	// spring constants for harmonic bonds
		int bond_rigid[MAX_MOLECULE_BONDS];	// is this bond rigid?

		int n_angles;
		int angles[MAX_MOLECULE_ANGLES*3];		// 3*n_angles in length. [ i,j,k, l,m,n, ... ] where i,j,k form the angle
		double angle_eq[MAX_MOLECULE_ANGLES];	// resting angles; absolute for rigid angles, else energy minimum for harmonics.
		double angle_k[MAX_MOLECULE_ANGLES];	// spring constants for harmonic angles
		int angle_rigid[MAX_MOLECULE_ANGLES];	// is this angle rigid?
		
		int fast_bound[MAX_MOLECULE_SITES][MAX_SITE_BONDS];	// fast checks on bound status of sites
	} Molecule;
	
	/*
		A ChargedPlane described a uniformly charged, infinite plane located perpendicular
		to a specified axis, at the specified location.
	*/
	typedef struct
	{
		int axis;
		double pos, sigma;
	} ChargedPlane;
	
	/*
		The MCSim structure contains all the info we need to define an MC sim.
		By placing all the info in a single structure, we can pass a pointer to it when we call functions etc, which
		can speed things up and prevents long parameter lists being needed.
	*/
	typedef struct
	{
		/*
			Site templates present in the system
		*/	
		int n_site_templates;
		Site site_templates[MAX_SITE_TEMPLATES];

		/*
			Molecule templates present in the sim.
		*/
		int n_molecule_templates;
		Molecule molecule_templates[MAX_MOLECULE_TEMPLATES];

		/*
			Charged plane templates present in the sim.
		*/
		int n_charged_plane_templates;
		ChargedPlane charged_plane_templates[MAX_CHARGEDPLANE_TEMPLATES];
		
		/*
			General MC information.
		*/
		double T;		// assumes Kelvin.
		double e1;		// relative permittivity of implicit solvent - compared to free space, as #define'd as E0
		double LJ_cut;	// cutoff for LJ interactions
		int LJ_corr;	// Do we consider the tail correction to the LJ interaction?
		double delta_r;	// max move on each axis
		long ran1_seed; // for the ran1() random number generator
		double cell[3]; // simulation box size, [x,y,z]
		int PBC[3];		// periodic boundary conditions or each axis, [x,y,z]; 0 = don't wrap, 1 = wrap
		long int current_step, max_steps, save_every;
		long int accepted, rejected;

		/*
			Reduced units:

			eps = energy (default: kBT)
			sig = length (default: 1)
			
			Conversions:
			
			U* = U . reduced_eps^-1;
			P* = P . reduced_sig^3 . reduced_eps^-1
			rho* = rho . reduced_sig^3
			T* = kB . T . reduced_eps^-1
			
			These are not used, but are included for convenience!
		*/
		double reduced_eps, reduced_sig;

		/*
			Internal stuff - don't change unless you know what you're doing!
			site_coords is guaranteed to be at least n_sites*3 doubles, but may be more if you
			are using the grand canonical ensemble via AddMoleculeToSim() and RemoveMoleculeFromSim(). The
			resizing of arrays etc is taken care of behind the scenes, so if you use those functions you do
			not need to worry about such things.
		*/
		int n_sites, max_sites;		// current total site count, and max capacity before reallocation needed.
		double * site_coords;		// 3*n_sites in length. [ x_1,y_1,z_1, x_2,y_2,z_2, ... x_(n-1), y_(n-1), z_(n-1) ]
		int * site_template_indices;	// indices into sim->site_templates[] for each individual site.

		/*
			Precomputed Lennard-Jones 12-6 table for cross interactions for site types i and j:
			eps = LJ_eps_table[ (i*n_site_templates) + j ] or LJ_eps_table[ (j*n_site_templates) + i ], as symmetrical matrix.
			sig = LJ_sig_table[ (i*n_site_templates) + j ] or LJ_sig_table[ (j*n_site_templates) + i ], as symmetrical matrix.

			LJ 12-6 cross interactions are determined by the Lorentz-Berthelot mixing rules (see RebuildLJTable()):
				sigma_ij = 0.5(sigma_i + sigma_j)
				eps_ij = sqrt(eps_i * eps_j)
			These mixing rules are quite standard, although not always optimal; could replace with, eg, Kong rules as
			discussed in Delhommelle & Millie, Mol Phys 99:8:619-625, 2001.
			
		*/
		double * LJ_eps_table, * LJ_sig_table;
		double stored_coords[MAX_MOLECULE_SITES*3]; // used as a temporary storage buffer in the Push...() and Pop...() routines.
		
		double pt[MAX_PT][9]; // pressure tensor contributions. Not currently used.
		
	} MCSim;

	/*
		In bugs.h
	*/
	void PrintBugs();

	/*
		In energy.c
	*/
	double GetLJ126Energy( double r, double eps, double sig );
	double GetLJ126TailCorrectionEnergy( MCSim * sim );
	double GetHardSphereEnergy( double r, double radius );
	double GetSpringEnergy( double r, double k, double rest, int rigid );
	double GetDirectCoulombEnergy( double r, double qi, double qj, double e1 );
	
	double GetInfiniteWallCoulombEnergy( double r, double qi, double sigma, double e1 );
	double GetFiniteWallCoulombEnergyTV( double r, double qi, double sigma, double e1, double L );
	double GetFiniteWallCoulombEnergyJ( double r, double qi, double sigma, double e1, double W );

	double GetSiteEnergy( MCSim * sim, int site );
	double GetMoleculeEnergy( MCSim * sim, int mol_type, int mol_instance, double * coords );
	double GetTotalEnergy( MCSim * sim );

	/*
		In io.c
	*/
	MCSim * LoadMCSim( char * filename );
	void PrintSim( MCSim * sim );
	void SaveMCSim( MCSim * sim, char * filename );
	
	/*
		In mc.c
	*/
	int GetSiteTypeFromName( MCSim * sim, char * name );
	int GetMoleculeTypeFromName( MCSim * sim, char * name );

	void MIC( int n, double * src, double * dst, double * cell, int * PBC );
	double GetSeparationSquaredAndVectorMIC( double * r1, double * r2, double * dest, double * cell, int * PBC );

	MCSim * MakeEmptySim();
		void AddSiteInfo( MCSim * sim, char * name, double q, double hsr, double LJ_eps, double LJ_sig );
		
		void AddMoleculeInfo( MCSim * sim, char * name, int count, int length, int * sites, int n_bonds, int * bonds, int n_angles, int * angles ); // long winded; used in parsing!
		void AddMoleculeInfo( MCSim * sim, char * name, int count );
		void AddSiteToMolecule( MCSim * sim, char * molecule_name, char * site_name );
		void AddBondToMolecule( MCSim * sim, char * molecule_name, int site1, int site2, double resting_length, double k, int is_rigid );
		void AddAngleToMolecule( MCSim * sim, char * molecule_name, int site1, int site2, int site3, double resting_angle, double k, int is_rigid );
		
		void AddChargedPlaneInfo( MCSim * sim, int axis, double pos, double sigma );
		
		void InitialiseSim( MCSim * sim, double T );
	void FreeSim( MCSim * sim );

	void RebuildLJTable( MCSim * sim );
	double GetLJEpsFromTable( MCSim * sim, int type_i, int type_j );
	double GetLJSigFromTable( MCSim * sim, int type_i, int type_j );

	void PushSiteCoords( MCSim * sim, int site_index );
	void PopSiteCoords( MCSim * sim, int site_index );
	void PushMoleculeCoords( MCSim * sim, int molecule_type, int molecule_instance );
	void PopMoleculeCoords( MCSim * sim, int molecule_type, int molecule_instance );
	
	int AreBound( MCSim * sim, int molecule_type, int molecule_start_index, int i, int j );
	
	int GetMoleculeStartSite( MCSim * sim, int molecule_type, int molecule_instance );
	int GetParentMolecule( MCSim * sim, int site, int *molecule_type, int *molecule_instance );

	void AddMoleculeToSim( MCSim * sim, int molecule_type, double * coords );
	void RemoveMoleculeFromSim( MCSim * sim, int molecule_type, int molecule_instance );

	void GetMoleculeLocalCoords( MCSim * sim, int molecule_type, int molecule_instance, double * dest_coords, double * dest_COG );
	void RotateMolecule( MCSim * sim, int molecule_type, int molecule_instance, double * axis, double theta );
	void TranslateMolecule( MCSim * sim, int molecule_type, int molecule_instance, double * offset );

	#define MC_INCLUDED

#endif
