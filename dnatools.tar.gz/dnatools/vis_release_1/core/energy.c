#include "mc.h"

/*
	NOTE - all energy functions return units of Joules.
	
	In some places, things are divided by NAV (Avogadro's number) as many
	paramaters in the system are expressed in J/mol.
*/

double GetLJ126Energy( double r, double eps, double sig )
{
	double lj6;
	double r_r;
	
	/* Precalculated reciprocal still faster than division in many cases! */
	r_r = 1.0/r;
	
	lj6 = (sig*r_r) * (sig*r_r); /* (sigma/r)^2 */
	lj6 = lj6*lj6*lj6; /* (sigma/r)^6 */
	
	return 4.0*eps*( lj6*lj6 - lj6 );
}
double GetLJ126TailCorrectionEnergy( MCSim * sim )
{
	int i, j;
	double eps, sig, vol, rho, frac3, prefactor, corr, energy;
	
	prefactor = (8.0/3.0)*M_PI;
	energy = 0.0;
	
	vol = sim->cell[0]*sim->cell[1]*sim->cell[2];
	
	/*
		Note; bonding does not matter on the tail correction, provided the LJ cutoff is larger than
		any of the bonds in the sim - which is a pretty safe bet!
	*/
	for( i=0; i<sim->n_site_templates; i++ )
	{
		for( j=i; j<sim->n_site_templates; j++ ) /* not j=i+1...n_site_templates, as want corrections for same site types. */
		{
			eps = GetLJEpsFromTable( sim, i, j ) / NAV; // as eps expressed per mole
			sig = GetLJSigFromTable( sim, i, j );
			
			rho = (double)sim->site_templates[j].count / vol; /* density of site j under consideration. */
						
			/*
				Correction for single site of type i with all instances of type j. We muliply this by the
				appropriate number of sites of type i in the sim, to get the overall contribution of the
				tail corrections for LJ interactions between these two types.
			*/
			frac3 = sig / sim->LJ_cut;
			frac3 = frac3*frac3*frac3; /* (sig/rc)^3 */
			corr = prefactor * rho * (sig*sig*sig) * eps * ( (1.0/3.0)*frac3*frac3*frac3 - frac3 );
			energy += corr * sim->site_templates[i].count;
			/*
				ie, each site of type 'i' in the sim has a correction due to the density of the site type 'j' in
				the simulation; therefore, multiply the correction by the number of 'i' sites.
			*/
		}
	}
	return energy;
}
double GetHardSphereEnergy( double r, double radius )
{
	if( r <= radius ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
	else return 0.0;
}
double GetSpringEnergy( double r, double k, double rest, int rigid )
{
	static double tol = 0.00001; /* distance from equilibrium length beyond which a rigid system produces infinite energy. */
	
	if( rigid == 1 && fabs(r-rest) > tol ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
	return 0.5 * k * (r-rest) * (r-rest);
}
/*
	Return energy of point charges.

	Input:		r in Ang
				qi in ECU
				qj in ECU
				e1 relative to permittivity of vacuum
*/
double GetDirectCoulombEnergy( double r, double qi, double qj, double e1 )
{
	return ( (qi*qj)/(4.0*M_PI*E0*e1*r) ) * ( (ELEM_CHARGE*ELEM_CHARGE)/1e-10 );
}
/*
	Return energy of point charge with infinite charged plane.

	Input:		r in Ang
				qi in ECU
				sigma in ECU per square Angstrom
				e1 relative to permittivity of vacuum
*/
double GetInfiniteWallCoulombEnergy( double r, double qi, double sigma, double e1 )
{
	return ( (-sigma*qi*r)/(2.0*E0*e1) ) * ( (ELEM_CHARGE/1e-20) * ELEM_CHARGE * 1e-10 );
}
/*
	Return energy of point charge with finite charged plane.

	Input:		r in Ang
				qi in ECU
				sigma in ECU.Ang^-2
				e1 relative to permittivity of vacuum
				W in Ang
				
	Notes:	These have been tested to converge onto the energy of an infinite charged plane for sufficiently large W ( around 200 Angstrom ); the relative error between
			the T&V & J versions goes from circa 6.5e-21 @ W = 20Ang to basically zero @ W = 70Ang, so we can confidently use them interchangably for any W.

	       Assumes finite plane is SQUARE! Do not assume this gives the correct result for, eg, circle or rectangle!
*/
double GetFiniteWallCoulombEnergyTV( double r, double qi, double sigma, double e1, double W )
{
	/* a la Torrie and Valleau, J Chem Phys 73:5807 */
	double z, r_1, r_2, f;
	
	z = (r/W); /* as f(zi/W); zi is r, in this case. */

	r_1 = sqrt( 0.5  + z*z );
	r_2 = sqrt( 0.25 + z*z );
		
	f =   4.0*log( (0.5+r_1)/r_2 )
		- 4.0*z*(
					asin( (r_2*r_2 + 0.5*r_1)/(0.5*r_2 + r_1*r_2) )
				  + atan( 1.0/(2.0*z) )
				  - M_PI/2.0
				);
	
	return ((sigma*qi*W)/(4.0*M_PI*e1*E0))*f * ( (ELEM_CHARGE/1e-20) * ELEM_CHARGE * 1e-10);
}
double GetFiniteWallCoulombEnergyJ( double r, double q, double sigma, double e1, double L )
{
	/* a la Jonsson et al, J Phys Chem 84:2179 */
	double a, a2, a4, zpsb, zpsb2, sum;
	double x1, x2, y1, y2;
	
	a = L; /* L/2.0 in Jonsson - error in Melbourne code? noticable effect on conc profile! */
	
	a2 = a*a;
	a4 = a2*a2;
	
	zpsb = r;
	zpsb2 = zpsb*zpsb;
	
	x1 = sqrt( 2.0*a2 + zpsb2 ) + a;
	x2 = sqrt( a2 + zpsb2 );
	
	y1 = a4 - zpsb2*zpsb2 - 2.0*a2*zpsb2;
	y2 = (a2 + zpsb2) * (a2 + zpsb2);
	
	sum = 8.0*log( x1/x2 ) - 2.0*r*( asin(y1/y2) + (M_PI/2.0) );
	
	return ((sigma*q)/(4.0*M_PI*E0*e1)) * sum * ( (ELEM_CHARGE/1e-20) * ELEM_CHARGE * 1e-10);
}



/*
	Note; only works on internal sites; getting the energy of an external site makes no sense, as all
	sites are enclosed in Molecule structures and you'd be using GetMoleculeEnergy on an external molecule instead.
	Otherwise, that external site could be involved with bonds and angle in the external molecule, and we'd need to
	know about the coords of the external sites, and what typeof molecule they are in. At that stage, you're basically
	reimplementing GetMoleculeEnergy()!
*/
double GetSiteEnergy( MCSim * sim, int site )
{
	int i, s1, s2, s3, local_site, mol_start_site, mol_type, mol_instance;
	double LJ_energy, LJTC_energy, LJ_corr_nplus1, LJ_corr_n;
	double Q_energy, HS_energy, QP_energy, bond_energy, angle_energy;
	
	int t1, t2, axis;
	double q1, q2, hs1, hs2;
	double eps, sig, r12, rv12[3], r23, rv23[3], theta;
	
	Molecule * mol;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "Null sim pointer passed" );
		if( site < 0 || site >= sim->n_sites ) JERROR( "Bad site index" );
	#endif
	
	LJ_energy = 0.0;
	LJTC_energy = 0.0;
	Q_energy = 0.0;
	HS_energy = 0.0;
	QP_energy = 0.0;
	bond_energy = 0.0;
	angle_energy = 0.0;
	
	mol_start_site = GetParentMolecule( sim, site, &mol_type, &mol_instance );
	local_site = site - mol_start_site;
	mol = &sim->molecule_templates[mol_type];
	
	t1 = sim->site_template_indices[site];
	q1 = sim->site_templates[t1].q;
	hs1 = sim->site_templates[t1].hard_sphere_radius;
	
	// nonbonded
	for( i=0; i<sim->n_sites; i++ )
	{
		if( i == site ) continue;
		if( AreBound( sim, mol_type, mol_start_site, site, i ) == 1 ) continue;
		
		t2 = sim->site_template_indices[i];
		q2 = sim->site_templates[t2].q;
		hs2 = sim->site_templates[t2].hard_sphere_radius;

		eps = GetLJEpsFromTable( sim, t1, t2 ) / NAV; // as expressed per mole
		sig = GetLJSigFromTable( sim, t1, t2 );

		r12 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[site*3], &sim->site_coords[i*3], rv12, sim->cell, sim->PBC ) );

		if( r12 < sim->LJ_cut )
			LJ_energy += GetLJ126Energy( r12, eps, sig );

		Q_energy += GetDirectCoulombEnergy( r12, q1, q2, sim->e1 );
		HS_energy += GetHardSphereEnergy( r12, hs1 + hs2 );

		/* test for hard sphere collision and bail, to save time avaluating rest of stuff. */
		if( HS_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
	}
		
	// JL tail correction, if needed.
	if( sim->LJ_corr != 0 )
	{
		LJ_corr_nplus1 = GetLJ126TailCorrectionEnergy( sim );
		sim->site_templates[t1].count--;
		LJ_corr_n = GetLJ126TailCorrectionEnergy( sim );
		sim->site_templates[t1].count++;
		
		LJTC_energy = LJ_corr_nplus1 - LJ_corr_n; /* LJ tail correction due to presence of this site. */
	}

	// charged planes
	for( i=0; i<sim->n_charged_plane_templates; i++ )
	{
		axis = sim->charged_plane_templates[i].axis;
		rv12[0] = 0.0;
		rv12[1] = 0.0;
		rv12[2] = 0.0;
		rv12[axis] = sim->site_coords[(site*3) + axis] - sim->charged_plane_templates[i].pos;
		
		MIC( 1, rv12, rv12, sim->cell, sim->PBC );
		r12 = fabs( rv12[axis] ); /* important; want absolute distance for GetInfiniteWallCoulombEnergy below. */
		QP_energy += GetInfiniteWallCoulombEnergy( r12, q1, sim->charged_plane_templates[i].sigma, sim->e1 );
	}

	/*
		bonds; as the internal bond indices are stored as relative to the first site in the molecule,
		we use the "local" site index (ie. subtract the index of the first site in the molecule from the actual site index).
		Then we simply check to see if our local coordinate shows up in any of the bonds listed in the molecule.
	*/
	for( i=0; i<mol->n_bonds; i++ )
	{
		if( mol->bonds[(i*2)+0] == local_site || mol->bonds[(i*2)+1] == local_site )
		{
			s1 = mol_start_site + mol->bonds[(i*2)+0];
			s2 = mol_start_site + mol->bonds[(i*2)+1];
			
			r12 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[s1*3], &sim->site_coords[s2*3], rv12, sim->cell, sim->PBC ) );
			bond_energy += GetSpringEnergy( r12, mol->bond_k[i]/NAV, mol->bond_eq[i], mol->bond_rigid[i] ); // divided by NAV as k is expressed per mole

			/* test for rigid bond violation and bail, to save time avaluating rest of stuff. */
			if( bond_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
		}
	}
	
	/*
		angles; once again, we use the "local" site index, relative to the first site in the molecule.
	*/
	for( i=0; i<mol->n_angles; i++ )
	{
		if( mol->angles[(i*3)+0] == local_site || mol->angles[(i*3)+1] == local_site || mol->angles[(i*3)+2] == local_site )
		{
			s1 = mol_start_site + mol->angles[(i*3)+0];
			s2 = mol_start_site + mol->angles[(i*3)+1];
			s3 = mol_start_site + mol->angles[(i*3)+2];

			r12 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[s1*3], &sim->site_coords[s2*3], rv12, sim->cell, sim->PBC ) );
			r23 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[s3*3], &sim->site_coords[s2*3], rv23, sim->cell, sim->PBC ) );

			/*
				Sometimes, when you have EXACTLY straight angles, acos( stuff ) won't work, as |stuff| has overflowed
				ever so slightly over 1.0. This occurred in testing with straight polymers, so now we have a little guard
				in here to fix that.
			*/
			theta = ( rv12[0]*rv23[0] + rv12[1]*rv23[1] + rv12[2]*rv23[2] ) / (r12*r23);
			if( theta >  1.0 - 1e-10 ) theta =  1.0 - 1e-10;
			if( theta < -1.0 + 1e-10 ) theta = -1.0 + 1e-10;
			theta = acos( theta );

			angle_energy += GetSpringEnergy( theta, mol->angle_k[i]/NAV, mol->angle_eq[i], mol->angle_rigid[i] ); // k is divided by NAV as expressed per mole

			/* test for rigid angle violation and bail, to save time avaluating rest of stuff. */
			if( angle_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
		}
	}

/*	printf( "Site Energies:\n" );
	printf( "\t%e, %e\n", LJ_energy, LJTC_energy );
	printf( "\t%e, %e\n", Q_energy, QP_energy );
	printf( "\t%e\n", HS_energy );
	printf( "\t%e\n", bond_energy );
	printf( "\t%e\n", angle_energy );*/

	return LJ_energy + LJTC_energy + Q_energy + QP_energy + HS_energy + bond_energy + angle_energy;
}







/*
	Terminology:
		An "internal" molecule is one already present in the system, so we have all the details in the sim structure.
		An "external" molecule is not (yet) in the system.

	Parameters:
		mol_type is an index into sim->molecule_templates[]
		mol_instance is the molecule instance: mol_instance<0 where external molecule.
		coords are the external molecule coords, where required (ie where mol_instance<0) - otherwise ignored.

	Notes:
		We can't simply iterate over the sites in the molecule vs all the other sites in the system, and exclude only bound
		sites or self interactions; this would double count the energy between many sites in the molecule.
	
		Consider a linear molecule with 3 sites;
	
		1--2--3
	
		If we move one of the terminal sites (1 or 2), they are not directly bound, and so would be
		evaluated with nonbonded interactions. However, the iteration over the sites in the molecule
		and all other sites in the simulation would include the interactions between 1 and 3 on the first iteration,
		and then between 3 and 1 in the the last iteration - thus double counting the energy. Any energy change due
		to moving the terminal sites would therefore be DOUBLED!
	
		To solve this, we iterate over the sites in the molecule with each other, and then with each site in the molecule
		over the sites before and after that molecule.
*/
double GetMoleculeEnergy( MCSim * sim, int mol_type, int mol_instance, double * coords )
{
	int molecule_start, i, j, length, t1, t2, s1, s2, s3, axis;
	
	double q1, q2, hs1, hs2, eps, sig, theta;
	double r, r12, r23, rv12[3], rv23[3];
	
	double LJ_energy, LJTC_energy, Q_energy, QP_energy, HS_energy, bond_energy, angle_energy;
	double LJ_corr_n, LJ_corr_nplus1;
	
	double * molecule_coords;
	Molecule * mol;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "Null sim pointer passed" );
		if( mol_type < 0 || mol_type >= sim->n_molecule_templates ) JERROR( "Bad molecule type" );
		if( mol_instance < 0 && coords == NULL ) JERROR( "NULL coords passed" );
		if( mol_instance >= sim->molecule_templates[mol_type].count ) JERROR( "Bad molecule instance" );
	#endif

	LJ_energy = LJTC_energy = 0.0;
	Q_energy = QP_energy = 0.0;
	HS_energy = 0.0;
	LJ_corr_n = LJ_corr_nplus1 = 0.0;
	bond_energy = angle_energy = 0.0;

	if( mol_instance < 0 )
	{
		// external molecule; use passed coords
		molecule_start = 0;
		molecule_coords = coords;
	}
	else
	{
		// internal molecule; get coords and start site from site data
		molecule_start = GetMoleculeStartSite( sim, mol_type, mol_instance );
		molecule_coords = &sim->site_coords[molecule_start*3];
	}
	
	
	mol = &sim->molecule_templates[mol_type];
	length = mol->length;

	/*
		Nonbonded interactions - see note above.
	*/
	for( i=0; i<length; i++ )
	{
		t1 = mol->site_templates[i];
		q1 = sim->site_templates[t1].q;
		hs1 = sim->site_templates[t1].hard_sphere_radius;
		
		/*
			nonbonded interactions with other sites in the molecule itself, without
			double counting!
		*/
		for( j=i+1; j<length; j++ )
		{
			/*
				Exclude bound sites. Note that we already have i and j as relative to start of molecule, so we can pass them directly with molecule_start (ie offset) = 0
			*/
			if( AreBound( sim, mol_type, 0, i, j ) == 1 ) continue;

			t2 = mol->site_templates[j];
			q2 = sim->site_templates[t2].q;
			hs2 = sim->site_templates[t2].hard_sphere_radius;

			eps = GetLJEpsFromTable( sim, t1, t2 ) / NAV; // as eps expressed per mole
			sig = GetLJSigFromTable( sim, t1, t2 );

			r = sqrt( GetSeparationSquaredAndVectorMIC( &molecule_coords[i*3], &molecule_coords[j*3], rv12, sim->cell, sim->PBC ) );

			if( r < sim->LJ_cut )
				LJ_energy += GetLJ126Energy( r, eps, sig );

			Q_energy += GetDirectCoulombEnergy( r, q1, q2, sim->e1 );
			HS_energy += GetHardSphereEnergy( r, hs1 + hs2 );

			/* test for hard sphere collision and bail, to save time avaluating rest of stuff. */
			if( HS_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
		}
		/*
			nonbonded interactions with all other sites in the sim, excluding the
			sites in the molecule itself.
		*/
		for( j=0; j<sim->n_sites; j++ )
		{
			/*
				If the molecule is internal, skip the nonbonded interactions with the
				other sites in the molecule, as we've already considered them above.
				
				I'm not sure it's worth removing the molecule_instance check and having 2 separate loops over j
				depending on internal or external, as although this would speed up the external evaluation loop
				(we don't need to the two checks below) that's the uncommon case - most of the time we're acting
				on internal molecules, and we'd still need to test j == molecule_start with potential for pipeline flush
				and branch prediction etc.
			*/
			if( mol_instance >= 0 && j == molecule_start )
			{
				j += length-1; // -1 as we will increment j when we restart the loop after the continue statement!
				continue;
			}

			t2 = sim->site_template_indices[j];
			q2 = sim->site_templates[t2].q;
			hs2 = sim->site_templates[t2].hard_sphere_radius;

			eps = GetLJEpsFromTable( sim, t1, t2 ) / NAV; // as eps expressed per mole
			sig = GetLJSigFromTable( sim, t1, t2 );

			r = sqrt( GetSeparationSquaredAndVectorMIC( &molecule_coords[i*3], &sim->site_coords[j*3], rv12, sim->cell, sim->PBC ) );

			if( r < sim->LJ_cut )
				LJ_energy += GetLJ126Energy( r, eps, sig );

			Q_energy += GetDirectCoulombEnergy( r, q1, q2, sim->e1 );
			HS_energy += GetHardSphereEnergy( r, hs1 + hs2 );

			/* test for hard sphere collision and bail, to save time avaluating rest of stuff. */
			if( HS_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
		}

		/* Site to charged plane interactions */
		for( j=0; j<sim->n_charged_plane_templates; j++ )
		{
			axis = sim->charged_plane_templates[j].axis;
			rv12[0] = 0.0;
			rv12[1] = 0.0;
			rv12[2] = 0.0;
			rv12[axis] = molecule_coords[(i*3) + axis] - sim->charged_plane_templates[j].pos;
			
			MIC( 1, rv12, rv12, sim->cell, sim->PBC );
			r = fabs( rv12[axis] ); /* important; want absolute distance for GetInfiniteWallCoulombEnergy below. */
			QP_energy += GetInfiniteWallCoulombEnergy( r, q1, sim->charged_plane_templates[j].sigma, sim->e1 );
		}
	}

	/*
		Add any desired long ranged correction to the LJ potential.
	*/
	if( sim->LJ_corr != 0 )
	{
		/* molecule is external. */
		if( mol_instance < 0 )
		{
			LJ_corr_n = GetLJ126TailCorrectionEnergy( sim );
			/* increase system site counts to reflect "added" molecule */
			for( i=0; i<length; i++ )
			{
				j = mol->site_templates[i];
				sim->site_templates[j].count++;
			}
			LJ_corr_nplus1 = GetLJ126TailCorrectionEnergy( sim );
			/* decrease system site counts to correct values. */
			for( i=0; i<length; i++ )
			{
				j = mol->site_templates[i];
				sim->site_templates[j].count--;
			}
		}
		/* molecule is internal. */
		else
		{
			LJ_corr_nplus1 = GetLJ126TailCorrectionEnergy( sim );
			/* decrease system site counts to reflect "removed" molecule */
			for( i=0; i<length; i++ )
			{
				j = mol->site_templates[i];
				sim->site_templates[j].count--;
			}
			LJ_corr_n = GetLJ126TailCorrectionEnergy( sim );
			/* increase system site counts to correct values. */
			for( i=0; i<length; i++ )
			{
				j = mol->site_templates[i];
				sim->site_templates[j].count++;
			}
		}
		LJTC_energy = LJ_corr_nplus1 - LJ_corr_n; /* LJ tail correction due to presence of this molecule. */
	}


	/*
		Get bond energies for sites in this molecule.
	*/
	for( i=0; i<mol->n_bonds; i++ )
	{
		s1 = mol->bonds[(i*2)+0];
		s2 = mol->bonds[(i*2)+1];

		r = sqrt( GetSeparationSquaredAndVectorMIC( &molecule_coords[s1*3], &molecule_coords[s2*3], rv12, sim->cell, sim->PBC ) );

		bond_energy += GetSpringEnergy( r, mol->bond_k[i]/NAV, mol->bond_eq[i], mol->bond_rigid[i] ); // k divided by NAV as expressed per mole

		/* test for rigid bond violation and bail, to save time avaluating rest of stuff. */
		if( bond_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
	}
	/*
		Get angle energies for sites in this molecule.
	*/
	for( i=0; i<mol->n_angles; i++ )
	{
		s1 = mol->angles[(i*3)+0];
		s2 = mol->angles[(i*3)+1];
		s3 = mol->angles[(i*3)+2];

		r12 = sqrt( GetSeparationSquaredAndVectorMIC( &molecule_coords[s1*3], &molecule_coords[s2*3], rv12, sim->cell, sim->PBC ) );
		r23 = sqrt( GetSeparationSquaredAndVectorMIC( &molecule_coords[s3*3], &molecule_coords[s2*3], rv23, sim->cell, sim->PBC ) );

		/*
			Sometimes, when you have EXACTLY straight angles, acos( stuff ) won't work, as |stuff| has overflowed
			ever so slightly over 1.0. This occurred in testing with straight polymers, so now we have a little guard
			in here to fix that.
		*/
		theta = ( rv12[0]*rv23[0] + rv12[1]*rv23[1] + rv12[2]*rv23[2] ) / (r12*r23);
		if( theta >  1.0 - 1e-10 ) theta =  1.0 - 1e-10;
		if( theta < -1.0 + 1e-10 ) theta = -1.0 + 1e-10;
		theta = acos( theta );

		angle_energy += GetSpringEnergy( theta, mol->angle_k[i]/NAV, mol->angle_eq[i], mol->angle_rigid[i] ); // k divided by NAV as expressed eper mole

		/* test for rigid angle violation and bail, to save time avaluating rest of stuff. */
		if( angle_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
	}
	
/*	printf( "Molecule Energies:\n" );
	printf( "\t%e, %e\n", LJ_energy, LJTC_energy );
	printf( "\t%e, %e\n", Q_energy, QP_energy );
	printf( "\t%e\n", HS_energy );
	printf( "\t%e\n", bond_energy );
	printf( "\t%e\n", angle_energy );*/
	
	return LJ_energy + LJTC_energy + Q_energy + QP_energy + HS_energy + bond_energy + angle_energy;
}






/*
	Gets the total energy of the system.
	
	Note - we don't have the double counting problem as in GetMoleculeEnergy(); as we can simply
	double loop over i=0->N, j=i+1->N we won't double count energies.
*/
double GetTotalEnergy( MCSim * sim )
{
	int offset, length, i, j, t1, t2, s1, s2, s3, axis;
	int mol_type, mol_instance;
	double q1, q2, hs1, hs2, eps, sig, r12, r23, rv12[3], rv23[3];
	double theta;
	
	double LJ_energy, LJTC_energy, Q_energy, QP_energy, HS_energy, bond_energy, angle_energy;
	
	Molecule * mol;
	
	LJ_energy = 0.0;
	LJTC_energy = 0.0;
	Q_energy = 0.0;
	QP_energy = 0.0;
	HS_energy = 0.0;
	bond_energy = 0.0;
	angle_energy = 0.0;
	
	/*
		As we have contiguous blocks of data for each molecule, we can subsume the loop over
		pairs into a loop over molecules; this is also needed to check whether sites are bound!
	*/
	for( mol_type = 0; mol_type < sim->n_molecule_templates; mol_type++ )
	{
		mol = &sim->molecule_templates[mol_type];
		length = mol->length;
		for( mol_instance = 0; mol_instance < mol->count; mol_instance++ )
		{
			offset = GetMoleculeStartSite( sim, mol_type, mol_instance );
			/*
				Loop over sites in the current molecule
			*/
			for( i=offset; i<offset+length; i++ )
			{
				t1 = sim->site_template_indices[i];
				q1 = sim->site_templates[t1].q;
				hs1 = sim->site_templates[t1].hard_sphere_radius;
				/*
					Get nonbonded energies for sites in the sim.
				*/
				for( j=i+1; j<sim->n_sites; j++ )
				{
					if( AreBound( sim, mol_type, offset, i, j ) == 1 ) continue;

					t2 = sim->site_template_indices[j];
					q2 = sim->site_templates[t2].q;
					hs2 = sim->site_templates[t2].hard_sphere_radius;

					eps = GetLJEpsFromTable( sim, t1, t2 ) / NAV; // as eps is eexpressed per mole
					sig = GetLJSigFromTable( sim, t1, t2 );

					r12 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[i*3], &sim->site_coords[j*3], rv12, sim->cell, sim->PBC ) );

					if( r12 < sim->LJ_cut )
						LJ_energy += GetLJ126Energy( r12, eps, sig );

					Q_energy += GetDirectCoulombEnergy( r12, q1, q2, sim->e1 );
					HS_energy += GetHardSphereEnergy( r12, hs1 + hs2 );

					/* test for inf energy and bail, to save time avaluating rest of stuff. */
					if( HS_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
				}
				/*
					Site to charged plane interactions
				*/
				for( j=0; j<sim->n_charged_plane_templates; j++ )
				{
					axis = sim->charged_plane_templates[j].axis;
					rv12[0] = 0.0;
					rv12[1] = 0.0;
					rv12[2] = 0.0;
					rv12[axis] = sim->site_coords[(i*3) + axis] - sim->charged_plane_templates[j].pos;
				
					MIC( 1, rv12, rv12, sim->cell, sim->PBC );
					r12 = fabs( rv12[axis] ); /* important; want absolute distance for GetInfiniteWallCoulombEnergy below. */
					QP_energy += GetInfiniteWallCoulombEnergy( r12, q1, sim->charged_plane_templates[j].sigma, sim->e1 );
				}
			}
			/*
				Get bond energies for sites in this molecule.
			*/
			for( i=0; i<mol->n_bonds; i++ )
			{
				s1 = offset + mol->bonds[(i*2)+0];
				s2 = offset + mol->bonds[(i*2)+1];

				r12 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[s1*3], &sim->site_coords[s2*3], rv12, sim->cell, sim->PBC ) );

				bond_energy += GetSpringEnergy( r12, mol->bond_k[i]/NAV, mol->bond_eq[i], mol->bond_rigid[i] ); // k divided by NAV as expressed per mole

				/* test for rigid bond violation and bail, to save time avaluating rest of stuff. */
				if( bond_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
			}
			/*
				Get angle energies for sites in this molecule.
			*/
			for( i=0; i<mol->n_angles; i++ )
			{
				s1 = offset + mol->angles[(i*3)+0];
				s2 = offset + mol->angles[(i*3)+1];
				s3 = offset + mol->angles[(i*3)+2];

				r12 = GetSeparationSquaredAndVectorMIC( &sim->site_coords[s1*3], &sim->site_coords[s2*3], rv12, sim->cell, sim->PBC );
				r23 = GetSeparationSquaredAndVectorMIC( &sim->site_coords[s3*3], &sim->site_coords[s2*3], rv23, sim->cell, sim->PBC );

				r12 = sqrt( r12 );
				r23 = sqrt( r23 );
				
				/*
					Sometimes, when you have EXACTLY straight angles, acos( stuff ) won't work, as |stuff| has overflowed
					ever so slightly over 1.0. This occurred in testing with straight polymers, so now we have a little guard
					in here to fix that.
				*/
				theta = ( rv12[0]*rv23[0] + rv12[1]*rv23[1] + rv12[2]*rv23[2] ) / (r12*r23);
				if( theta >  1.0 - 1e-10 ) theta =  1.0 - 1e-10;
				if( theta < -1.0 + 1e-10 ) theta = -1.0 + 1e-10;
				theta = acos( theta );
				
				angle_energy += GetSpringEnergy( theta, mol->angle_k[i]/NAV, mol->angle_eq[i], mol->angle_rigid[i] ); // k divided by NAV as expressed per mole

				/* test for rigid angle violation and bail, to save time avaluating rest of stuff. */
				if( angle_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
			}
		}
	}
	
	/*
		Should really have a term for the charged plane energies if you are planning on moving planes which share an axis during the sim,
		otherwise it will always be a constant contribution to the energy which we should be able to ignore. Planes with orthogonal axes
		will always supply a constant energy as they are infinite, so any possible arrangement of their position gives the same energy.
		
		IMPORTANT: this will obviously be a different situation entirely if the charge on the infinite planes is changing during the simulation!
		Then we will need to consider the interactions between all the planes on all the axes!
	*/
	
	LJTC_energy += GetLJ126TailCorrectionEnergy( sim );

	return LJ_energy + LJTC_energy + Q_energy + QP_energy + HS_energy + bond_energy + angle_energy;
}




































/*
	Pressure tensor calculations; not currently used.
*/
void EvaluatePressure( MCSim * sim, double hsr, double sigma, Bins * qbins )
{
	int i, j, t1, t2, s1, s2, s3;
	int mol_type, mol_instance, site_offset;
	double r, r12[3], r23[3];
	double f1[3], f2[3], f3[3];
	double q1, q2, k, rest, eps, sig;
	double pre1, pre2, sig6, rr, rr6;
	double DC_check;
	
	double theta, cos_theta, sin_theta, l12, l23, c11, c13, c33;

	for( j=0; j<MAX_PT; j++ )
		for( i=0; i<9; i++ )
			sim->pt[j][i] = 0.0;
	
	/*
		Direct sites; ignores hard sphere potential, as assumes called with valid configuration - if not, pressure will be wrong!
		Momentum transfer due to hard sphere potential calculated elsewhere in ...
	*/
	DC_check = 0.0;
	for( i=0; i<sim->n_sites; i++ )
	{
		t1 = sim->site_template_indices[i];
		q1 = sim->site_templates[t1].q;
		
		for( j=i+1; j<sim->n_sites; j++ )
		{
			t2 = sim->site_template_indices[j];
			q2 = sim->site_templates[t2].q;
			
			eps = GetLJEpsFromTable( sim, t1, t2 );
			sig = GetLJSigFromTable( sim, t1, t2 );
			
			r = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[i*3], &sim->site_coords[j*3], r12, sim->cell, sim->PBC ) );
			
			/*
				Some handy info...
			*/
			rr = 1.0/r;			/* reciprocal; 1/r */
			rr6 =  rr  * rr  * rr  * rr  * rr  * rr;
			sig6 = sig * sig * sig * sig * sig * sig;

			/*
				Lennard-Jones 12-6 pressure contribution.
				Units should be fine, ie reduced units per reduced length.
			*/
			pre1 = 4.0*eps*( 12.0*sig6*sig6*rr6*rr6*rr - 6.0*sig6*rr6*rr );
			if( r < sim->LJ_cut )
			{
				f1[0] = pre1 * r12[0]/r;
				f1[1] = pre1 * r12[1]/r;
				f1[2] = pre1 * r12[2]/r;
				
				sim->pt[PT_LJ][0] += r12[0] * f1[0];
				sim->pt[PT_LJ][1] += r12[0] * f1[1];
				sim->pt[PT_LJ][2] += r12[0] * f1[2];

				sim->pt[PT_LJ][3] += r12[1] * f1[0];
				sim->pt[PT_LJ][4] += r12[1] * f1[1];
				sim->pt[PT_LJ][5] += r12[1] * f1[2];

				sim->pt[PT_LJ][6] += r12[2] * f1[0];
				sim->pt[PT_LJ][7] += r12[2] * f1[1];
				sim->pt[PT_LJ][8] += r12[2] * f1[2];
			}
			
			/*
				Direct Coulomb pressure contribution
				Units converted to J / m, but then must be changed to reduced units / Angstrom!
			*/
			pre2 = ( (q1*q2*ELEM_CHARGE*ELEM_CHARGE)/(4.0*M_PI*E0*sim->e1*(r*r*1e-20)) ); /* / (sim->reduced_eps*1e10); */
			f2[0] = pre2 * r12[0]/r;
			f2[1] = pre2 * r12[1]/r;
			f2[2] = pre2 * r12[2]/r;

			sim->pt[PT_DC][0] += r12[0] * f2[0];
			sim->pt[PT_DC][1] += r12[0] * f2[1];
			sim->pt[PT_DC][2] += r12[0] * f2[2];

			sim->pt[PT_DC][3] += r12[1] * f2[0];
			sim->pt[PT_DC][4] += r12[1] * f2[1];
			sim->pt[PT_DC][5] += r12[1] * f2[2];

			sim->pt[PT_DC][6] += r12[2] * f2[0];
			sim->pt[PT_DC][7] += r12[2] * f2[1];
			sim->pt[PT_DC][8] += r12[2] * f2[2];
			
/*			if( sim->site_coords[(i*3)+2] * sim->site_coords[(j*3)+2] < 0.0 ) // on different sides of the midplane */
			if( sim->site_coords[(i*3)+2] < 0.0 && sim->site_coords[(j*3)+2] > 0.0 ) /* on different sides of the midplane */
			{
				DC_check += ( -(q1*q2*ELEM_CHARGE*ELEM_CHARGE)/(4.0*M_PI*E0*sim->e1*(r*1e-10*r*1e-10)) ) * ( fabs(r12[2])/r ); /* units cancel in r12 and r, so use as is. */
/*				DC_check += ( -(q1*q2*ELEM_CHARGE*ELEM_CHARGE)/(sim->e1*(r*r*1e-20)) ) * ( fabs(r12[2])/r ); // units cancel in r12 and r, so use as is. */
			}
		}
	}
	printf( "%e: %e\n", DC_check, DC_check / ( (sim->cell[0]*sim->cell[1]*1e-18) ) ); /* 1e-18 as want decimetres, not m! */

	/* wall forces. */
	DC_check = 0.0;
	for( i=0; i<sim->n_sites; i++ )
	{
			q1 = sim->site_templates[ sim->site_template_indices[i] ].q;
			
			if( sim->site_coords[(i*3)+2] < 0.0 )
			{
				/* interaction with opposite wall */
				r = hsr + sim->cell[2]/2.0 + fabs(sim->site_coords[(i*3)+2]);
				r = r / sim->cell[0];
				pre2 = 4.0*r*r * sqrt( 1 + 1.0/(2.0*r*r) );
				pre2 = atan( 1.0 / pre2 );
				DC_check += -((4.0*q1*sigma) / (4.0*M_PI*E0*sim->e1)) * pre2 * ELEM_CHARGE * (ELEM_CHARGE/1e-20);
			}
			else
			{
				/* only do one side? */
			}
	}
	printf( "%e: %e\n", DC_check, DC_check / ( (sim->cell[0]*sim->cell[1]*1e-18) ) ); /* 1e-18 as want decimetres, not m! */
	
	/*
		Bond and angle pressure
	*/
	for( mol_type = 0; mol_type < sim->n_molecule_templates; mol_type++ )
	{
		for( mol_instance = 0; mol_instance < sim->molecule_templates[mol_type].count; mol_instance++ )
		{
			site_offset = GetMoleculeStartSite( sim, mol_type, mol_instance );
			/*
				Get bond energies for sites in this molecule.
			*/
			for( i=0; i<sim->molecule_templates[mol_type].n_bonds; i++ )
			{
				s1 = site_offset + sim->molecule_templates[mol_type].bonds[(i*2)+0];
				s2 = site_offset + sim->molecule_templates[mol_type].bonds[(i*2)+1];

				k = sim->molecule_templates[mol_type].bond_k[i];
				rest = sim->molecule_templates[mol_type].bond_eq[i];

				r = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[s1*3], &sim->site_coords[s2*3], r12, sim->cell, sim->PBC ) );

				pre1 = k*( r - rest );
				
				f1[0] = -pre1 * r12[0]/r;
				f1[1] = -pre1 * r12[1]/r;
				f1[2] = -pre1 * r12[2]/r;
				
				sim->pt[PT_BOND][0] += r12[0] * f1[0];
				sim->pt[PT_BOND][1] += r12[0] * f1[1];
				sim->pt[PT_BOND][2] += r12[0] * f1[2];

				sim->pt[PT_BOND][3] += r12[1] * f1[0];
				sim->pt[PT_BOND][4] += r12[1] * f1[1];
				sim->pt[PT_BOND][5] += r12[1] * f1[2];

				sim->pt[PT_BOND][6] += r12[2] * f1[0];
				sim->pt[PT_BOND][7] += r12[2] * f1[1];
				sim->pt[PT_BOND][8] += r12[2] * f1[2];
			}
			/*
				Get angle pressure for sites in this molecule.
				
				U(theta) = k/2 ( theta - rest )^2
				F(theta) - -\grad U(theta)
				
				Use chain rule:
				
				F = -( dU/dtheta . dtheta/dcos(theta) . dcos(theta)/dx ), for force on x due to angle potential.
				
				dU/dtheta = k( theta - rest )
				dtheta/dcos(theta) = -1/sin(theta)
				
				as:
					theta = acos( cos(theta) ),
				so:
					dtheta/dcos(theta) = -1/sqrt(1-cos^2(theta)),
				as derivative of acos(x) = 1/sqrt(1-cos^2(theta)), and sin^2(theta) = 1 - cos^2(theta)
				
				dcos(theta)/dx = 
				
				as
					cos(theta) = rij.rjk/(|rij|.|rjk|)
				where
					rij = ri -> rj
					rjk = rj -> rk
					
				Hence, total force is ...
				
			*/
			for( i=0; i<sim->molecule_templates[mol_type].n_angles; i++ )
			{
				s1 = site_offset + sim->molecule_templates[mol_type].angles[(i*3)+0];
				s2 = site_offset + sim->molecule_templates[mol_type].angles[(i*3)+1];
				s3 = site_offset + sim->molecule_templates[mol_type].angles[(i*3)+2];

				k = sim->molecule_templates[mol_type].angle_k[i];
				rest = sim->molecule_templates[mol_type].angle_eq[i];

				l12 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[s1*3], &sim->site_coords[s2*3], r12, sim->cell, sim->PBC ) );
				l23 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[s3*3], &sim->site_coords[s2*3], r23, sim->cell, sim->PBC ) );

				l12 = sqrt( l12 );
				l23 = sqrt( l23 );
				
				cos_theta = (r12[0]*r23[0] + r12[1]*r23[1] + r12[2]*r23[2]) / (l12*l23);
				theta = acos( cos_theta );
				sin_theta = sin( theta );
				if( fabs(sin_theta) < 1e-6 ) sin_theta = 1e-6;
				
				pre1 = k * ( theta - rest ) / sin_theta;
				c13 = pre1 / ( l12 * l23 );
				pre2 = pre1 * cos_theta;
				c11 = pre2 / ( l12 * l12 );
				c33 = pre2 / ( l23 * l23 );
				
				f1[0] = -c13 * r23[0] + c11 * r12[0];
				f1[1] = -c13 * r23[1] + c11 * r12[1];
				f1[2] = -c13 * r23[2] + c11 * r12[2];

				f3[0] = -c13 * r12[0] + c33 * r23[0];
				f3[1] = -c13 * r12[1] + c33 * r23[1];
				f3[2] = -c13 * r12[2] + c33 * r23[2];
				
				sim->pt[PT_ANGLE][0] += r12[0]*f1[0] + r23[0]*f3[0];
				sim->pt[PT_ANGLE][1] += r12[0]*f1[1] + r23[0]*f3[1];
				sim->pt[PT_ANGLE][2] += r12[0]*f1[2] + r23[0]*f3[2];

				sim->pt[PT_ANGLE][3] += r12[1]*f1[0] + r23[1]*f3[0];
				sim->pt[PT_ANGLE][4] += r12[1]*f1[1] + r23[1]*f3[1];
				sim->pt[PT_ANGLE][5] += r12[1]*f1[2] + r23[1]*f3[2];

				sim->pt[PT_ANGLE][6] += r12[2]*f1[0] + r23[2]*f3[0];
				sim->pt[PT_ANGLE][7] += r12[2]*f1[1] + r23[2]*f3[1];
				sim->pt[PT_ANGLE][8] += r12[2]*f1[2] + r23[2]*f3[2];
			}
		}
	}
	
	printf( "LJ pressure:\n" );
	for( i=0; i<3; i++ ) printf( "\t% .2e % .2e % .2e\n", sim->pt[PT_LJ][(i*3)+0], sim->pt[PT_LJ][(i*3)+1], sim->pt[PT_LJ][(i*3)+2] );

	printf( "DC pressure:\n" );
	for( i=0; i<3; i++ ) printf( "\t% .2e % .2e % .2e\n", sim->pt[PT_DC][(i*3)+0], sim->pt[PT_DC][(i*3)+1], sim->pt[PT_DC][(i*3)+2] );
	printf( "%e\n", sim->pt[PT_DC][8]/(sim->cell[0]*sim->cell[1]*sim->cell[2]*1e-30*NAV*KB*sim->T) );

	printf( "Bond pressure:\n" );
	for( i=0; i<3; i++ ) printf( "\t% .2e % .2e % .2e\n", sim->pt[PT_BOND][(i*3)+0], sim->pt[PT_BOND][(i*3)+1], sim->pt[PT_BOND][(i*3)+2] );

	printf( "Angle pressure:\n" );
	for( i=0; i<3; i++ ) printf( "\t% .2e % .2e % .2e\n", sim->pt[PT_ANGLE][(i*3)+0], sim->pt[PT_ANGLE][(i*3)+1], sim->pt[PT_ANGLE][(i*3)+2] );
}
