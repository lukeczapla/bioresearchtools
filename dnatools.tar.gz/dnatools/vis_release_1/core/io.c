#include "mc.h"


/*
	Here be dragons!
	
	There is some ugly, UGLY code in here. This is generally the case when doing IO with C.
	
	Don't mess with this stuff unless you know what you're doing!
*/




/*
	Little macro to check whether there are the correct number of arguments fro a parse line.
*/
#define PARSE_CHECK_ARG_COUNT( ntokens, count, buffer, msg, lno, fname ) \
	if( ntokens < count )	\
	{	\
		sprintf( buffer, "Bad %s on line %d of input file %s", msg, lno, fname );	\
		JERROR( buffer );	\
	}

int ParseSystemParams( char * filename, FILE * f, MCSim * sim, int * line_no )
{
	char buffer[1024];
	char * tokens[10];
	char * delims = ":; \t\n\r";
	int ntokens, returnval;
	
	sim->T = 0.0;
	sim->e1 = 0.0;
	sim->ran1_seed = 0;
	sim->delta_r = 0.0;
	
	sim->LJ_cut = 0.0;
	sim->LJ_corr = 0;
	
	sim->cell[0] = 0.0;
	sim->cell[1] = 0.0;
	sim->cell[2] = 0.0;
	
	sim->PBC[0] = 0;
	sim->PBC[1] = 0;
	sim->PBC[2] = 0;
	
	sim->current_step = 0;
	sim->max_steps = 0;
	sim->save_every = 0;

	sim->accepted = 0;
	sim->rejected = 0;
	
	returnval = -1;

	while( fgets( buffer, 1024, f ) != NULL )
	{
		(*line_no)++;
		ntokens = TokenizeString( buffer, delims, tokens, 10 );

		if( ntokens < 1 || buffer[0] == '#' || tokens[0][0] == '#' ) continue;
		if( strcasecmp(tokens[0],"end") == 0 ) { returnval = 0; break; }
		
		/* ALL params are "key value" pairs, so check number of tokens only once, here. */
		PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "parameter definition", *line_no, filename );

		if( strcasecmp(tokens[0],"t") == 0 ) 			sim->T = StringToDouble( tokens[1], filename, *line_no );
		else if( strcasecmp(tokens[0],"e1") == 0 )		sim->e1 = StringToDouble( tokens[1], filename, *line_no );
		else if( strcasecmp(tokens[0],"seed") == 0 )	sim->ran1_seed = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"delta_r") == 0 )	sim->delta_r = StringToDouble( tokens[1], filename, *line_no );
		else if( strcasecmp(tokens[0],"lj_cut") == 0 )	sim->LJ_cut = StringToDouble( tokens[1], filename, *line_no );
		else if( strcasecmp(tokens[0],"lj_corr") == 0 )	sim->LJ_corr = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"x") == 0 )		sim->cell[0] = StringToDouble( tokens[1], filename, *line_no );
		else if( strcasecmp(tokens[0],"y") == 0 )		sim->cell[1] = StringToDouble( tokens[1], filename, *line_no );
		else if( strcasecmp(tokens[0],"z") == 0 )		sim->cell[2] = StringToDouble( tokens[1], filename, *line_no );
		else if( strcasecmp(tokens[0],"pbc_x") == 0 )	sim->PBC[0] = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"pbc_y") == 0 )	sim->PBC[1] = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"pbc_z") == 0 )	sim->PBC[2] = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"step") == 0 )	sim->current_step = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"max_steps") == 0 )sim->max_steps = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"current_step") == 0 )sim->current_step = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"save_every") == 0 )sim->save_every = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"accepted") == 0 )sim->accepted = StringToInt( tokens[1], 10, filename, *line_no );
		else if( strcasecmp(tokens[0],"rejected") == 0 )sim->rejected = StringToInt( tokens[1], 10, filename, *line_no );
		else printf( "WARNING: Unknown system flag '%s' in input file %s, line %d - IGNORING LINE!\n", tokens[0], filename, *line_no );
	}
	return returnval;
}
int ParseSite( char * filename, FILE * f, MCSim * sim, int * line_no )
{
	char buffer[1024];
	char * tokens[10];
	char * delims = ":; \t\n\r";
	int ntokens, returnval;
	Site s;
	
	sprintf( s.name, "site_%d", sim->n_site_templates );
	s.count = 0;
	s.q = 0.0;
	s.hard_sphere_radius = 0.0;
	s.LJ_eps = 0.0;
	s.LJ_sig = 0.0;
	
	returnval = -1;

	while( fgets( buffer, 1024, f ) != NULL )
	{
		(*line_no)++;
		ntokens = TokenizeString( buffer, delims, tokens, 10 );

		if( ntokens < 1 || buffer[0] == '#' || tokens[0][0] == '#' ) continue;
		if( strcasecmp(tokens[0],"end") == 0 ) { returnval = 0; break; }

		if( strcasecmp(tokens[0],"name") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "name", *line_no, filename );
			strncpy( s.name, tokens[1], MAX_TEMPLATE_NAMELEN );
		}
		else if( strcasecmp(tokens[0],"q") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "charge", *line_no, filename );
			s.q = StringToDouble( tokens[1], filename, *line_no );
		}
		else if( strcasecmp(tokens[0],"hard_sphere") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "hard sphere radius", *line_no, filename );
			s.hard_sphere_radius = StringToDouble( tokens[1], filename, *line_no );
			if( s.hard_sphere_radius < 0.0 )
			{
				sprintf( buffer, "Hard sphere radius must be zero (no hard sphere) or positive (hard sphere); value is %f on line %d of input file %s\n", s.hard_sphere_radius, *line_no, filename );
				JERROR( buffer );
			}
		}
		else if( strcasecmp(tokens[0],"LJ_eps") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "LJ eps", *line_no, filename );
			s.LJ_eps = StringToDouble( tokens[1], filename, *line_no );
		}
		else if( strcasecmp(tokens[0],"LJ_sig") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "LJ sig", *line_no, filename );
			s.LJ_sig = StringToDouble( tokens[1], filename, *line_no );
		}
		else printf( "WARNING: Unknown site flag '%s' in input file %s, line %d - IGNORING LINE!\n", tokens[0], filename, *line_no );
	}
	
	AddSiteInfo( sim, s.name, s.q, s.hard_sphere_radius, s.LJ_eps, s.LJ_sig );
	return returnval;
}
int ParseMolecule( char * filename, FILE * f, MCSim * sim, int * line_no )
{
	char buffer[1024], msg[1024];
	char * tokens[10];
	char * delims = ":; \t\n\r";
	int ntokens, i, returnval;
	Molecule mol;
	
	sprintf( mol.name, "site_%d", sim->n_molecule_templates );
	mol.count = 0;
	mol.length = 0;
	mol.n_bonds = 0;
	mol.n_angles = 0;
	
	returnval = -1;

	while( fgets( buffer, 1024, f ) != NULL )
	{
		(*line_no)++;
		ntokens = TokenizeString( buffer, delims, tokens, 10 );

		if( ntokens < 1 || buffer[0] == '#' || tokens[0][0] == '#' ) continue;
		if( strcasecmp(tokens[0],"end") == 0 ) { returnval = 0; break; }
	
		if( strcasecmp(tokens[0],"name") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "name", *line_no, filename );
			strncpy( mol.name, tokens[1], MAX_TEMPLATE_NAMELEN );
		}
		else if( strcasecmp(tokens[0],"count") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "count", *line_no, filename );
			mol.count = StringToInt( tokens[1], 10, filename, *line_no );
		}
		else if( strcasecmp(tokens[0],"site") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "site", *line_no, filename );
			i = GetSiteTypeFromName( sim, tokens[1] );
			if( i == -1 )
			{
				sprintf( msg, "Unknown site type '%s' in molecule on line %d of input file %s", tokens[1], *line_no, filename );
				JERROR( msg ); /* using separate message buffer here, as tokens[1] points into buffer so can't sprintf() to that! */
			}
			mol.site_templates[mol.length] = i;
			mol.length++;
		}
		else if( strcasecmp(tokens[0],"bond") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 6, buffer, "bond definition", *line_no, filename );
			i = mol.n_bonds;
			mol.bonds[i*2 +0]  = StringToInt( tokens[1], 10, filename, *line_no )-1;
			mol.bonds[i*2 +1]  = StringToInt( tokens[2], 10, filename, *line_no )-1;
			mol.bond_eq[i]      = StringToDouble( tokens[3], filename, *line_no );
			mol.bond_k[i]       = StringToDouble( tokens[4], filename, *line_no );
			mol.bond_rigid[i]   = StringToInt( tokens[5], 10, filename, *line_no );
			mol.n_bonds++;
		}
		else if( strcasecmp(tokens[0],"angle") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 7, buffer, "angle definition", *line_no, filename );
			i = mol.n_angles;
			mol.angles[i*3 +0] = StringToInt( tokens[1], 10, filename, *line_no )-1;
			mol.angles[i*3 +1] = StringToInt( tokens[2], 10, filename, *line_no )-1;
			mol.angles[i*3 +2] = StringToInt( tokens[3], 10, filename, *line_no )-1;
			mol.angle_eq[i]   = StringToDouble( tokens[4], filename, *line_no );
			mol.angle_k[i]    = StringToDouble( tokens[5], filename, *line_no );
			mol.angle_rigid[i] = StringToInt( tokens[6], 10, filename, *line_no );
			mol.n_angles++;
		}
		else printf( "WARNING: Unknown molecule flag '%s' in input file %s, line %d - IGNORING LINE!\n", tokens[0], filename, *line_no );
	}
	
	AddMoleculeInfo( sim, mol.name, mol.count, mol.length, mol.site_templates, mol.n_bonds, mol.bonds, mol.n_angles, mol.angles );
	/*
		Copy bond and angle parameters from the parsed molecule to the sim arrays.
		This is not done in AddMoleculeInfo(), which only copies the indices!
	*/
	for( i=0; i<mol.n_bonds; i++ )
	{
		sim->molecule_templates[sim->n_molecule_templates-1].bond_eq[i] = mol.bond_eq[i];
		sim->molecule_templates[sim->n_molecule_templates-1].bond_k[i] = mol.bond_k[i];
		sim->molecule_templates[sim->n_molecule_templates-1].bond_rigid[i] = mol.bond_rigid[i];
	}
	for( i=0; i<mol.n_angles; i++ )
	{
		sim->molecule_templates[sim->n_molecule_templates-1].angle_eq[i] = mol.angle_eq[i];
		sim->molecule_templates[sim->n_molecule_templates-1].angle_k[i] = mol.angle_k[i];
		sim->molecule_templates[sim->n_molecule_templates-1].angle_rigid[i] = mol.angle_rigid[i];
	}
	return returnval;
}
int ParseChargedPlane( char * filename, FILE * f, MCSim * sim, int * line_no )
{
	char buffer[1024];
	char * tokens[10];
	char * delims = ":; \t\n\r";
	int ntokens, returnval;
	ChargedPlane cp;
	
	cp.axis = 0;
	cp.pos = 0.0;
	cp.sigma = 0.0;
	
	returnval = -1;
	
	while( fgets( buffer, 1024, f ) != NULL )
	{
		(*line_no)++;
		ntokens = TokenizeString( buffer, delims, tokens, 10 );

		if( ntokens < 1 || buffer[0] == '#' || tokens[0][0] == '#' ) continue;
		if( strcasecmp(tokens[0],"end") == 0 ) { returnval = 0; break; }
		
		if( strcasecmp(tokens[0],"axis") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "axis", *line_no, filename );
			cp.axis = StringToInt( tokens[1], 10, filename, *line_no );
			if( cp.axis < 0 || cp.axis > 2 )
			{
				sprintf( buffer, "Bad axis definition on line %d of input file %s", *line_no, filename );
				JERROR( buffer );
			}
		}
		else if( strcasecmp(tokens[0],"pos") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "position", *line_no, filename );
			cp.pos = StringToDouble( tokens[1], filename, *line_no );
		}
		else if( strcasecmp(tokens[0],"sigma") == 0 )
		{
			PARSE_CHECK_ARG_COUNT( ntokens, 2, buffer, "sigma", *line_no, filename );
			cp.sigma = StringToDouble( tokens[1], filename, *line_no );
		}
		else printf( "WARNING: Unknown charged plane flag '%s' in input file %s, line %d - IGNORING LINE!\n", tokens[0], filename, *line_no );
	}
	
	AddChargedPlaneInfo( sim, cp.axis, cp.pos, cp.sigma );
	return returnval;
}
int ParseCoords( char * filename, FILE * f, MCSim * sim, int * line_no )
{
	char buffer[1024], msg[1024];
	char * tokens[10];
	char * delims = ":; \t\n\r";
	int ntokens, i, returnval;
	int current_config_site;
	
	current_config_site = 0;
	
	returnval = -1;
	
	while( fgets( buffer, 1024, f ) != NULL )
	{
		(*line_no)++;

		ntokens = TokenizeString( buffer, delims, tokens, 10 );
		
		if( ntokens < 1 || buffer[0] == '#' || tokens[0][0] == '#' ) continue;
		if( strcasecmp(tokens[0],"end") == 0 ) { returnval = 0; break; }

		PARSE_CHECK_ARG_COUNT( ntokens, 4, buffer, "entry", *line_no, filename );
		if( current_config_site >= sim->n_sites )
		{
			sprintf( msg, "Too many sites in configuration - stopped at line %d of input file %s", *line_no, filename );
			JERROR( msg );
		}

		i = GetSiteTypeFromName( sim, tokens[0] );
		
		if( i == -1 )
		{
			sprintf( msg, "Unknown site type '%s' in configuration on line %d of input file %s", tokens[0], *line_no, filename );
			JERROR( msg );
		}
		else if( i != sim->site_template_indices[current_config_site] )
		{
			i = sim->site_template_indices[current_config_site];
			sprintf( msg, "Unexpected site type '%s' (expecting '%s') in configuration on line %d of input file %s", tokens[0], sim->site_templates[i].name, *line_no, filename );
			JERROR( msg );
		}
		else
		{
			sim->site_coords[current_config_site*3 +0] = StringToDouble( tokens[1], filename, *line_no );
			sim->site_coords[current_config_site*3 +1] = StringToDouble( tokens[2], filename, *line_no );
			sim->site_coords[current_config_site*3 +2] = StringToDouble( tokens[3], filename, *line_no );

			current_config_site++;
		}

	}
	return returnval;
}
		


/*
	Make an MC sim from a file.
*/
MCSim * LoadMCSim( char * filename )
{
	char buffer[1024];
	char * tokens[10];
	char * delims = ":; \t\n\r";
	FILE * f;
	int ntokens, line_no, i, j;
	int sim_initialised;
	MCSim * sim;
	
	#ifdef DEBUG
		if( filename == NULL ) JERROR( "NULL filename passed" );
	#endif

	sim = MakeEmptySim();
	sim_initialised = 0;

	if( (f = fopen(filename,"r")) == NULL ) JERROR( "Unable to open sim input file" );

	/*
		*****************************************************************
		* Parse input file.                                             *
		*****************************************************************
	*/
	line_no = 0;
	while( fgets( buffer, 1024, f ) != NULL )
	{
		line_no++;
		ntokens = TokenizeString( buffer, delims, tokens, 10 );

		if( ntokens < 1 || buffer[0] == '#' || tokens[0][0] == '#' ) continue;
		if( strcasecmp(tokens[0],"end") == 0 )
		{
			sprintf( buffer, "Unexpected 'end' statement on line %d of input file %s", line_no, filename );
			JERROR( buffer );
		}
		
		if( strcasecmp(tokens[0],"system") == 0 )
		{
			if( ParseSystemParams( filename, f, sim, &line_no ) == -1 ) JERROR( "Problem in parsing system parameters" );
		}
		else if( strcasecmp(tokens[0],"site") == 0 )
		{
			if( ParseSite( filename, f, sim, &line_no ) == -1 ) JERROR( "Problem in parsing site" );
		}
		else if( strcasecmp(tokens[0],"molecule") == 0 )
		{
			if( ParseMolecule( filename, f, sim, &line_no ) == -1 ) JERROR( "Problem in parsing molecule" );
		}
		else if( strcasecmp(tokens[0],"charged_plane") == 0 )
		{
			if( ParseChargedPlane( filename, f, sim, &line_no ) == -1 ) JERROR( "Problem in parsing charged plane" );
		}
		else if( strcasecmp(tokens[0],"coordinates") == 0 )
		{
			/* should have enough molecule info etc at this point to allocate site coordinate arrays etc. Need to do this before reading in coorsd etc. */
			InitialiseSim( sim, sim->T );
			sim_initialised = 1;
			/* load up the coordinates, having set up the arrays above. */
			if( ParseCoords( filename, f, sim, &line_no ) == -1 ) JERROR( "Problem in parsing coordinates" );
		}
		else
		{
			printf( "WARNING: Unknown section '%s' in input file %s, line %d - IGNORING ENTIRE SECTION!\n", tokens[0], filename, line_no );
		}
	}
	
	fclose( f );
	
	/*
		If we didn't hit a coordinates section, we won't have initialised the sim yet; this is very important,
		as it allocates the coordinate array and the site types array etc!
	*/
	if( sim_initialised == 0 )
	{
		printf( "WARNING: No configuration section encountered in input file %s; initial coordinates will all be zero unless explicitly set!\n", filename );
		InitialiseSim( sim, sim->T );
	}

	/*
		*****************************************************************
		* Some misc. validity checks.                                   *
		*****************************************************************
	*/
	printf( "System params check:\n" );
	printf( "\tT : %f (%f)\n", sim->T, sim->T*sim->reduced_eps/KB );
	printf( "\tLJ cutoff : %f (%f)\n", sim->LJ_cut, sim->LJ_cut * sim->reduced_sig );
	printf( "\tReduced eps %e, reduced sig %e.\n", sim->reduced_eps, sim->reduced_sig );
	for( i=0; i<sim->n_site_templates; i++ )
		printf( "%s : %d, %e %e (%e J/mol, %e Ang)\n", sim->site_templates[i].name, sim->site_templates[i].count, sim->site_templates[i].LJ_eps, sim->site_templates[i].LJ_sig, sim->site_templates[i].LJ_eps*sim->reduced_eps*NAV, sim->site_templates[i].LJ_sig*sim->reduced_sig );
	/* change energy units and length scales in molecule bond info */
	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		printf( "%s:\n", sim->molecule_templates[i].name );
		for( j=0; j<sim->molecule_templates[i].n_bonds; j++ )
			printf( "\tbond  %d: k %e, rest %e Ang)\n", j, sim->molecule_templates[i].bond_k[j], sim->molecule_templates[i].bond_eq[j] );
		for( j=0; j<sim->molecule_templates[i].n_angles; j++ )
			printf( "\tangle %d: k %e, rest %e rads\n", j, sim->molecule_templates[i].angle_k[j], sim->molecule_templates[i].angle_eq[j] );
	}
	
	PrintSim( sim );
	return sim;
}
void PrintSim( MCSim * sim )
{
	int i, j, k, l, m, n, o, p;
	
	/*
		*****************************************************************
		* DEBUG only - dump raw arrays to console.                      *
		*****************************************************************
	*/
	
	#ifdef DEBUG
		printf( "LJ table:\n" );
		for( l=0; l<sim->n_site_templates; l++ )
		{
			printf( "\t%s:\n", sim->site_templates[l].name );
			for( m=0; m<sim->n_site_templates; m++ )
			{
				printf( "\t\t%s: %.2e,%.2e\n", sim->site_templates[m].name, sim->LJ_eps_table[ (l*sim->n_site_templates) + m ], sim->LJ_sig_table[ (l*sim->n_site_templates) + m ] );
			}
		}

		printf( "Global site array:\n" );
		for( i=0; i<sim->n_sites; i++ )
		{
			j = sim->site_template_indices[i];
			printf( "\t%d: type %d (%s) : %f, %f, %f\n", i, j, sim->site_templates[j].name, sim->site_coords[i*3 +0], sim->site_coords[i*3 +1], sim->site_coords[i*3 +2] );
		}
	#endif
	

	/*
		*****************************************************************
		* Print system parameters to the console.                       *
		*****************************************************************
	*/
	printf( "\n---------- Sim info --------------------\n" );
	
	printf( "SYSTEM:\n" );
	printf( "\t n_sites: %d\n", sim->n_sites );
	printf( "\t T: %f\n", sim->T );
	printf( "\t e1: %f (%e)\n", sim->e1, sim->e1*E0 );
	printf( "\t delta_r: %f\n", sim->delta_r );
	printf( "\t LJ_cut: %f\n", sim->LJ_cut );
	printf( "\t LJ_corr: %d\n", sim->LJ_corr );
	printf( "\t cell: %.2e, %.2e, %.2e\n", sim->cell[0], sim->cell[1], sim->cell[2] );
	printf( "\t PBC: %d, %d, %d\n", sim->PBC[0], sim->PBC[1], sim->PBC[2] );
	printf( "\t ran1_seed: %ld\n", sim->ran1_seed );
	printf( "\t current_step, max_steps, save_every: %ld, %ld, %ld\n", sim->current_step, sim->max_steps, sim->save_every );
	printf( "\t accepted and rejected moves: %ld, %ld\n", sim->accepted, sim->rejected );
	printf( "\t Reduced epsilon, sigma: %e, %e\n", sim->reduced_eps, sim->reduced_sig );

	printf( "SITE TEMPLATES (%d)\n", sim->n_site_templates );
	for( i=0; i<sim->n_site_templates; i++ )
	{
		printf( "\t name: %s (%d), %d counts\n", sim->site_templates[i].name, i, sim->site_templates[i].count );
		printf( "\t\t q: %f\n", sim->site_templates[i].q );
		printf( "\t\t hard_sphere_radius: %f\n", sim->site_templates[i].hard_sphere_radius );
		printf( "\t\t LJ_eps, LJ_sig: %.2e, %.2e\n", sim->site_templates[i].LJ_eps, sim->site_templates[i].LJ_sig );
	}

	printf( "MOLECULE TEMPLATES (%d)\n", sim->n_molecule_templates );
	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		printf( "\t name: %s (%d)\n", sim->molecule_templates[i].name, i );
		printf( "\t\t count: %d\n", sim->molecule_templates[i].count );
		printf( "\t\t length: %d\n", sim->molecule_templates[i].length );
		for( j=0; j<sim->molecule_templates[i].length; j++ )
		{
			k = sim->molecule_templates[i].site_templates[j];
			printf( "\t\t\t %s (%d)\n", sim->site_templates[k].name, k );
		}
		printf( "\t\t n_bonds: %d\n", sim->molecule_templates[i].n_bonds );
		for( j=0; j<sim->molecule_templates[i].n_bonds; j++ )
		{
			k = sim->molecule_templates[i].bonds[j*2+0];
			l = sim->molecule_templates[i].bonds[j*2+1];
			m = sim->molecule_templates[i].site_templates[k];
			n = sim->molecule_templates[i].site_templates[l];
			printf( "\t\t\t %d -- %d (%s -- %s), %.2e : %.2e (%s)\n", k, l,
				sim->site_templates[m].name, sim->site_templates[n].name,
				sim->molecule_templates[i].bond_eq[j], sim->molecule_templates[i].bond_k[j],
				sim->molecule_templates[i].bond_rigid[j] ? "rigid" : "flexible" );
		}
		printf( "\t\t n_angles: %d\n", sim->molecule_templates[i].n_angles );
		for( j=0; j<sim->molecule_templates[i].n_angles; j++ )
		{
			k = sim->molecule_templates[i].angles[j*3+0];
			l = sim->molecule_templates[i].angles[j*3+1];
			m = sim->molecule_templates[i].angles[j*3+2];
			n = sim->molecule_templates[i].site_templates[k];
			o = sim->molecule_templates[i].site_templates[l];
			p = sim->molecule_templates[i].site_templates[m];
			printf( "\t\t\t %d -- %d -- %d (%s -- %s -- %s), %.2e : %.2e (%s)\n", k, l, m,
				sim->site_templates[n].name, sim->site_templates[o].name, sim->site_templates[p].name,
				sim->molecule_templates[i].angle_eq[j], sim->molecule_templates[i].angle_k[j],
				sim->molecule_templates[i].angle_rigid[j] ? "rigid" : "flexible" );
		}
		printf( "\t\t fast_bound table:\n" );
		for( j=0; j<sim->molecule_templates[i].length; j++ )
		{
			if( sim->molecule_templates[i].fast_bound[j][0] != -1 )
			{
				printf( "\t\t\t%d (%s)\n", j, sim->site_templates[ sim->molecule_templates[i].site_templates[j] ].name );
				k=0;
				while( sim->molecule_templates[i].fast_bound[j][k] != -1 && k < MAX_SITE_BONDS )
				{
					printf( "\t\t\t\t%d\n", sim->molecule_templates[i].fast_bound[j][k] );
					k++;
				}
			}
		}
	}
	
	printf( "CHARGED PLANES (%d)\n", sim->n_charged_plane_templates );
	for( i=0; i<sim->n_charged_plane_templates; i++ )
	{
		printf( "\t axis %d, position %f, sigma %f\n", sim->charged_plane_templates[i].axis, sim->charged_plane_templates[i].pos, sim->charged_plane_templates[i].sigma );
	}
	
	printf( "----------------------------------------\n\n" );	
}
void SaveMCSim( MCSim * sim, char * filename )
{
	int i, j;
	FILE * f;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( filename == NULL ) JERROR( "NULL filename passed" );
	#endif

	if( (f = fopen(filename,"w")) == NULL ) JERROR( "Unable to open sim output file" );

	fprintf( f, "system\n" );
		fprintf( f, "\tt %f\n", sim->T );
		fprintf( f, "\te1 %f\n", sim->e1 );
		fprintf( f, "\tdelta_r %f\n", sim->delta_r );
		fprintf( f, "\tLJ_cut %f\n", sim->LJ_cut );
		fprintf( f, "\tLJ_corr %d\n", sim->LJ_corr );
		fprintf( f, "\tx %f\n", sim->cell[0] );
		fprintf( f, "\ty %f\n", sim->cell[1] );
		fprintf( f, "\tz %f\n", sim->cell[2] );
		fprintf( f, "\tpbc_x %d\n", sim->PBC[0] );
		fprintf( f, "\tpbc_y %d\n", sim->PBC[1] );
		fprintf( f, "\tpbc_z %d\n", sim->PBC[2] );
		fprintf( f, "\tseed %ld\n", sim->ran1_seed );
		fprintf( f, "\tcurrent_step %ld\n", sim->current_step );
		fprintf( f, "\tmax_steps %ld\n", sim->max_steps );
		fprintf( f, "\tsave_every %ld\n", sim->save_every );
		fprintf( f, "\taccepted %ld\n", sim->accepted );
		fprintf( f, "\trejected %ld\n", sim->rejected );
	fprintf( f, "end\n" );

	fprintf( f, "\n" );

	for( i=0; i<sim->n_site_templates; i++ )
	{
		fprintf( f, "site\n" );
		fprintf( f, "\tname %s\n", sim->site_templates[i].name );
		fprintf( f, "\tq %f\n", sim->site_templates[i].q );
		fprintf( f, "\thard_sphere %f\n", sim->site_templates[i].hard_sphere_radius );
		fprintf( f, "\tlj_eps %e\n", sim->site_templates[i].LJ_eps );
		fprintf( f, "\tlj_sig %f\n", sim->site_templates[i].LJ_sig );
		fprintf( f, "end\n\n" );
	}

	for( i=0; i<sim->n_molecule_templates; i++ ) /* convert all bond and angle k to non-reduced on save */
	{
		fprintf( f, "molecule\n" );
		fprintf( f, "\tname %s\n", sim->molecule_templates[i].name );
		fprintf( f, "\tcount %d\n", sim->molecule_templates[i].count );
		for( j=0; j<sim->molecule_templates[i].length; j++ )
			fprintf( f, "\tsite %s\n", sim->site_templates[ sim->molecule_templates[i].site_templates[j] ].name );
		for( j=0; j<sim->molecule_templates[i].n_bonds; j++ )
		{
			fprintf( f, "\tbond %d %d %f %e %d\n", sim->molecule_templates[i].bonds[(j*2)+0]+1, sim->molecule_templates[i].bonds[(j*2)+1]+1, sim->molecule_templates[i].bond_eq[j], sim->molecule_templates[i].bond_k[j], sim->molecule_templates[i].bond_rigid[j] );
		}
		for( j=0; j<sim->molecule_templates[i].n_angles; j++ )
		{
			fprintf( f, "\tangle %d %d %d %f %e %d\n", sim->molecule_templates[i].angles[(j*3)+0]+1, sim->molecule_templates[i].angles[(j*3)+1]+1, sim->molecule_templates[i].angles[(j*3)+2]+1, sim->molecule_templates[i].angle_eq[j], sim->molecule_templates[i].angle_k[j], sim->molecule_templates[i].angle_rigid[j] );
		}
		fprintf( f, "end\n\n" );
	}
	
	for( i=0; i<sim->n_charged_plane_templates; i++ )
	{
		fprintf( f, "charged_plane\n" );
		fprintf( f, "\taxis %d\n", sim->charged_plane_templates[i].axis );
		fprintf( f, "\tpos %e\n", sim->charged_plane_templates[i].pos );
		fprintf( f, "\tsigma %e\n", sim->charged_plane_templates[i].sigma );
		fprintf( f, "end\n\n" );
	}
	
	/* add site info */
	fprintf( f, "coordinates\n" );
	for( i=0; i<sim->n_sites; i++ )
	{
		fprintf( f, "\t%s\t%f %f %f\n", sim->site_templates[ sim->site_template_indices[i] ].name, sim->site_coords[ (i*3) +0], sim->site_coords[ (i*3) +1], sim->site_coords[ (i*3) +2] );
	}
	fprintf( f, "end\n" );
	
	fclose( f );

}
