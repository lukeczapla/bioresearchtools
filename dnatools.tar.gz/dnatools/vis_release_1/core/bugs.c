#ifndef MC_INCLUDED

#include "mc.h"

char * bugs[] = {
	"Sqrt always evaluated for nonbonded interactions; could check for neutral sites before using cut^2 instead, but careful with hard sphere - if larger than LJ cutoff, would be ignored!",
	"Momentum transfer running average does not work - figure out why. Final S(x) distribution appears to be fine, though.",
	""
};

void PrintBugs()
{
	int i;

	printf( "\nKnown bugs and issues:\n" );
	for( i=0; strlen(bugs[i]) > 0; i++)
	{
		printf( "%d. %s\n", i, bugs[i] );
	}
	printf( "\n" );
}


#endif
