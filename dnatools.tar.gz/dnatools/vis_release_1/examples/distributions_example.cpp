#include "../core/mc.h"
#include "../util/distributions.h"

/*
	Produce a concentration profile for point ions between 2 impenetrable walls on the z axis.
	
	This uses the long ranged electrostatic energy correction calculated in the Distributions object;
	compare to the Poisson-Boltzmann predictions for the same system which do not include explicit ion-ion
	interactions.
*/

void test_distributions( int n, double x, double y, double z )
{
	int i, mol_type, mol_instance, site;
	double oldU, newU, deltaU;
	
	MCSim * sim;
	Distributions *d;
	
	sim = MakeEmptySim();
		AddSiteInfo( sim, "c1", 1.0, 0.0, 0.0, 1.0 );
		AddMoleculeInfo( sim, "m1", n );
			AddSiteToMolecule( sim, "m1", "c1" );
	InitialiseSim( sim, 300.0 );
	
	sim->cell[0] = x;
	sim->cell[1] = y;
	sim->cell[2] = z;
	
	sim->PBC[2] = 0; // switch off periodic boundaries on z axis
	
	sim->e1 = 78.3;
	sim->delta_r = 6.0;
	sim->max_steps = 2000000;
	
	PrintSim( sim );
	
	/*
		Create a distribution profile for all the component sites in the MCSim on the z axis.
		The block length is 500 samples, and we're using 3 bins per unit length.
	*/
	d = new Distributions( 2, 500, 3*sim->cell[2], sim );
	
	/*
		Randomly place sites
	*/
	for( i=0; i<sim->n_sites; i++ )
	{
		sim->site_coords[(i*3)+0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
		sim->site_coords[(i*3)+1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
		sim->site_coords[(i*3)+2] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[2];
	}
	
	/*
		Main MC loop
	*/
	for( sim->current_step=0; sim->current_step<sim->max_steps; sim->current_step++ )
	{
		/*
			Accumulate the current Site profiles.
		*/
		d->Accumulate( sim );
		
		mol_type = 0;
		mol_instance = (int) floor( ran1(&sim->ran1_seed) * sim->molecule_templates[mol_type].count );
		site = GetMoleculeStartSite( sim, mol_type, mol_instance );
				
		oldU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL ) + d->GetLREECorrection( sim, mol_type, mol_instance, NULL );

		PushMoleculeCoords( sim, mol_type, mol_instance );
		
		/*
			The molecules in this case are simply single sites, so it's easy to manipulate the
			coordinates  directly. We're just moving them about randomly in the simulation cell.
		*/
		sim->site_coords[(site*3) +0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
		sim->site_coords[(site*3) +1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
		sim->site_coords[(site*3) +2] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[2];

		newU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL ) + d->GetLREECorrection( sim, mol_type, mol_instance, NULL );
		
		deltaU = newU - oldU;
		if( deltaU < 0.0 | ran1(&sim->ran1_seed) < exp( -deltaU/(KB*sim->T) ) )
		{
			// accepted.
		}
		else
		{
			// rejected
			PopMoleculeCoords( sim, mol_type, mol_instance );
		}
		
		if( sim->current_step % 50000 == 0 )
		{
			printf( "Step %lu\n", sim->current_step );
			d->Save( "", sim ); // periodically write a concentration profile for all the Site types in the sim
		}
	}
	
	printf( "Ended on step %lu\n", sim->current_step );
	d->Save( "", sim );

	delete d;
	FreeSim( sim );
}

int main( int argc, char ** argv )
{
	/*
		These are designed to rproduce some internal data I had to check the long ranged correction
		and compare to a Poisson-Boltzmann distribution.
	*/

//	test_distributions( 40, 119.416, 119.416, 21.0 ); // rdf-713
//	test_distributions( 40, 37.763, 37.763, 21.0 ); // rdf-071
	test_distributions( 200, 84.440, 84.440, 21.0 ); // rdf-071-200
	exit( -1 );
	
	return 0;
}
