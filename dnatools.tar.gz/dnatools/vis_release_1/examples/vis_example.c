#include "../core/mc.h"

/*
	Short example of how to use the visualisation program.
	
	Rotate a linear molecule composed of 3 sites about random axis, while
	translating in random directions. We don't use explicit bonds or angles
	as we're just rotating and moving the entire molecule, so geometry is
	maintained automatically - see the self test examples.
	
	This assumes the visualisation program is listening on the same
	machine ("localhost" and "127.0.0.1" both give the local loopback
	interface) on the KRONENBOURG_PORT (1664). This also seems to be used
	by a program called NetView, so be careful and change if needed.
	
	Best to build this as "production", or you'll get constant socket
	output being printed to the console.
	
	Controls: Use the up and down arrows to zoom in and out, and move the mouse
	while holding down the left mouse button to rotate. Left and right arrow keys
	barrel roll the display.
*/
void VisExample()
{
	unsigned long i;
	double axis[3], delta[3];
	double translate_speed, rotate_speed;
	MCSim * sim;
	jsocket * js;

	sim = MakeEmptySim();
		AddSiteInfo( sim, "a", 0.0, 0.0, 0.0, 1.0 );
		AddSiteInfo( sim, "b", 0.0, 0.0, 0.0, 1.0 );
		AddSiteInfo( sim, "c", 0.0, 0.0, 0.0, 1.0 );

		AddMoleculeInfo( sim, "test molecule", 1 );
			AddSiteToMolecule( sim, "test molecule", "a" );
			AddSiteToMolecule( sim, "test molecule", "b" );
			AddSiteToMolecule( sim, "test molecule", "c" );

	InitialiseSim( sim, 298.0 );
	
	sim->cell[0] = 50.0;
	sim->cell[1] = 50.0;
	sim->cell[2] = 50.0;

	/*
		Initial site coords; whatever relative positions the sites have to one
		another will be preserved. Try making them further apart, or on a right angle etc.
	*/
	sim->site_coords[(0*3)+0] = -2.5;
	sim->site_coords[(0*3)+1] = -2.5;
	sim->site_coords[(0*3)+2] = 0.0;

	sim->site_coords[(1*3)+0] = 0.0;
	sim->site_coords[(1*3)+1] = 0.0;
	sim->site_coords[(1*3)+2] = 0.0;

	sim->site_coords[(2*3)+0] = 2.5;
	sim->site_coords[(2*3)+1] = 2.5;
	sim->site_coords[(2*3)+2] = 0.0;

	translate_speed = 0.5;
	rotate_speed = 0.1;

	i = 0;
	while( 1 )
	{
		/*
			Change movement direction and rotate axis every 500 iterations.
			This will also trigger on first iteration to set up initial dir, axis.
		*/
		if( i % 500 == 0 )
		{
			delta[0] = (ran1(&sim->ran1_seed)-0.5)*translate_speed;
			delta[1] = (ran1(&sim->ran1_seed)-0.5)*translate_speed;
			delta[2] = (ran1(&sim->ran1_seed)-0.5)*translate_speed;
			// Get rotation axis as unit vector uniformly distribution on surface of sphere.
			UniformSpherePoint( axis, &sim->ran1_seed );
		}

		TranslateMolecule( sim, 0, 0, delta );
		RotateMolecule( sim, 0, 0, axis, rotate_speed );

		usleep( 1000000 / 30 ); // roughly 30 fps update rate
		
		/*
			Note; this does not make any allowances for endian format; it simply writes the
			integer data to the socket, and assumes whatever's listening uses big endian or little
			endian integer format in the same manner as this computer. If you're mixing x86 and PPC
			architectures, for example, this will break!
			
			Don't alter the order the data are written; the visualisation program expects incoming
			data in a certain order or BAD THINGS might happen to how the simulation looks!
		*/
		js = GetJSocket( "localhost", KRONENBOURG_PORT, 0 );
		if( js != NULL )
		{
			// first, write the dimensions of the simulation cell
			WriteJSocket( js->socket, sim->cell, sizeof(double)*3 );
			// next, write the number of sites
			WriteJSocket( js->socket, &sim->n_sites, sizeof(int) );
			// we also need the site type array, so we can draw the sites in different colours to distinguish them
			WriteJSocket( js->socket, sim->site_template_indices, sizeof(int)*sim->n_sites );
			// finally, and most importantly, the coordinates of all the sites.
			WriteJSocket( js->socket, sim->site_coords, sizeof(double)*sim->n_sites*3 );
			FreeJSocket( js );
		}
		else
		{
			printf( "Unable to connect to visualisation port; is this because the visualisation program is using a different port? Has it been stopped? Was it ever running?\n" );
			exit( -1 );
		}
		
		i++;
	}
}

void VisExample2()
{
	int i, j, nsites;
	int site, molecule;
	double oldU, newU;
	MCSim * sim;
	jsocket * js;
	
	nsites = 10;

	sim = MakeEmptySim();
		AddSiteInfo( sim, "a", 0.0, 0.0, 0.0, 1.0 );
		AddSiteInfo( sim, "b", 0.0, 0.0, 0.0, 1.0 );
		
		sim->ran1_seed = -1;
		
		AddMoleculeInfo( sim, "test molecule", (int) floor( ran1(&sim->ran1_seed) * 10 ) );
		for( i=0; i<nsites; i++ )
		{
			j = (int) floor( ran1(&sim->ran1_seed) * sim->n_site_templates );
			AddSiteToMolecule( sim, "test molecule", sim->site_templates[j].name );
		}
		for( i=0; i<nsites-1; i++ ) AddBondToMolecule( sim, "test molecule", i+1, i+2, 3.0, 1e5, 0 );
		for( i=0; i<nsites-2; i++ ) AddAngleToMolecule( sim, "test molecule", i+1, i+2, i+3, M_PI, 1e5, 0 );
		
	InitialiseSim( sim, 298.0 );
	
	PrintSim( sim );

	sim->cell[0] = 15.0;
	sim->cell[1] = 15.0;
	sim->cell[2] = 30.0;

	/*
		Initial site coords; whatever relative positions the sites have to one
		another will be preserved. Try making them further apart, or on a right angle etc.
	*/
	for( molecule=0; molecule<sim->n_molecule_templates; molecule++ )
	{
		for( i=0; i<sim->molecule_templates[molecule].count; i++ )
		{
			oldU = (ran1( &sim->ran1_seed )-0.5) * sim->cell[0];
			newU = (ran1( &sim->ran1_seed )-0.5) * sim->cell[1];
		
			site = GetMoleculeStartSite( sim, molecule, i );
		
			for( j=site; j<site+sim->molecule_templates[molecule].length; j++ )
			{
				sim->site_coords[(j*3)+0] = oldU;
				sim->site_coords[(j*3)+1] = newU;
				sim->site_coords[(j*3)+2] = (-sim->cell[2]/2.0) + (j-site)*3.0;
			}
		}
	}

	i = 0;
	while( 1 )
	{
		sim->current_step++;
		
		molecule = (int) floor( ran1(&sim->ran1_seed) * sim->molecule_templates[0].count );
		site = GetMoleculeStartSite( sim, 0, molecule ) + (int) floor( ran1(&sim->ran1_seed) * sim->molecule_templates[0].length );
		
		oldU = GetMoleculeEnergy( sim, 0, molecule, NULL );
		PushMoleculeCoords( sim, 0, molecule );
		
		sim->site_coords[(site*3) + 0] += (ran1(&sim->ran1_seed)-0.5)*2.0;
		sim->site_coords[(site*3) + 1] += (ran1(&sim->ran1_seed)-0.5)*2.0;
		sim->site_coords[(site*3) + 2] += (ran1(&sim->ran1_seed)-0.5)*2.0;
		
		MIC( 1, &sim->site_coords[site*3], &sim->site_coords[site*3], sim->cell, sim->PBC );

		newU = GetMoleculeEnergy( sim, 0, molecule, NULL );
		
		/*
			Should we accept? Calculate weight and random number.
		*/
		if( newU < oldU || ran1(&sim->ran1_seed) < exp( -(newU-oldU)/(sim->T) ) )
		{
			sim->accepted++;
		}
		else
		{
			PopMoleculeCoords( sim, 0, molecule );
			sim->rejected++;
		}

		if( sim->current_step > 0 && sim->current_step % 10000 == 0 )
		{
			printf( "%lu, %lu\n", sim->accepted, sim->rejected );
			sim->accepted = 0;
			sim->rejected = 0;
			/*
				Note; this does not make any allowances for endian format; it simply writes the
				integer data to the socket, and assumes whatever's listening uses big endian or little
				endian integer format in the same manner as this computer. If you're mixing x86 and PPC
				architectures, for example, this will break!
			
				Don't alter the order the data are written; the visualisation program expects incoming
				data in a certain order or BAD THINGS might happen to how the simulation looks!
			*/
			js = GetJSocket( "localhost", KRONENBOURG_PORT, 0 );
			if( js != NULL )
			{
				// first, write the dimensions of the simulation cell
				WriteJSocket( js->socket, sim->cell, sizeof(double)*3 );
				// next, write the number of sites
				WriteJSocket( js->socket, &sim->n_sites, sizeof(int) );
				// we also need the site type array, so we can draw the sites in different colours to distinguish them
				WriteJSocket( js->socket, sim->site_template_indices, sizeof(int)*sim->n_sites );
				// finally, and most importantly, the coordinates of all the sites.
				WriteJSocket( js->socket, sim->site_coords, sizeof(double)*sim->n_sites*3 );
				FreeJSocket( js );
			}
		}
	}
}

int main( int argc, char ** argv )
{
	VisExample();
//	VisExample2();
	return 0;
}
