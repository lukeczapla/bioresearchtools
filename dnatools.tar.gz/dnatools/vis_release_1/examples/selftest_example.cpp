#include "../core/mc.h"

/*
	Generate a simple LJ sim with epsilon = 1.0 and sigma = 1.0.
*/
MCSim * MakeVanillaSim( double T, double rho, double x, double y, double z, int n_site_templates, int n_mol_types, int max_mol_length )
{
	MCSim * sim;
	int i;
	char temp[128];
	
	sim = MakeEmptySim();
		i = (int) floor(rho*(x*y*z));
		sim->n_sites = i;
		sim->max_sites = i;
		for( i=0; i<n_site_templates; i++ )
		{
			sprintf( temp, "site_%d", i );
			AddSiteInfo( sim, temp, 0.0, 0.0, NAV*KB*T, 1.0 );
		}
		for( i=0; i<n_mol_types; i++ )
		{
			sprintf( temp, "molecule_%d", i );
			if( i == 0 )
			{
				AddMoleculeInfo( sim, temp, sim->n_sites );
			}
			else
			{
				AddMoleculeInfo( sim, temp, 0 );
			}
			AddSiteToMolecule( sim, temp, sim->site_templates[i].name );
		}
	InitialiseSim( sim, T );
	
	sim->cell[0] = x;
	sim->cell[1] = y;
	sim->cell[2] = z;
	
	for( i=0; i<sim->n_sites; i++ )
	{
		sim->site_coords[(i*3)+0] = (ran1( &sim->ran1_seed )-0.5)*x;
		sim->site_coords[(i*3)+1] = (ran1( &sim->ran1_seed )-0.5)*y;
		sim->site_coords[(i*3)+2] = (ran1( &sim->ran1_seed )-0.5)*z;
	}

	return sim;
}

/*
	Should produce uniform profiles on x, y and z axes for density.
*/
void TestBins()
{
	double new_r[3];
	Bins * x_prof, * y_prof, * z_prof, * test;
	int site, i, nslices;
	MCSim * sim;
	
	printf( "Testing binning structures..." );

	sim = MakeVanillaSim( 1.0, 1.0, 5.0, 5.0, 5.0, 1, 1, 1 );
	if( sim == NULL ) JERROR( "Unable to make sim" );	
	
	sim->max_steps =   10000;
	sim->save_every =   1000;
	
	nslices = 10;

	x_prof = new Bins( 1, -sim->cell[0]/2.0, sim->cell[0]/2.0, (int) sim->cell[0]*nslices );
	y_prof = new Bins( 1, -sim->cell[1]/2.0, sim->cell[1]/2.0, (int) sim->cell[1]*nslices );
	z_prof = new Bins( 1, -sim->cell[2]/2.0, sim->cell[2]/2.0, (int) sim->cell[2]*nslices );

	for( sim->current_step = 0; sim->current_step < sim->max_steps; sim->current_step++ )
	{
		for( i=0; i<sim->n_sites; i++ )
		{
			x_prof->CoordAdd( &sim->site_coords[(i*3) +0], 1.0 );
			y_prof->CoordAdd( &sim->site_coords[(i*3) +1], 1.0 );
			z_prof->CoordAdd( &sim->site_coords[(i*3) +2], 1.0 );
		}

		// randomly select site to move.
		site = (int) floor( ran1( &sim->ran1_seed )*sim->n_sites );

		// attempt move
		new_r[0] = (ran1(&sim->ran1_seed)-0.5)*sim->cell[0];
		new_r[1] = (ran1(&sim->ran1_seed)-0.5)*sim->cell[1];
		new_r[2] = (ran1(&sim->ran1_seed)-0.5)*sim->cell[2];

		sim->site_coords[(site*3) +0] = new_r[0];
		sim->site_coords[(site*3) +1] = new_r[1];
		sim->site_coords[(site*3) +2] = new_r[2];
		
		if( sim->current_step > 0 && sim->current_step % sim->save_every == 0 )
		{
			x_prof->Save( "xdensity.dist", sim->cell[0]*sim->cell[1] );
			y_prof->Save( "ydensity.dist", sim->cell[0]*sim->cell[1] );
			z_prof->Save( "zdensity.dist", sim->cell[0]*sim->cell[1] );
		}
	}
	
	x_prof->Save( "xdensity.dist", 1.0 );
	y_prof->Save( "ydensity.dist", 1.0 );
	z_prof->Save( "zdensity.dist", 1.0 );
	
	// check z profile can be reloaded correctly from file
	test = new Bins( "zdensity.dist" );
	if( fabs(test->mins[0]-z_prof->mins[0]) > 1e-50 ) JERROR( "Reloaded profile has min value mismatch" );
	if( fabs(test->maxs[0]-z_prof->maxs[0]) > 1e-50 ) JERROR( "Reloaded profile has max value mismatch" );
	if( fabs(test->deltas[0]-z_prof->deltas[0]) > 1e-50 ) JERROR( "Reloaded profile has delta_r value mismatch" );
	if( test->total_nbins != z_prof->total_nbins ) JERROR( "Reloaded profile has n_bins value mismatch" );
	for( i=0; i<test->total_nbins; i++ )
	{
		if( fabs(test->accs[i]-z_prof->accs[i]) > 1e-50 ) JERROR( "Bin value mismatch" );
		if( test->acc_counts[i] != z_prof->acc_counts[i] ) JERROR( "Bin count mismatch" );
	}

	delete x_prof;
	delete y_prof;
	delete z_prof;
	delete test;
	
	FreeSim( sim );

	printf( "passed.\n\n" );
}



/*
	Check that the optimisations in the table info for LJ and separation work, and agree with the non-optimised versions.
*/
void TestTables()
{
	double store_r[10][3];
	double target_eps, target_sig, eps, sig;
	double tol = 1e-99;
	int site, mol_t, mol_i, offset, i, j;
	double * old_table;
	MCSim * sim;
	
	sim = MakeEmptySim();
	if( sim == NULL ) JERROR( "Unable to make sim" );
		AddSiteInfo( sim, "a", 0.5, 0.0, NAV*KB*298, 3.0 );
		AddSiteInfo( sim, "b", 1.0, 0.0, NAV*KB*298, 3.0 );
		
		AddMoleculeInfo( sim, "test", 1 );
			AddSiteToMolecule( sim, "test", "a" );

		AddMoleculeInfo( sim, "test2", 1 );
			AddSiteToMolecule( sim, "test", "b" );

	InitialiseSim( sim, 298.0 );

	// put some random coords in so we're not testing push an pop routines on a load of zeros
	for( i=0; i<sim->n_sites; i++ )
	{
		sim->site_coords[(i*3) +0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
		sim->site_coords[(i*3) +1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
		sim->site_coords[(i*3) +2] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[2];
	}

	printf( "Testing LJ parameter and stored coordinate tables; tolerance is %.2e ... ", tol );

	old_table = (double *)malloc( sizeof(double) * sim->max_sites * sim->max_sites );
	if( old_table == NULL ) JERROR( "Unable to allocate old table" );


	// test LJ table by cycling through all the possible site combinations, and check table vs explicit.
	for( i=0; i<sim->n_site_templates; i++ )
		for( j=i; j<sim->n_site_templates; j++ )
		{
			target_eps = 0.5*( sim->site_templates[i].LJ_eps + sim->site_templates[j].LJ_eps );
			target_sig = sqrt( sim->site_templates[i].LJ_sig * sim->site_templates[j].LJ_sig );

			eps = GetLJEpsFromTable( sim, i, j );
			sig = GetLJSigFromTable( sim, i, j );

			if( fabs(target_eps - eps) > tol )
			{
				printf( "target_eps: %e, eps: %e, abs_delta: %e\n", target_eps, eps, fabs(target_eps - eps) );
				JERROR( "LJ epsilon test failed" );
			}
			if( fabs(target_sig - sig) > tol ) JERROR( "LJ sigma test failed" );

			eps = GetLJEpsFromTable( sim, j, i );
			sig = GetLJSigFromTable( sim, j, i );

			if( fabs(target_eps - eps) > tol ) JERROR( "LJ epsilon test failed" );
			if( fabs(target_sig - sig) > tol ) JERROR( "LJ sigma test failed" );
		}


	// Move some molecules, test push and pop functions etc
	for( i=0; i<100; i++ )
	{
		mol_t = (int) floor( ran1(&sim->ran1_seed)*sim->n_molecule_templates );
		if( sim->molecule_templates[mol_t].count < 1 ) continue;
		mol_i = (int) floor( ran1(&sim->ran1_seed)*sim->molecule_templates[mol_t].count );
				
		// push seps
		PushMoleculeCoords( sim, mol_t, mol_i );

		// test pushed coords against actual
		offset = GetMoleculeStartSite( sim, mol_t, mol_i );
		for( j=0; j < sim->molecule_templates[mol_t].length; j++ )
		{
			if( sim->stored_coords[(j*3)+0] != sim->site_coords[((offset+j)*3)+0] ) JERROR( "PushMoleculeCoords() failed on x" );
			if( sim->stored_coords[(j*3)+1] != sim->site_coords[((offset+j)*3)+1] ) JERROR( "PushMoleculeCoords() failed on y" );
			if( sim->stored_coords[(j*3)+2] != sim->site_coords[((offset+j)*3)+2] ) JERROR( "PushMoleculeCoords() failed on z" );
		}
		
		j = 0;
		for( site=offset; site<offset+sim->molecule_templates[mol_t].length; site++ )
		{
			// store old site pos
			store_r[j][0] = sim->site_coords[(site*3) +0];
			store_r[j][1] = sim->site_coords[(site*3) +1];
			store_r[j][2] = sim->site_coords[(site*3) +2];
			// get new site pos
			sim->site_coords[(site*3) +0] = (ran1(&sim->ran1_seed)-0.5)*sim->cell[0];
			sim->site_coords[(site*3) +1] = (ran1(&sim->ran1_seed)-0.5)*sim->cell[1];
			sim->site_coords[(site*3) +2] = (ran1(&sim->ran1_seed)-0.5)*sim->cell[2];
			
			j++;
		}
				
		// at this stage, we know that push stores the correct molecule info.
		// all we now need to check is that the molecule pop routine works properly.
		PopMoleculeCoords( sim, mol_t, mol_i );
		
		// test restored coords against actual
		offset = GetMoleculeStartSite( sim, mol_t, mol_i );
		for( j=0; j < sim->molecule_templates[mol_t].length; j++ )
		{
			if( sim->site_coords[((offset+j)*3)+0] != store_r[j][0] ) JERROR( "PopMoleculeCoords() failed on x" );
			if( sim->site_coords[((offset+j)*3)+1] != store_r[j][1] ) JERROR( "PopMoleculeCoords() failed on x" );
			if( sim->site_coords[((offset+j)*3)+2] != store_r[j][2] ) JERROR( "PopMoleculeCoords() failed on x" );
		}
	}
	
	FreeSim( sim );
	printf( "passed.\n\n" );
}



/*
	Note; for sparsely populated systems, most of the molecule energy differences in this routine will come from the
	bonds and angles, so don't worry if that looks a bit strange.
	
	Important; if we move an entire molecule via rotate, translate etc then the energy change measured with GetMoleculeEnergy()
	before and after the move should tally closely with the energy change measured with GetTotalEnergy() before and after
	the move. This will not be the case with a single site energy, unless it's a single site molecule, as the energy change comes
	from the new positions of ALL the sites in the molecule, not just one!
*/
void TestPartialEnergyCorrection()
{
	double old_totalU, new_totalU, total_deltaU, old_molU, new_molU, mol_deltaU, old_siteU, new_siteU, site_deltaU;
	int site, mol_type, mol_instance;
	
	int i, j, start, length, count;
	double bond_len;

	double pos[3], dir[3];
	
	double largest, tolerance = 1e-10;
	
	MCSim * sim;
	
	/*
		Create sim of small polymers. Doesn't use LJ potential,
		as you can get unlucky and move something right into the extremely
		repulsive region, and this can mess with the comparison of the
		relative energies, when in practice they're actually perfectly fine and comparable!
	*/
	length = 10;
	count = 5;
	bond_len = 3.0;
	sim = MakeEmptySim();
		AddSiteInfo( sim, "a",  1.0, 0.0, 0.0, 1.0 );
		AddSiteInfo( sim, "b", -1.0, 0.0, 0.0, 1.0 );

		AddMoleculeInfo( sim, "polymer", count );
		for( i=0; i<length; i++ )
		{
			j = (int) floor( ran1(&sim->ran1_seed) * sim->n_site_templates );
			AddSiteToMolecule( sim, "polymer", sim->site_templates[j].name );
		}
		for( i=0; i<length; i++ )
		{
			if( i < length-1 ) AddBondToMolecule( sim, "polymer", i+1, i+2, bond_len, 1e3, 0 );
			if( i < length-2 ) AddAngleToMolecule( sim, "polymer", i+1, i+2, i+3, M_PI, 1e3, 0 );
		}
	InitialiseSim( sim, 298.0 );

	sim->e1 = 78.3;

	sim->cell[0] = 25.0;
	sim->cell[1] = 25.0;
	sim->cell[2] = 50.0;
	
	/*
		Place polymers in random straight lines
	*/
	for( i=0; i<count; i++ )
	{
		start = GetMoleculeStartSite( sim, 0, i );
		
		pos[0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
		pos[1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
		pos[2] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[2];

		UniformSpherePoint( dir, &sim->ran1_seed );
		
		dir[0] *= bond_len;
		dir[1] *= bond_len;
		dir[2] *= bond_len;
		
		for( j=0; j<length; j++ )
		{
			sim->site_coords[ (start+j)*3 + 0] = pos[0];
			sim->site_coords[ (start+j)*3 + 1] = pos[1];
			sim->site_coords[ (start+j)*3 + 2] = pos[2];
			
			pos[0] += dir[0];
			pos[1] += dir[1];
			pos[2] += dir[2];
		}
	}
	MIC( sim->n_sites, sim->site_coords, sim->site_coords, sim->cell, sim->PBC );
	
	printf( "Testing partial energy corrections; relative tolerance is %.2e ... ", tolerance );
	largest = 0.0;

	/*
		Move some sites around; check that the energy difference from total sim, molecule and site itself tally up.
	*/
	for( i=0; i<sim->n_sites*10; i++ )
	{
		site = (int) floor( ran1(&sim->ran1_seed) * sim->n_sites );
		GetParentMolecule( sim, site, &mol_type, &mol_instance );
		
		// get original energies
		old_totalU = GetTotalEnergy( sim );
		old_molU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL );
		old_siteU = GetSiteEnergy( sim, site );
		
		// move the site a little bit, and ensure it's wrapped.
		sim->site_coords[(site*3) + 0] += ran1(&sim->ran1_seed) * 10.0;
		sim->site_coords[(site*3) + 1] += ran1(&sim->ran1_seed) * 10.0;
		sim->site_coords[(site*3) + 2] += ran1(&sim->ran1_seed) * 10.0;
		MIC( 1, &sim->site_coords[site*3], &sim->site_coords[site*3], sim->cell, sim->PBC );

		// get new energies
		new_totalU = GetTotalEnergy( sim );
		new_molU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL );
		new_siteU = GetSiteEnergy( sim, site );
		
		// deltas
		total_deltaU = new_totalU - old_totalU;
		mol_deltaU   = new_molU   - old_molU;
		site_deltaU  = new_siteU  - old_siteU;
		
		if( fabs( 1.0 - fabs(mol_deltaU/total_deltaU) ) > tolerance || fabs( 1.0 - fabs(site_deltaU/total_deltaU) ) > tolerance )
		{
			printf( "\nIteration %d, %d sites:\n", i, sim->n_sites );
			
			printf( "Old total U: %.10e\n", old_totalU );
			printf( "\told molecule U: %.10e\n", old_molU );
			printf( "\told site U: %.10e\n", old_siteU );
			
			printf( "New total U: %.10e\n", new_totalU );
			printf( "\tnew molecule U: %.10e\n", new_molU );
			printf( "\tnew site U: %.10e\n", new_siteU );
			
			printf( "Total delta U: %.10e\n", total_deltaU );
			printf( "\tmolecule delta U: %.10e\n", mol_deltaU );
			printf( "\tsite delta U: %.10e\n", site_deltaU );
			
			
			printf( "Molecule relative difference: %.10e, tol %.10e\n", fabs( 1.0 - fabs(mol_deltaU/total_deltaU) ), tolerance );
			printf( "Site relative difference: %.10e, tol %.10e\n", fabs( 1.0 - fabs(site_deltaU/total_deltaU) ), tolerance );
			JERROR( "Molecule partial energy difference test failed" );
		}
		
		if( fabs( 1.0 - fabs(mol_deltaU/total_deltaU) ) > largest ) largest = fabs( 1.0 - fabs(mol_deltaU/total_deltaU) );
		if( fabs( 1.0 - fabs(site_deltaU/total_deltaU) ) > largest ) largest = fabs( 1.0 - fabs(site_deltaU/total_deltaU) );
	}

	printf( "passed; largest relative difference was %e\n\n", largest );
	FreeSim( sim );
}


/*
	Generate a probability distribution for bond and angle values.
*/
void TestBondsAndAngles()
{
	int site;
	double oldU, newU, l12, l23, theta;
	double r12[3], r23[3];
	Bins * bond_prof, * angle_prof;
	MCSim * sim;

	sim = MakeEmptySim();
		AddSiteInfo( sim, "a", 0.0, 0.0, 0.0, 1.0 );
		AddSiteInfo( sim, "b", 0.0, 0.0, 0.0, 1.0 );

		AddMoleculeInfo( sim, "test", 1 );
			AddSiteToMolecule( sim, "test", "a" );
			AddSiteToMolecule( sim, "test", "b" );
			AddSiteToMolecule( sim, "test", "a" );

			AddBondToMolecule( sim, "test", 1, 2, 3.0, 500e3, 0 );
			AddBondToMolecule( sim, "test", 2, 3, 3.0, 500e3, 0 );

			AddAngleToMolecule( sim, "test", 1, 2, 3, M_PI/2.0, 100e3, 0 );
	InitialiseSim( sim, 298.0 );
	
	sim->cell[0] = 25.0;
	sim->cell[1] = 25.0;
	sim->cell[2] = 25.0;

	sim->delta_r = 0.5;

	sim->max_steps =    2000000;
	sim->save_every =    500000;
	
	/*
		Initial coords for the molecule sites
	*/
	sim->site_coords[(0*3)+0] = -2.5;
	sim->site_coords[(0*3)+1] = 0.0;
	sim->site_coords[(0*3)+2] = 0.0;

	sim->site_coords[(1*3)+0] = 0.0;
	sim->site_coords[(1*3)+1] = 0.0;
	sim->site_coords[(1*3)+2] = 0.0;

	sim->site_coords[(2*3)+0] = 2.5;
	sim->site_coords[(2*3)+1] = 0.0;
	sim->site_coords[(2*3)+2] = 0.0;

	bond_prof = new Bins( 1, 2.0, 4.0, 250 );
	angle_prof = new Bins( 1, 0.0, M_PI+1e-10, 250 );
	
	printf( "Generating bond and angle distributions ...\n" );

	/*
		Main MC loop
	*/
	for( sim->current_step = 0; sim->current_step < sim->max_steps; sim->current_step++ )
	{
		/*
			Add current bonds and angles to the distributions.
		*/
		l12 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[0*3], &sim->site_coords[1*3], r12, sim->cell, sim->PBC ) );
		l23 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[2*3], &sim->site_coords[1*3], r23, sim->cell, sim->PBC ) );

		bond_prof->CoordAdd( &l12, 1.0 );
		bond_prof->CoordAdd( &l23, 1.0 );

		theta = acos( ( r12[0]*r23[0] + r12[1]*r23[1] + r12[2]*r23[2] ) / (l12*l23) );
		angle_prof->CoordAdd( &theta, 1.0 );
		
		/*
			Calculate a site to move and the delta; store old positions
		*/
		site = (int) floor(ran1( &sim->ran1_seed )*sim->n_sites);
		oldU = GetTotalEnergy( sim );
		PushSiteCoords( sim, site );

		sim->site_coords[(site*3)+0] += (ran1(&sim->ran1_seed)-0.5)*sim->delta_r;
		sim->site_coords[(site*3)+1] += (ran1(&sim->ran1_seed)-0.5)*sim->delta_r;
		sim->site_coords[(site*3)+2] += (ran1(&sim->ran1_seed)-0.5)*sim->delta_r;
		
		newU = GetTotalEnergy( sim );
		
		/*
			Save if we need to
		*/
		if( sim->current_step > 0 && sim->current_step % sim->save_every == 0 )
		{
			printf( "step %ld of %ld (%.0f%%);\n", sim->current_step, sim->max_steps, ((float)sim->current_step/sim->max_steps)*100 );
			printf("\taccepted %ld (%.0f%%) rejected %ld (%.0f%%)\n", sim->accepted, ((float)sim->accepted/sim->current_step)*100, sim->rejected, ((float)sim->rejected/sim->current_step)*100 );
		}

		if( newU < oldU || ran1(&sim->ran1_seed) < exp( -(newU-oldU)/(KB*sim->T) ) )
		{
			sim->accepted++;
			continue;
		}
		else
		{
			// rejected; restore old positions, and sep entries where needed.
			sim->rejected++;
			PopSiteCoords( sim, site );
		}
	}
	
	/*
		Normalise profiles
	*/
	oldU = 0.0;
	newU = 0.0;
	for( site=0; site<bond_prof->total_nbins; site++ )
	{
		oldU += bond_prof->accs[site];
		newU += angle_prof->accs[site];
	}
	for( site=0; site<bond_prof->total_nbins; site++ )
	{
		bond_prof->accs[site] /= oldU;
		angle_prof->accs[site] /= oldU;
	}
	
	bond_prof->Save( "bonds.dist", 1.0 );
	angle_prof->Save( "angles.dist", 1.0 );

	delete bond_prof;
	delete angle_prof;

	FreeSim( sim );

	printf( "passed.\n\n" );
}
void TestNonbonded( MCSim * sim, double max_prof_extent, int nslices, char * output_profile )
{
	int i, j, site;
	double oldU, newU, weight, temp[3];
	double old_r, new_r;
	Bins * prof;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "Null sim pointer passed" );
	#endif

	prof = new Bins( 1, 0.0, max_prof_extent, nslices );
	
	/*
		Setup; get original energy, and populate separation array where necessary.
		RIGGED TO ONLY ACT ON ONE AXIS AND COORDS RIGGED AT START TOO!
	*/
	sim->site_coords[(0*3)+0] = -3.0;
	sim->site_coords[(0*3)+1] = 0.0;
	sim->site_coords[(0*3)+2] = 0.0;

	sim->site_coords[(1*3)+0] = 3.0;
	sim->site_coords[(1*3)+1] = 0.0;
	sim->site_coords[(1*3)+2] = 0.0;
	
	oldU = GetTotalEnergy( sim );
	
	for( sim->current_step = 0; sim->current_step < sim->max_steps; sim->current_step++ )
	{
		/*
			Add previous separations to the distributions
		*/
		for( i=0; i<sim->n_sites-1; i++ )
			for( j=i+1; j<sim->n_sites; j++ )
			{
				weight = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[i*3], &sim->site_coords[j*3], temp, sim->cell, sim->PBC ) );
				prof->CoordAdd( &weight, 1.0 );
			}
		
		/*
			Calculate a site to move and the delta; store old positions
		*/
		site = (int) floor(ran1( &sim->ran1_seed )*sim->n_sites);

		old_r = sim->site_coords[(site*3)+0];
		new_r = (ran1( &sim->ran1_seed )-0.5)*sim->cell[0];
		sim->site_coords[(site*3)+0] = new_r;
		
		/*
			Calculate new energy
		*/
		newU = GetTotalEnergy( sim );

		/*
			Save if we need to
		*/
		if( sim->current_step != 0 && sim->current_step % sim->save_every == 0 )
		{
			printf( "step %ld of %ld (%.0f%%);\n", sim->current_step, sim->max_steps, ((float)sim->current_step/sim->max_steps)*100 );
			printf("\taccepted %ld (%.0f%%) rejected %ld (%.0f%%)\n", sim->accepted, ((float)sim->accepted/sim->current_step)*100, sim->rejected, ((float)sim->rejected/sim->current_step)*100 );

			// check acceptance rate; change if needed
			if( (double)sim->accepted/sim->current_step > 0.5 ) sim->delta_r *= 1.5;
			else sim->delta_r *= 0.5;
		}
		
		/*
			Should we accept? Calculate weight and random number.
		*/
		if( newU < oldU || ran1(&sim->ran1_seed) < exp( -(newU-oldU)/(KB*sim->T) ) )
		{
			sim->accepted++;
			oldU = newU;
			continue;
		}
		else
		{
			// rejected; restore old positions, and sep entries where needed.
			sim->rejected++;
			sim->site_coords[(site*3)+0] = old_r;
		}
	}

	/*
		Normalise profiles
	*/
	oldU = 0.0;
	for( site=0; site<prof->total_nbins; site++ ) oldU += prof->accs[site];
	for( site=0; site<prof->total_nbins; site++ ) prof->accs[site] /= oldU;

	prof->Save( output_profile, 1.0 );

	delete prof;
}
void TestInfWallCoulomb()
{
	int site;
	double oldU, newU;
	double new_r;
	Bins * prof;
	MCSim * sim;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "Null sim pointer passed" );
	#endif

	printf( "Generating charged plane distribution...\n" );

	sim = MakeEmptySim();
		AddSiteInfo( sim, "a", 0.5, 0.0, 0.0, 1.0 );
		AddMoleculeInfo( sim, "test", 1 );
			AddSiteToMolecule( sim, "test", "a" );
		AddChargedPlaneInfo( sim, 0, -500.0, 1e-7 );
	InitialiseSim( sim, 298.0 );

	sim->cell[0] = 1000.0;
	sim->cell[1] = 25.0;
	sim->cell[2] = 25.0;
	
	sim->PBC[0] = 0; // SWITCH OFF X PERIODIC BOUNDARY!
	
	sim->max_steps  =   2000000;
	sim->save_every =    500000;
	
	prof = new Bins( 1, 0.0, sim->cell[0], (int)sim->cell[0]/10 );
	
	/*
		Setup; get original energy, and populate separation array where necessary.
		RIGGED TO ONLY ACT ON ONE AXIS AND COORDS RIGGED AT START TOO!
	*/
	sim->site_coords[(0*3)+0] = -3.0;
	sim->site_coords[(0*3)+1] = 0.0;
	sim->site_coords[(0*3)+2] = 0.0;
	
	for( sim->current_step = 0; sim->current_step < sim->max_steps; sim->current_step++ )
	{
		/*
			Add current separations to the distribution
		*/
		new_r = fabs( sim->site_coords[(0*3)+0] - -500.0 );
		prof->CoordAdd( &new_r, 1.0 );
		
		/*
			Calculate a site to move and the delta; store old position
		*/
		site = (int) floor(ran1( &sim->ran1_seed )*sim->n_sites);
		oldU = GetTotalEnergy( sim );
		PushSiteCoords( sim, site );

		new_r = (ran1( &sim->ran1_seed )-0.5)*sim->cell[0];
		sim->site_coords[(site*3) +0] = new_r;
		
		/*
			Calculate new energy; in this case, also ensure reject of move where too close to wall
		*/
		if( new_r < -450.0 )
			newU = HUGE_VAL;
		else
			newU = GetTotalEnergy( sim );

		/*
			Save if we need to
		*/
		if( sim->current_step != 0 && sim->current_step % sim->save_every == 0 )
		{
			printf( "step %ld of %ld (%.0f%%);\n", sim->current_step, sim->max_steps, ((float)sim->current_step/sim->max_steps)*100 );
			printf("\taccepted %ld (%.0f%%) rejected %ld (%.0f%%)\n", sim->accepted, ((float)sim->accepted/sim->current_step)*100, sim->rejected, ((float)sim->rejected/sim->current_step)*100 );
		}
		
		/*
			Should we accept? Calculate weight and random number.
		*/
		if( newU < oldU || ran1(&sim->ran1_seed) < exp( -(newU-oldU)/(KB*sim->T) ) )
		{
			sim->accepted++;
		}
		else
		{
			PopSiteCoords( sim, site ); // restore old position
			sim->rejected++;
		}
	}

	/*
		Normalise profiles
	*/
	oldU = 0.0;
	for( site=0; site<prof->total_nbins; site++ ) oldU += prof->accs[site];
	for( site=0; site<prof->total_nbins; site++ ) prof->accs[site] /= oldU;

	prof->Save( "qwi.dist", sim->cell[0]*sim->cell[1] );
	delete prof;
	
	FreeSim( sim );
	printf( "done.\n\n" );
}

/*
	Attempts to test rotation and translation by moving and rotating the molecule in random
	directions for random periods of time.
	
	Note that we don't actually specify any bond or angle information; as all we're doing is
	rotating and translating the entire molecule, the geometry should be preserved automatically.
	
	This is tested in the code below.
*/
void TestRotation()
{
	unsigned long i;
	double axis[3], dir[3], sep[3], r1, r2, r3;
	MCSim * sim;

	printf( "Testing rotate functionality ...\n" );

	r1 = 25.0;
	sim = MakeEmptySim();
		AddSiteInfo( sim, "1", 0.0, 0.0, 0.0, 1.0 );
		AddSiteInfo( sim, "2", 0.0, 0.0, 0.0, 1.0 );

		AddMoleculeInfo( sim, "m", 1 );
			AddSiteToMolecule( sim, "m", "1" );
			AddSiteToMolecule( sim, "m", "2" );
			AddSiteToMolecule( sim, "m", "1" );

	InitialiseSim( sim, 298.0 );
	sim->cell[0] = r1;
	sim->cell[1] = r1;
	sim->cell[2] = r1;

	sim->site_coords[(0*3)+0] = -2.5;
	sim->site_coords[(0*3)+1] = -2.5;
	sim->site_coords[(0*3)+2] = 0.0;

	sim->site_coords[(1*3)+0] = 0.0;
	sim->site_coords[(1*3)+1] = 0.0;
	sim->site_coords[(1*3)+2] = 0.0;

	sim->site_coords[(2*3)+0] = 2.5;
	sim->site_coords[(2*3)+1] = 2.5;
	sim->site_coords[(2*3)+2] = 0.0;

	i = 0;
	while( 1 )
	{
		// change movement direction and rotate axis every 500 iterations.
		if( i % 500 == 0 )
		{
			dir[0] = (ran1(&sim->ran1_seed)-0.5)*0.1;
			dir[1] = (ran1(&sim->ran1_seed)-0.5)*0.1;
			dir[2] = (ran1(&sim->ran1_seed)-0.5)*0.1;
			// get rotation axis as unit vector uniformly distribution on surface of sphere.
			UniformSpherePoint( axis, &sim->ran1_seed );
		}

		TranslateMolecule( sim, 0, 0, dir );
		RotateMolecule( sim, 0, 0, axis, 0.01 );

		/*
			Check that the molecule geometry is being conserved.
		*/
		r1 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[(0*3)], &sim->site_coords[(1*3)], sep, sim->cell, sim->PBC ) );
		if( fabs(r1 - sqrt(sep[0]*sep[0] + sep[1]*sep[1] + sep[2]*sep[2])) > 1e-5 )
		{
			printf( "\t%.10e != %.10e\n", r1, sqrt( sep[0]*sep[0] + sep[1]*sep[1] + sep[2]*sep[2] ) );
			exit( -1 );
		}
		r2 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[(1*3)], &sim->site_coords[(2*3)], sep, sim->cell, sim->PBC ) );
		if( fabs(r2 - sqrt(sep[0]*sep[0] + sep[1]*sep[1] + sep[2]*sep[2])) > 1e-5 )
		{
			printf( "\t%.10e != %.10e\n", r2, sqrt( sep[0]*sep[0] + sep[1]*sep[1] + sep[2]*sep[2] ) );
			exit( -1 );
		}
		r3 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[(0*3)], &sim->site_coords[(2*3)], sep, sim->cell, sim->PBC ) );
		if( fabs(r3 - sqrt(sep[0]*sep[0] + sep[1]*sep[1] + sep[2]*sep[2])) > 1e-5 )
		{
			printf( "\t%.10e != %.10e\n", r3, sqrt( sep[0]*sep[0] + sep[1]*sep[1] + sep[2]*sep[2] ) );
			exit( -1 );
		}
		
		/*
			Print spearations lengths every few iterations so the user has some feedback; these
			values should not change!
		*/
		if( i > 0 && i % 500000 == 0 )
		{
			printf( "Step %lu:\n", i );

			printf( "\t1->2 : %e\n", r1 );
			printf( "\t2->3 : %e\n", r2 );
			printf( "\t1->3 : %e\n", r3 );
		}

//		if( i > ULONG_MAX-1 ) break; // ie, previously tested to an absurd number of iterations and geometry correctly preserved!
		if( i > 2000000 ) break;

		++i;
	}

	printf( "passed.\n\n" );
}


void _testgcPrint( MCSim * sim, int * site_counts, int * molecule_counts )
{
	int i, j, k, site_type, start_site;

	printf( "Site counts:\n\tname: from MCSim internal data, from tracking arrays\n" );
	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		printf( "\t%s: %d, %d\n", sim->site_templates[i].name, sim->site_templates[i].count, site_counts[i] );
	}
	

	printf( "Actual system: %d sites (max %d)\n", sim->n_sites, sim->max_sites );
	start_site = 0;
	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		printf( "\t%s: %d x %d\n", sim->molecule_templates[i].name, sim->molecule_templates[i].count, sim->molecule_templates[i].length );
		for( j=0; j<sim->molecule_templates[i].count; j++ )
		{
			for( k=0; k<sim->molecule_templates[i].length; k++ )
			{
				site_type = sim->site_template_indices[start_site+k];
				printf( "%d\t%s %d (%s %d)\n",	start_site+k, sim->site_templates[site_type].name,
				 																	site_type,
																					sim->site_templates[ sim->molecule_templates[i].site_templates[k] ].name,
																					sim->molecule_templates[i].site_templates[k] );
			}
			start_site += sim->molecule_templates[i].length;
		}
	}



	printf( "Expected system:\n" );
	start_site = 0;
	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		printf( "\t%s: %d x %d\n", sim->molecule_templates[i].name, molecule_counts[i], sim->molecule_templates[i].length );
		for( j=0; j<molecule_counts[i]; j++ )
		{
			for( k=0; k<sim->molecule_templates[i].length; k++ )
			{
				site_type = sim->molecule_templates[i].site_templates[k];
				printf( "%d\t%s %d\n", start_site+k, sim->site_templates[site_type].name, site_type );
			}
			start_site += sim->molecule_templates[i].length;
		}
	}
}
/*
	Test the grand canonical MC abilities of the sim code.
	
	Basic idea is to maintain a parallel set of molecule counts and site type indices as we randomly add and remove
	molecules from the simulation.
	This allows us to test the resulting simulation data against what we think it should be, and bail on errors.
	
	We use two static arrays;	"coords" used to store randomly generated molecule coords when we attempt to add.
								"types" should shadow the sim->site_template_indices array.
	
	The function will stop where the test arrays are too small; this shouldn't really happen without an insanely
	long test simulation, as these arrays are large enough for a density of 1000 of the largest molecules per
	square unit, which is nuts.
*/
void TestGCFunctionality()
{
	MCSim * sim;
	int mol_counts[MAX_MOLECULE_TEMPLATES], mol_max_counts[MAX_MOLECULE_TEMPLATES], mol_min_counts[MAX_MOLECULE_TEMPLATES];
	int site_counts[MAX_MOLECULE_TEMPLATES];
	double * coords;
	int gc_loop, i, j, max_site_count;
	int number_added, number_removed;
	int molecule_type, molecule_instance;
	
	printf( "Testing grand canonical functionality ... \n" );

	/*
		Test sim setup.
	*/
	sim = MakeEmptySim();
		AddSiteInfo( sim, "site1", 0.0, 0.0, NAV*KB*298.0, 1.0 );
		AddSiteInfo( sim, "site2", 0.0, 0.0, NAV*KB*298.0, 1.0 );
		AddSiteInfo( sim, "site3", 0.0, 0.0, NAV*KB*298.0, 1.0 );
		AddSiteInfo( sim, "site4", 0.0, 0.0, NAV*KB*298.0, 1.0 );
		
		AddMoleculeInfo( sim, "molecule1", 10 );
			AddSiteToMolecule( sim, "molecule1", "site1" );
			AddSiteToMolecule( sim, "molecule1", "site1" );

		AddMoleculeInfo( sim, "molecule2", 10 );
			AddSiteToMolecule( sim, "molecule2", "site2" );

		AddMoleculeInfo( sim, "molecule3", 10 );
			AddSiteToMolecule( sim, "molecule3", "site3" );
			AddSiteToMolecule( sim, "molecule3", "site3" );
			AddSiteToMolecule( sim, "molecule3", "site3" );

		AddMoleculeInfo( sim, "molecule4", 10 );
			AddSiteToMolecule( sim, "molecule4", "site4" );

	InitialiseSim( sim, 298.0 );
	sim->cell[0] = 10.0;
	sim->cell[1] = 10.0;
	sim->cell[2] = 10.0;
	sim->LJ_cut = 5.0;
	sim->T = 2.0;

	/*
		Get largest molecule type, and allocate an array sufficient for 1000 of them
		per cubic unit volume. Also allocate the coords array for any new molecules
		to be added with.
	*/
	for( i=0; i<sim->n_site_templates; i++ )
	{
		site_counts[i] = sim->site_templates[i].count;
	}
	j = 0; // max molecule length
	for( i=0; i<sim->n_molecule_templates; i++ )
	{
		if( sim->molecule_templates[i].length > j ) j = sim->molecule_templates[i].length;
		mol_counts[i] = sim->molecule_templates[i].count;
		mol_max_counts[i] = sim->molecule_templates[i].count;
		mol_min_counts[i] = sim->molecule_templates[i].count;
	}
	max_site_count = (int) (sim->cell[0] * sim->cell[0] * sim->cell[0] * 1000 * j); // max number of sites according to above criteria
	coords = (double *)malloc( sizeof(double) * j );
	if( coords == NULL )JERROR( "Unable to allocate coords" );
	
	number_added = 0;
	number_removed = 0;
	
	for( gc_loop = 1; gc_loop <= 500000; gc_loop++ )
	{
		/*
			Add a molecule
		*/
		if( ran1(&sim->ran1_seed) < 0.5 )
		{
			molecule_type = (int) floor( ran1(&sim->ran1_seed) * sim->n_molecule_templates );
			AddMoleculeToSim( sim, molecule_type, coords );
			
			// update tracking arrays
			for( i=0; i<sim->molecule_templates[molecule_type].length; i++ )
			{
				site_counts[ sim->molecule_templates[molecule_type].site_templates[i] ]++;
			}
			mol_counts[molecule_type]++;
			if( mol_counts[molecule_type] > mol_max_counts[molecule_type] ) mol_max_counts[molecule_type] = mol_counts[molecule_type];

			number_added++;
		}
		/*
			Remove a molecule
		*/
		else
		{
			molecule_type = (int) floor( ran1(&sim->ran1_seed) * sim->n_molecule_templates );
			molecule_instance = (int) floor( ran1(&sim->ran1_seed) * sim->molecule_templates[molecule_type].count );
			if( sim->molecule_templates[molecule_type].count < 1 ) continue;
			RemoveMoleculeFromSim( sim, molecule_type, molecule_instance );

			// update tracking arrays
			for( i=0; i<sim->molecule_templates[molecule_type].length; i++ )
			{
				site_counts[ sim->molecule_templates[molecule_type].site_templates[i] ]--;
			}
			mol_counts[molecule_type]--;
			if( mol_counts[molecule_type] < mol_min_counts[molecule_type] ) mol_min_counts[molecule_type] = mol_counts[molecule_type];

			number_removed++;
		}
		
		/*
			Check data we explicitly calculate against the internal system data; this is a test of
			self consistency in the AddMoleculeToSim() and RemoveMoleculeFromSim() routines.
		*/
		for( i=0; i<sim->n_site_templates; i++ ) // site counts shoudl match up
		{
			if( site_counts[i] != sim->site_templates[i].count )
			{
				_testgcPrint( sim, site_counts, mol_counts );
				printf( "For site type %d:\n", i );
				JERROR( "Bad site counts" );
			}
		}
		for( i=0; i<sim->n_molecule_templates; i++ ) // molecule counts should match up
		{
			if( mol_counts[i] != sim->molecule_templates[i].count )
			{
				_testgcPrint( sim, site_counts, mol_counts );
				printf( "For molecule type %d:\n", i );
				JERROR( "Bad molecule counts" );
			}
		}
		/*
			If we have correct site and molecule counts, in the correct order, the only thing left to check is the global sim->site_template_indices[] array.
			Check it against the internal molecule data; we could do this globally, and get rid of the sim->site_template_indices[] array altogether, but that
			would be very slow when we need to quickly check site types in nonbonded interactions etc.
		*/
		j = 0;
		for( molecule_type = 0; molecule_type < sim->n_molecule_templates; molecule_type++ ) // site type array should follow the info in the molecule entries.
		{
			for( molecule_instance = 0; molecule_instance < sim->molecule_templates[molecule_type].count; molecule_instance++ )
			{
				for( i=0; i<sim->molecule_templates[molecule_type].length; i++ )
				{
					if( sim->site_template_indices[j] != sim->molecule_templates[molecule_type].site_templates[i] )
					{
						_testgcPrint( sim, site_counts, mol_counts );
						printf( "For site %d:\n", j );
						JERROR( "Bad site type index" );
					}
					j++;
				}
			}
			
		}
		
		/*
			Print some info every now and again.
		*/
		if( gc_loop % 100000 == 0 )
		{
			printf( "Step %d:\n", gc_loop );
			printf( "\t%d sites of a maximum of %d\n", sim->n_sites, sim->max_sites );
			for( i=0; i<sim->n_molecule_templates; i++ )
			{
				printf( "\t* %s: %d counts (min %d, max %d)\n", sim->molecule_templates[i].name, sim->molecule_templates[i].count, mol_min_counts[i], mol_max_counts[i] );
			}
			printf( "\t%d adds\n", number_added );
			printf( "\t%d removes\n", number_removed );
			printf( "\t%d total completed operations (%d impossible removals skipped)\n", number_removed+number_added, gc_loop-(number_removed+number_added) );
		}
	}
	
	free( coords );
	FreeSim( sim );
	
	printf( "passed.\n\n" );
}


int main( int argc, char ** argv )
{
	MCSim * sim;
	double x, y, z;

	TestBins();
	TestTables();
	TestPartialEnergyCorrection();
	TestRotation();
	TestBondsAndAngles();
	TestGCFunctionality();

	printf( "Generating Lennard-Jones potential distribution...\n" );
	x = 25.0;
	y = z = 10.0;
	sim = MakeVanillaSim( 298.0, 2.0/(x*y*z), x, y, z, 1, 1, 1 );
		sim->delta_r = 1.0;
		sim->site_templates[0].LJ_eps = 5.0e3;
		sim->site_templates[0].LJ_sig = 3.0;
		RebuildLJTable( sim );
		sim->max_steps =  2500000;
		sim->save_every =  500000;
	TestNonbonded( sim, sim->cell[0], 250, "lj.dist" );
	FreeSim( sim );
	printf( "done\n\n" );

	printf( "Generating hard sphere potential distribution...\n" );
	sim = MakeVanillaSim( 298.0, 2.0/(x*y*z), x, y, z, 1, 1, 1 );
		sim->delta_r = 1.0;
		sim->site_templates[0].LJ_eps = 0.0;
		sim->site_templates[0].LJ_sig = 3.0;
		sim->site_templates[0].hard_sphere_radius = 1.0;
		RebuildLJTable( sim );
		sim->max_steps =  2500000;
		sim->save_every =  500000;
	TestNonbonded( sim, sim->cell[0], 250, "hs.dist" );
	FreeSim( sim );
	printf( "done\n\n" );

	printf( "Generating direct electrostatic potential distribution...\n" );
	x = 500.0;
	sim = MakeVanillaSim( 298.0, 2.0/(x*y*z), x, y, z, 1, 1, 1 );
		sim->delta_r = 1.0;
		sim->site_templates[0].LJ_eps = 0.0;
		sim->site_templates[0].LJ_sig = 3.0;
		sim->site_templates[0].hard_sphere_radius = 0.0;
		sim->site_templates[0].q = 0.5;
		RebuildLJTable( sim );
		sim->max_steps =  2500000;
		sim->save_every =  500000;
	TestNonbonded( sim, sim->cell[0], 250, "q.dist" );
	FreeSim( sim );
	printf( "done\n\n" );

	TestInfWallCoulomb();
}
