#include "../core/mc.h"

/*
	Attempts to produce a rho / mu plot (a la Frenkel & Smit, p177) using
	a set of grand canonical Monte Carlo simulations.
	
	"pressures" is the list of pressures to simulate at.
	Writes the file "gc_mu.txt" which is mu vs. density, and is easily plottable.
	Compare output to that of WidomExample().
*/
void GCExample()
{
	long store = -1;
	double old_molU, new_molU;
	double coords[3];
	double L, volume, mu, move_rate;

	double sample_acc, block_mean;
	int eq_period, nsamples, nblocks, n_added, n_removed, n_moves;

	int i, p_index, mol_type, mol_instance;
	// pressure info for ideal gas in surrounds
	double P_id, pressures[] = { 0.128, 0.15, 0.20, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, -1.0 };
		
	FILE * f;
	MCSim * sim;
	
	move_rate = 0.35; // move rate quite low to encourage fast formation of target density.
	
	f = fopen( "gc_mu.txt", "w" );
	if( f != NULL ) fclose( f );
	
	for( p_index = 0; pressures[p_index] > 0.0; p_index++ )
	{
		sim = MakeEmptySim();
			AddSiteInfo( sim, "site", 0.0, 0.0, 1.0*NAV, 1.0 ); // ie reduced unit of 1.0 for LJ eps
			AddMoleculeInfo( sim, "molecule", 10 );
				AddSiteToMolecule( sim, "molecule", "site" );
		InitialiseSim( sim, 298.0 );

		L = 6.0; // where L too small for accurate density to be measured, weirdness at very low densities.
		sim->cell[0] = L;
		sim->cell[1] = L;
		sim->cell[2] = L;
		volume = sim->cell[0]*sim->cell[1]*sim->cell[2];
		
		sim->LJ_cut = L/2.0;
		sim->delta_r = 2.0;
		sim->ran1_seed = store;
		
		sim->T = 2.0; // switch to reduced temperature of 2
								
		P_id = pressures[p_index]; // ideal gas pressure of surrounds.
		printf( "\nP_id is %f\n", P_id );
				
		sim->save_every =     1000;
		eq_period       =   500000;
		sim->max_steps  =   500000+eq_period;
		
		n_added = 0;
		n_removed = 0;
		n_moves = 0;
		
		sample_acc = 0.0;
		block_mean = 0.0;
		nsamples = 0;
		nblocks = 0;

		/*
			Ramdomly place initial sites.
		*/
		for( i=0; i<sim->n_sites; i++ )
		{
			sim->site_coords[(i*3) + 0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
			sim->site_coords[(i*3) + 1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
			sim->site_coords[(i*3) + 2] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[2];
		}

		/*
			Main MC loop.
		*/
		for( sim->current_step = 0; sim->current_step < sim->max_steps; sim->current_step++ )
		{
			// sample mol counts
			sample_acc += sim->molecule_templates[0].count;
			nsamples++;
			
			/*
				Should we move a molecule?
				Note - only possible where at least one molecule (and hence, site) exists!
			*/
			if( sim->n_sites > 0 && ran1(&sim->ran1_seed) < move_rate )
			{
				mol_type = (int) floor( ran1( &sim->ran1_seed )*sim->n_molecule_templates );
				mol_instance = (int) floor( ran1( &sim->ran1_seed )*sim->molecule_templates[mol_type].count );
				
				old_molU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL );
				PushMoleculeCoords( sim, mol_type, mol_instance ); // save molecule coords
				
				coords[0] = (ran1( &sim->ran1_seed )-0.5)*sim->delta_r;
				coords[1] = (ran1( &sim->ran1_seed )-0.5)*sim->delta_r;
				coords[2] = (ran1( &sim->ran1_seed )-0.5)*sim->delta_r;
				
				TranslateMolecule( sim, mol_type, mol_instance, coords );

				/*
					Calculate new energy, determine whether to accept new state.
				*/
				new_molU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL );
				if( new_molU < old_molU || ran1(&sim->ran1_seed) < exp( -(new_molU-old_molU)/sim->T ) )
				{
					sim->accepted++;
				}
				else
				{
					sim->rejected++;
					PopMoleculeCoords( sim, mol_type, mol_instance ); // restore previous coords
				}
				n_moves++;
			}
			/*
				Attempt to change composition of sim by either adding or removing a molecule.
			*/
			else
			{
				/*
					Attempt to insert a molecule.
				*/
				if( ran1(&sim->ran1_seed) > 0.5 )
				{
					mol_type = (int) floor( ran1(&sim->ran1_seed)*sim->n_molecule_templates );
					// set up coords; as we're using a single site molecule sim, just 3 random numbers.
					coords[0] = (ran1( &sim->ran1_seed )-0.5)*sim->cell[0];
					coords[1] = (ran1( &sim->ran1_seed )-0.5)*sim->cell[1];
					coords[2] = (ran1( &sim->ran1_seed )-0.5)*sim->cell[2];

 					// get molecule energy of external molecule (ie not in the current sim, hence instance == -1) of type "mol_type", with coords as in "coords"
					new_molU = GetMoleculeEnergy( sim, mol_type, -1, coords );
				
					/*
						Usual GC insert accept formula for single component system.
					*/
					if( ran1( &sim->ran1_seed ) < (volume*P_id/(sim->T*sim->molecule_templates[mol_type].count+1)) * exp( -new_molU/sim->T ) )
					{
						n_added++;
						AddMoleculeToSim( sim, mol_type, coords );
					}
				}
				/*
					Attempt to remove a molecule; can only do so if more than 1 molecule of requested type present!
				*/
				else if ( sim->n_sites > 0 )
				{
					mol_type = (int) floor( ran1(&sim->ran1_seed)*sim->n_molecule_templates );
					
					// check we're not removing molecules that don't exist.
					if( sim->molecule_templates[mol_type].count > 0 )
					{

						mol_instance = (int) floor( ran1(&sim->ran1_seed)*sim->molecule_templates[mol_type].count );
										
						new_molU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL );
						new_molU = -new_molU; // as removing.
					
						/*
							Usual GC removal accept formula for single component system.
						*/
						if( ran1( &sim->ran1_seed ) < ((double)sim->molecule_templates[mol_type].count/(volume*P_id/sim->T)) * exp(-new_molU/sim->T ) ) // assumes reduced units.
						{
							n_removed++;
							RemoveMoleculeFromSim( sim, mol_type, mol_instance );
						}
					}
				}
			}
			
			/*
				Print some info to the console every now and again.
			*/
			if( sim->current_step > 0 && sim->current_step % 250000 == 0 )
			{
				printf( "Step %ld:\n", sim->current_step );
				printf( "\t%d moves, %d adds, %d removals in current block of %lu\n", n_moves, n_added, n_removed, sim->save_every );
				printf( "\tcurrent density of \"%s\": %f (%.2f counts)\n", sim->molecule_templates[0].name, sample_acc / (nsamples*volume), sample_acc / nsamples );
			}

			/*
				Add step average to block accumulator, and reset step info
			*/
			if( sim->current_step > 0 && sim->current_step % sim->save_every == 0 )
			{
				block_mean = block_mean*nblocks + sample_acc/nsamples;
				block_mean = block_mean / (nblocks+1);
				
				sample_acc = 0.0;
				nsamples = 0;
				
				nblocks ++;

				n_moves = n_added = n_removed = 0;
			}

			/*
				Equil period over; reset all accumulators and start again.
			*/
			if( sim->current_step == eq_period )
			{
				printf( "Equilibration period over. Collecting block data.\n" );
				// reset all counters
				n_added = n_removed = n_moves = 0;
				sample_acc = block_mean = 0.0;
				nsamples = nblocks = 0;
			}
		}
		
		/*
			Store the current random number generator value; this means we don't run the same
			sequence of numbers in the next simulation, as we would if we simply reset it to -1
			each time.
		*/
		store = sim->ran1_seed;

		/*
			Print final sim info
		*/
		printf( "Finished on step %ld:\n", sim->current_step );
		// actually mu_ex, the excess chemical potential; for mu : mu_ex + ln( <rho> )/beta
		mu = log(P_id/sim->T)*sim->T - log( block_mean / volume )*sim->T;
		printf( "\"%s\" : rho %f (%.2f counts), mu %f\n", sim->molecule_templates[0].name, block_mean / volume, block_mean, mu );

		/*
			Save final sim info
		*/
		f = fopen( "gc_mu.txt", "a" );
		if( f != NULL )
		{
			fprintf( f, "%f %f\n", block_mean / volume, mu );
			fclose( f );
		}

		FreeSim( sim );
	}
}

int main( int argc, char ** argv )
{
	GCExample();
	return 0;
}
