#include "../core/mc.h"
#include "../util/WL.h"


/*
	Example of recreating a 2D potential surface for the position of a charged site
	using the network aware Wang-Landau classes.
	
	This also makes use of the Bins class for simple creation of multidimensional binning
	structures which can be easily indexed with floating point coordinates. These coordinates
	should be double precision as the Bins structure uses variadic mapping, which expects
	double precision; using single precision, for example, will break the mapping routines!
	
	Saves 2 files; "target.txt" (the target potential surface) and "U.txt" - the
	current estimate of the target surface. This surface is deliberately quite
	complicated, wih excluded bands and charged wall contributions etc; it also
	features a large nuber of bins (circa 20,000), to show that the code scales well
	with large bias functions - in this case over 150kB of data.
	
	The bias function used here is expressed in units of kB*T.
	
	These output files may be plotted in gnuplot using the splot command:
	
	splot "target.txt" using 2:3:6 with pm3d
	splot "U.txt" using 2:3:($6) with pm3d
	
	Note that ($6) is needed in the U.txt file plotting to enforce ignoring of the
	'nan' values denoting the excluded region, or gnuplot interpolates over the gap
	giving a different graph to target.txt.
*/

/*
	Create the simulation we'll be using.
	
	It consists of:
	
	2 charged sites, with no hard sphere or Lennard-Jones paramaters.
		One of these sites is never moved, it's only there to to create
		effects which produce a more interesting energy surface.
		
	2 charged planes, which again make the potential surface a little more
	interesting to look at.
	
*/
MCSim * setup_sim( double T, double x, double y, double z, double delta_r )
{
	MCSim * sim;

	sim = MakeEmptySim();
		AddSiteInfo( sim, "s1", 0.5, 0.0, 0.0, 1.0 );
		AddSiteInfo( sim, "s2", 0.5, 0.0, 0.0, 1.0 );

		AddMoleculeInfo( sim, "m1", 1 );
			AddSiteToMolecule( sim, "m1", "s1" );

		AddMoleculeInfo( sim, "m2", 1 );
			AddSiteToMolecule( sim, "m2", "s2" );
		
		AddChargedPlaneInfo( sim, 1, -10.0, 0.001 );
		AddChargedPlaneInfo( sim, 2, -10.0, 0.001 );
	InitialiseSim( sim, T );

	sim->cell[0] = x;
	sim->cell[1] = y;
	sim->cell[2] = z;
	sim->delta_r = delta_r;
	
	PrintSim( sim );
	
	return sim;
}
/*
	Performs a short Wang - Landau MC run on the system, using the bias potential and delta_U passed.
*/
void short_run( MCSim * sim, Bins * bias, double delta_U )
{
	int mol_type, mol_instance, site, bias_bin;
	double oldU, newU;
	
	mol_type = 1; // always moving same site from same molecule.
	mol_instance = 0;
	
	for( sim->current_step=0; sim->current_step<sim->max_steps; sim->current_step++ )
	{
		site = GetMoleculeStartSite( sim, mol_type, mol_instance );
		
		bias_bin = bias->Map( &sim->site_coords[site*3 + 1] ); // ie use y and z coords of site to map onto a bin index.
		bias->accs[bias_bin] += delta_U;
		
		oldU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL ) + bias->accs[bias_bin]*KB*sim->T; // bias potential is in units of kBT

		PushSiteCoords( sim, site );
					
		// move
		sim->site_coords[site*3 + 1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
		sim->site_coords[site*3 + 2] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[2];
		
		bias_bin = bias->Map( &sim->site_coords[site*3 + 1] ); // ie use y and z components to map the correct bias bin, so we can get the energy penalty.
		
		/*
			Check bias potential for state we're moving to.
			If already infinite, due to being in one of the excluded regions,
			then don't bother evaluating the system potential!
		*/
		newU = bias->accs[bias_bin] * KB*sim->T;
		if( newU != HUGE_VAL )
		{
			newU += GetMoleculeEnergy( sim, mol_type, mol_instance, NULL );
			if( newU < oldU || ran1(&sim->ran1_seed) < exp( -(newU-oldU)/(KB*sim->T) ) )
			{
				sim->accepted++;
				continue;
			}
		}
		PopSiteCoords( sim, site );
		sim->rejected++;
	}
}

/*
	Fills a Bins structure with the 2D energy surface of the system.
	
	This surface is a function of a point charge and a series of charged planes,
	see the setup_sim() routine for more details.
	
	Where include_normal > 0, adds usual system energy too for a "target"
	potential surface that the sim results should closely approximate.
	Otherwise, only include the excluded regions in the surface, which
	can then act as the starting potential surface of the Wang Landau server
	class  - these excluded regions are not products of the natural system energy,
	so we need to add them at the start via the initial values passed to the server.
*/
void get_energy_surface( Bins * b, MCSim * sim, int include_normal )
{
	int i, j, bin;
	double y, z, energy;
	double r, r12[3];

	/*
		Move across the 2d surface, gathering the energy at the equidistantly spaced
		points we visit.
	*/
	for( i = 0; i < b->nbins[0]; i++ )
	{
		y = b->mins[0] + (0.5+i)*b->deltas[0];
		for( j = 0; j < b->nbins[1]; j++ )
		{
			z = b->mins[1] + (0.5+j)*b->deltas[1];
			
			// move the mobile site to the new position, so we can use the standard energy functions to get its energy.
			sim->site_coords[(1*3) +0] = 0.0;
			sim->site_coords[(1*3) +1] = y;
			sim->site_coords[(1*3) +2] = z;
			
			/*
				get the appropriate bin index in the bias array from the y and z coords of the site.
				the bias is a 2d bins object, so we can pass a pointer to the first coordinate, and
				it will automatically know to take two coords starting at that position in memory
				so we're using both the y and z coords to map a bin index.
			*/
			bin = b->Map( &sim->site_coords[(1*3) +1] );

			energy = 0.0;

			r = GetSeparationSquaredAndVectorMIC( sim->site_coords, &sim->site_coords[3], r12, sim->cell, sim->PBC );
			if( r < 1.0 ) energy = HUGE_VAL;

			/*
				2 excluded strips to make the surface more interesting!
			*/
			if( fabs( sim->site_coords[(1*3)+1] ) < 1.0 ) energy = HUGE_VAL;
			if( fabs( sim->site_coords[(1*3)+2] ) < 1.0 ) energy = HUGE_VAL;

			if( energy != HUGE_VAL && include_normal > 0 )
				energy = GetMoleculeEnergy( sim, 1, 0, NULL ) / (KB*sim->T);

			b->accs[bin] = energy;
		}
	}
}
/*
	Save the bias info in a more useful manner than the ordinary Bins save routines.
*/
void save_energy_surface( Bins * b, char * fpath, int is_bias )
{
	double minval, maxval, *data;
	int i, j;
	
	j = b->total_nbins;
	data = b->accs;
	
	minval = data[0];
	maxval = data[0];

	/*
		Get minimum and maximum values, watching for HUGE_VAL which denotes
		an excluded region.
	*/
	for( i=1; i<j; i++ )
	{
		if( data[i] < minval ) minval = data[i];
		if( data[i] > maxval && data[i] != HUGE_VAL ) maxval = data[i];
	}
	
	if( is_bias == 0 )
	{
		/*
			If it's the target potential, we want to subtract the minimum value 
			from all the bins to get a relative energy surface.
		*/
		for( i=0; i<j; i++ ) data[i] -= minval;
		b->Save( fpath, 1.0 );
		for( i=0; i<j; i++ ) data[i] += minval;
	}
	else
	{
		/*
			If it's the bias potential, it's "upside down" compared to the target
			potential surface; therefore, we want to subtract the maximum value
			and invert it, which is done by using -1 as the multiplier in Save().
		*/
		for( i=0; i<j; i++ ) data[i] -= maxval;
		b->Save( fpath, -1.0 );
		for( i=0; i<j; i++ ) data[i] += maxval;
	}
}

void printusage()
{
	printf( "arguments: port simID\n" );
	printf( "Where:\n" );
	printf( "\tport is the TCP/IP port to listen for incoming connections\n" );
	printf( "\tsimID is the simulation group identifier\n" );
	exit( -1 );
}

int main( int argc, char ** argv )
{
	int i, n_fails, result, port, simID;
	
	double deltaU, deltaU_decay, min_deltaU;

	MCSim * sim;
	Bins * bias;
	WLNode * node;
	
	if( argc < 3 ) printusage();
	
	port = atoi( argv[1] );
	simID = atoi( argv[2] );
	
	/*
		Sim info setup.
	*/
	sim = setup_sim( 300.0, 20.0, 20.0, 20.0, 5.0 );
	sim->site_coords[(1*3) +1] = 3.0;
	sim->ran1_seed = (unsigned long)getpid();
	
	/*
		2D Bins setup; minimum to maximum positions on y and z axes, with 7 bins per Angstrom granularity.
	*/
	bias = new Bins( 2, -sim->cell[1]/2.0,
						 sim->cell[1]/2.0,
						 (int) (sim->cell[1]*10),
						
						-sim->cell[2]/2.0,
						 sim->cell[2]/2.0,
						 (int) (sim->cell[2]*10) );

	/*
		Save a target energy surface
	*/
	get_energy_surface( bias, sim, 1 );
	save_energy_surface( bias, "target.txt", 0 );

	/*
		Get an excluded energy surface, so we have the excluded regions in the initial data sets
		as a HUGE_VAL energy penalty for being in those regions.
	*/
	bias->Clear();
	get_energy_surface( bias, sim, 0 );

	/*
		Create a WLNode for this simulation, with starting bias as set up above.
		
		The parameters are overwritten if we Sync() with a running server, or when we
		promote to server and existing snapshot exists. Otherwise, they are used to
		seed the new simulation.
	*/
	deltaU = 1.0; // in kB.T
	deltaU_decay = 0.2;
	min_deltaU = 1e-5; // ie converge when deltaU <= 0.001% of kBT. This is excessive, but the sim finished very quickly otherwise!

	node = new WLNode( simID, port, bias->total_nbins, bias->accs, deltaU, deltaU_decay, WL_REFINE_ABSOLUTE, 10.0, min_deltaU );
	
	/*
		Try to join specified simulation. If there's no server defined, we may be the first
		node to come online - so try to promote this node the server.
		
		PromotingSync() attempts to sync with the specified simulation, and if that fails it
		attempts to promote the internal server to be the acting simulation server. The params
		below specify 1 attempt to sync before promotion, and then 5 attempts to sync afterwards
		( with a delat of 1 second between attempts ) before the routine returns failure.
		
		Note - always check the returned value! The simulation may have finished!
	*/
	result = node->PromotingSync( bias->accs, &deltaU, 1, 5, 1 );
	if( result < 0 )
	{
		if( result == WL_SIMULATION_FINISHED )
		{
			printf( "%s(): finished detected.\n", __func__ );
			delete node;
			exit( 0 );
		}
		printf( "Unable to sync or promote to server!\n" );
		exit( -1 );
	}

	
	/*
		Perform a number of small MC sims using the current bias, and sharing the new bias data
		with the server after each one. Continue until we have reduced deltaU to a small value.
	*/
	i = 0;
	n_fails = 0;
	sim->max_steps = 50000;
	while( 1 )
	{
		if( i % 100000 == 0 )
		{
			printf( "%s(): step %d, delta_U %f\n", __func__, i, deltaU );
			if( node->AmIServer() == 1 ) save_energy_surface( bias, "U.txt", 1 ); // if server, save the current surface as we go along
		}
		
		/*
			Short sim run with the current bias potential.
		*/
		sim->current_step = 0;
		short_run( sim, bias, deltaU );
		i += sim->max_steps;
		/*
			Update out bias potential and deltaU by synchronising data with server.
			Here we're passing the accumulator array from the bias object.
		*/
		result = node->PromotingSync( bias->accs, &deltaU, 1, 5, 1 );
		if( result < 0 )
		{
			if( result == WL_SIMULATION_FINISHED )
			{
				printf( "%s(): finished detected.\n", __func__ );
				break;
			}
			printf( "Unable to sync or promote to server!\n" );
			exit( -1 );
		}
	}
	
	save_energy_surface( bias, "U.txt", 1 ); // save final energy surface.

	printf( "%d steps.\n", i );
	
	delete node;
	delete bias;

	return 0;
}
