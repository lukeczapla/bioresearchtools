#include "../core/mc.h"
#include "../util/distributions.h"
#include "../util/pressures.h"

/*
	Try to replicate Malek's pressure stranheness
*/
/*
	Test pressures a la Valleau et al, J Chem Phys 95:520-532, 1991.
*/
void TestSaltMalek( double sigma, int sites_per_wall, double wq, double whsr, double w_R6eps, double w_R6sig, double cq, double chsr, double z )
{
	MCSim * sim;
	Distributions * d;
	SimplePressures *p;
	jsocket * js;
	
	StatBins *direct_coulomb, *charged_plane_templates, *combined_electro, *kinetic, *S1, *S2;
	double dc_pressure, cp_pressure, kin_pressure, S1_val, S2_val;

	int i, j, k, equil_period, evaluate_pressure_every, wdim, ncounter, mol_type, mol_instance, site;
	double a, c, m, extent, x, y, r, offset[3], oldU, newU, deltaU;
	
	wdim = (int) round( sqrt( (double)sites_per_wall ) );
	if( wdim*wdim != sites_per_wall )
	{
		printf( "sites_per_wall (%d) is not the square of an integer\n", sites_per_wall );
		exit( -1 );
	}
	
	ncounter = (int) round( 2.0*sites_per_wall*fabs(wq)/fabs(cq) );
	if( cq*ncounter - wq*2.0*sites_per_wall > 1e-20 )
	{
		printf( "can't calculate integer counterion count (%d) to balance walls properly\n", ncounter );
		exit( -1 );
	}
	
	x = sqrt( (double)sites_per_wall/sigma );
	y = x;
	
	a = x/wdim;
	extent = (z/2.0) - (2.0*whsr);

	/*
		Initialise sim structure
	*/
	sim = MakeEmptySim();
		AddSiteInfo( sim, "wall1", wq, whsr, 0.0, 1.0 );
		AddSiteInfo( sim, "wall2", wq, whsr, 0.0, 1.0 );
		AddSiteInfo( sim, "counter", cq, chsr, 0.0, 1.0 );
		
		AddMoleculeInfo( sim, "wall1", sites_per_wall );
			AddSiteToMolecule( sim, "wall1", "wall1" );

		AddMoleculeInfo( sim, "wall2", sites_per_wall );
			AddSiteToMolecule( sim, "wall2", "wall2" );

		AddMoleculeInfo( sim, "counter", ncounter );
			AddSiteToMolecule( sim, "counter", "counter" );

		sim->cell[0] = x;
		sim->cell[1] = y;
		sim->cell[2] = z;

		sim->PBC[2] = 0;

		sim->e1 = 78.5;
		sim->delta_r = 20.0;

	InitialiseSim( sim, 298.0 );
	PrintSim( sim );

	/*
		Place wall sites on grid
	*/
	k = 0;
	for( i=0; i<wdim; i++ )
	{
		for( j=0; j<wdim; j++ )
		{
			sim->site_coords[(k*3)+0] = (-sim->cell[0]/2.0) + (a/2.0) + a*i;
			sim->site_coords[(k*3)+1] = (-sim->cell[1]/2.0) + (a/2.0) + a*j;
			sim->site_coords[(k*3)+2] =  -sim->cell[2]/2.0;

			sim->site_coords[((k+sites_per_wall)*3)+0] = (-sim->cell[0]/2.0) + (a/2.0) + a*i;
			sim->site_coords[((k+sites_per_wall)*3)+1] = (-sim->cell[1]/2.0) + (a/2.0) + a*j;
			sim->site_coords[((k+sites_per_wall)*3)+2] =   sim->cell[2]/2.0;
			k++;
		}
	}

	/*
		Place counterion sites, ensuring hard spheres don't overlap in starting config
	*/
	printf( "Placing sites...\n" );
	for( i=2*sites_per_wall; i<2*sites_per_wall + ncounter; i++ )
	{
		if( i%10 == 0 ) printf( "\tdone %d...\n", i );
		
		sim->site_coords[(i*3)+0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
		sim->site_coords[(i*3)+1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
		sim->site_coords[(i*3)+2] = (ran1(&sim->ran1_seed)-0.5) * extent;

		for( j=2*sites_per_wall; j<i; j++ )
		{
			r = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[i*3], &sim->site_coords[j*3], offset, sim->cell, sim->PBC ) );
			if( r < 2.0*chsr )
			{
				i--;
				break;
			}
		}
	}

	/*
		Update visualisation, where connected.
	*/
	js = GetJSocket( "localhost", KRONENBOURG_PORT, 0 );
	if( js != NULL )
	{
		WriteJSocket( js->socket, sim->cell, sizeof(double)*3 );
		WriteJSocket( js->socket, &sim->n_sites, sizeof(int) );
		WriteJSocket( js->socket, sim->site_template_indices, sizeof(int)*sim->n_sites );
		WriteJSocket( js->socket, sim->site_coords, sizeof(double)*sim->n_sites*3 );
		FreeJSocket( js );
	}

	equil_period = 1000000;
	evaluate_pressure_every = 100;
	sim->max_steps = 2000000;
		
	d = new Distributions( 2, 1000, (int) ceil(sim->cell[2]*10), sim );
	/*
		Set up our pressure measuring class; the S function ranges from the
		ion diameter to a little outside that value, and we're interested in the
		z axis.
	*/
	p = new SimplePressures( 2, 2.0*chsr, 2.0*chsr+0.2, sim );
	/*
		Statistical binning of the data. Here we only have one bin! It ranges from
		0.0 to 2.0, and we pass coordinate of 1.0 to the binning routines to ensure
		we fall in that range.
		The S bins are just two values of the S function close to the hard pshere radius that
		we can use the interpolate the collisional pressure from.
	*/
	direct_coulomb = new StatBins( 100, 0.0,2.0,1 );
	charged_plane_templates = new StatBins( 100, 0.0,2.0,1 );
	combined_electro = new StatBins( 100, 0.0,2.0,1 );
	kinetic = new StatBins( 100, 0.0,2.0,1 );
	S1 = new StatBins( 100, 0.0,2.0,1 );
	S2 = new StatBins( 100, 0.0,2.0,1 );

	/*
		MC loop
	*/
	for( sim->current_step = 0; sim->current_step < sim->max_steps; sim->current_step++ )
	{
		if( sim->current_step > 0 && sim->current_step % 10000 == 0 )
		{
			printf( "Step %lu:\n", sim->current_step );
			printf( "\taccepted %lu of %lu (%.2f%%)\n", sim->accepted, sim->accepted+sim->rejected, 100.0*sim->accepted/(sim->accepted+sim->rejected) );
			
			/*
				Rought linear interpolation of function S to x == 0.
				ie.
					y = mx + c
					m = dy/dx
				so	c = y/mx etc.
				
				We have 2 bins; S1 and S2, the closest bins to the hard sphere cutoff (S1 is cutoff -> cutoff+delta, S2 is cutoff+delta -> cutoff+2*delta )
				
				Note that the paper we're copying used cubic interpolation, so we don't expect the S pressure to be as close as the other components.
				It should be pretty good, though!
			*/
			m = 1e3*(S1->block_means[0] - S2->block_means[0]) / p->S_delta;
			c = 1e3*S1->block_means[0] + (p->S_delta*0.5)*m; // as measured at halfway point of first bin
			
			printf( "\tP_kin: %f (%f)\n", kinetic->block_means[0], sqrt( kinetic->Variance(0) ) );
			printf( "\tP_col: %f (approx.)\n", c );
			printf( "\tP_el: %f (%f)\n", combined_electro->block_means[0], sqrt( combined_electro->Variance(0) ) );
			printf( "\t\tP_dc: %f (%f)\n", direct_coulomb->block_means[0], sqrt( direct_coulomb->Variance(0) ) );
			printf( "\t\tP_cp: %f (%f)\n", charged_plane_templates->block_means[0], sqrt( charged_plane_templates->Variance(0) ) );
			printf( "\tP_total: %f (approx)\n", kinetic->block_means[0] + c + combined_electro->block_means[0] );

			sim->accepted = 0;
			sim->rejected = 0;
			
			d->Save( "", sim );

			/*
				Update visualisation, where connected.
			*/
			js = GetJSocket( "localhost", KRONENBOURG_PORT, 0 );
			if( js != NULL )
			{
				WriteJSocket( js->socket, sim->cell, sizeof(double)*3 );
				WriteJSocket( js->socket, &sim->n_sites, sizeof(int) );
				WriteJSocket( js->socket, sim->site_template_indices, sizeof(int)*sim->n_sites );
				WriteJSocket( js->socket, sim->site_coords, sizeof(double)*sim->n_sites*3 );
				FreeJSocket( js );
			}
		}

		d->Accumulate( sim );
		if( sim->current_step > equil_period && sim->current_step % evaluate_pressure_every == 0 )
		{
			p->Get( sim, d, &dc_pressure, &cp_pressure, &kin_pressure, &S1_val, &S2_val );
			
			direct_coulomb->IndexAdd(  0, dc_pressure );
			charged_plane_templates->IndexAdd(  0, cp_pressure );
			//combined_electro->IndexAdd(  0, dc_pressure-cp_pressure );
			combined_electro->IndexAdd(  0, dc_pressure+cp_pressure );
			kinetic->IndexAdd( 0, kin_pressure );
			S1->IndexAdd(  0, S1_val );
			S2->IndexAdd(  0, S2_val );
		}
		
		mol_type = (int) floor( ran1(&sim->ran1_seed) * sim->n_molecule_templates );
		mol_instance = (int) floor( ran1(&sim->ran1_seed) * sim->molecule_templates[mol_type].count );
		site = GetMoleculeStartSite( sim, mol_type, mol_instance );
		
		// get current energy
		oldU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL ) + d->GetLREECorrection( sim, mol_type, mol_instance, NULL );
		// if wall sites, add R6 energy
		if( mol_type < 2 )
		{
			i = GetMoleculeStartSite( sim, mol_type, 0 );
			for( j=i; j<i+sim->molecule_templates[mol_type].count; j++ )
			{
				if( j == site ) continue;
				// R6, only on x and y axes
				r = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[site*3], &sim->site_coords[j*3], offset, sim->cell, sim->PBC ) );
				a = (w_R6sig / r);
				a = a*a*a * a*a*a;
//				oldU += (4.0*w_R6eps*KB*sim->T) * ( a*a - a );
				oldU += (4.0*w_R6eps*KB*sim->T) * ( -a );
			}
		}
		
		// offset for translation
		offset[0] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
		offset[1] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
		offset[2] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
		if( mol_type < 2 ) offset[2] = 0.0;
		
		// save old coords and move molecule
		PushMoleculeCoords( sim, mol_type, mol_instance );
		TranslateMolecule( sim, mol_type, mol_instance, offset );
		
		// check for z boundary violation, as we're not periodic on that axis!
		if( mol_type == 2 && fabs(sim->site_coords[(site*3) + 2]) > extent )
		{
			PopMoleculeCoords( sim, mol_type, mol_instance );
			sim->rejected++;
			continue;
		}

		// get new energy, work out the change in energy
		newU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL ) + d->GetLREECorrection( sim, mol_type, mol_instance, NULL );
		// if wall sites, add R6 energy
		if( mol_type < 2 )
		{
			i = GetMoleculeStartSite( sim, mol_type, 0 );
			for( j=i; j<i+sim->molecule_templates[mol_type].count; j++ )
			{
				if( j == site ) continue;
				// R6, only on x and y axes
				r = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[site*3], &sim->site_coords[j*3], offset, sim->cell, sim->PBC ) );
				a = (w_R6sig / r);
				a = a*a*a * a*a*a;
//				oldU += (4.0*w_R6eps*KB*sim->T) * ( a*a - a );
				newU += (4.0*w_R6eps*KB*sim->T) * ( -a );
			}
		}

		// accept new state?
		deltaU = newU - oldU;
		if( deltaU < 0.0 || ran1(&sim->ran1_seed) < exp( -(deltaU)/(KB*sim->T) ) )
		{
			sim->accepted++;
		}
		else
		{
			PopMoleculeCoords( sim, mol_type, mol_instance );
			sim->rejected++;
		}
	}


	delete d;

	delete p;
	delete direct_coulomb;
	delete charged_plane_templates;
	delete combined_electro;
	delete kinetic;
	delete S1;
	delete S2;
	
	FreeSim( sim );
}

/*
	Test pressures a la Valleau et al, J Chem Phys 95:520-532, 1991.
*/
void TestSaltV( double sigma, double q, double ion_diameter, double L, double W )
{
	MCSim * sim;
	Distributions * d;
	SimplePressures *p;
	jsocket * js;
	
	StatBins *direct_coulomb, *charged_plane_templates, *combined_electro, *kinetic, *S1, *S2;
	double dc_pressure, cp_pressure, kin_pressure, S1_val, S2_val;
	
	int i, j, ncounter;
	double hsr, adjusted_W, adjusted_sigma;
	
	int site, mol_instance, mol_type;
	double oldU, newU, deltaU;
	double r, offset[3];
	
	double m, c;
	
	int equil_period, evaluate_pressure_every;
	
	hsr = ion_diameter/2.0;
	adjusted_sigma = sigma / (ELEM_CHARGE*1e20);
	ncounter = (int) floor( (2.0*fabs(adjusted_sigma)*W*W)/fabs(q) );
	
	printf( "adjusted_sigma: %f ELEM/A^2 ( = %f C/m^2; original was %f)\n", adjusted_sigma, adjusted_sigma*ELEM_CHARGE*1e20, sigma );
	printf( "initial guess of %d counterions (valence %f)\n", ncounter, q );
	
	/*
		Recalculate x and y dims to precisely neutralise system
	*/
	printf( "Original system charge:\n" );
	printf( "\tWalls: 2.0 * %f * %f * %f = %f\n", adjusted_sigma, W, W, 2.0 * adjusted_sigma * W * W );
	printf( "\tCounter: %d * %f = %f\n", ncounter, q, q*ncounter );
	printf( "\tTotal: %f + %f = %f\n", 2.0 * adjusted_sigma * W * W, q*ncounter, 2.0 * adjusted_sigma * W * W + q*ncounter );

	adjusted_W = W;
	adjusted_sigma = ncounter*fabs(q)/(2.0*W*W);
	adjusted_W = sqrt( 0.5*ncounter*fabs(q)/fabs(adjusted_sigma) );

	printf( "Adjusted system charge:\n" );
	printf( "\tWalls: 2.0 * %f * %f * %f = %f\n", adjusted_sigma, adjusted_W, adjusted_W, 2.0 * adjusted_sigma * adjusted_W * adjusted_W );
	printf( "\tCounter: %d * %f = %f\n", ncounter, q, q*ncounter );
	printf( "\tTotal: %f + %f = %f\n", 2.0 * adjusted_sigma * adjusted_W * adjusted_W, q*ncounter, 2.0 * adjusted_sigma * adjusted_W * adjusted_W  +  q*ncounter );
	
	/*
		Initialise sim structure
	*/
	sim = MakeEmptySim();
		AddSiteInfo( sim, "counter", q, hsr, 0.0, 1.0 );
		AddMoleculeInfo( sim, "counter", ncounter );
			AddSiteToMolecule( sim, "counter", "counter" );
		AddChargedPlaneInfo( sim, 2, -(L/2.0 + hsr), adjusted_sigma );
		AddChargedPlaneInfo( sim, 2,  (L/2.0 + hsr), adjusted_sigma );

		sim->cell[0] = adjusted_W;
		sim->cell[1] = adjusted_W;

	InitialiseSim( sim, 298.0 );

	sim->cell[2] = L;
	sim->PBC[2] = 0;
	sim->e1 = 78.5;
	sim->delta_r = hsr;
	
	PrintSim( sim );
	
	equil_period = 1000000;
	evaluate_pressure_every = 100;
	sim->max_steps = 2000000;
		
	d = new Distributions( 2, 1000, (int) ceil(sim->cell[2]*10), sim );
	
	/*
		Set up our pressure measuring class; the S function ranges from the
		ion diameter to a little outside that value, and we're interested in the
		z axis.
	*/
	p = new SimplePressures( 2, ion_diameter, ion_diameter+0.2, sim );
	/*
		Statistical binning of the data. Here we only have one bin! It ranges from
		0.0 to 2.0, and we pass coordinate of 1.0 to the binning routines to ensure
		we fall in that range.
		The S bins are just two values of the S function close to the hard pshere radius that
		we can use the interpolate the collisional pressure from.
	*/
	direct_coulomb = new StatBins( 100, 0.0,2.0,1 );
	charged_plane_templates = new StatBins( 100, 0.0,2.0,1 );
	combined_electro = new StatBins( 100, 0.0,2.0,1 );
	kinetic = new StatBins( 100, 0.0,2.0,1 );
	S1 = new StatBins( 100, 0.0,2.0,1 );
	S2 = new StatBins( 100, 0.0,2.0,1 );
	
	/*
		Place sites, ensuring hard spheres don't overlap in starting config
	*/
	printf( "Placing sites...\n" );
	for( i=0; i<ncounter; i++ )
	{
		if( i%10 == 0 ) printf( "\tdone %d...\n", i );
		
		sim->site_coords[(i*3)+0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
		sim->site_coords[(i*3)+1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
		sim->site_coords[(i*3)+2] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[2];

		for( j=0; j<i; j++ )
		{
			r = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[i*3], &sim->site_coords[j*3], offset, sim->cell, sim->PBC ) );
			if( r < ion_diameter )
			{
				i--;
				break;
			}
		}
	}

	/*
		MC loop
	*/
	for( sim->current_step = 0; sim->current_step < sim->max_steps; sim->current_step++ )
	{
		if( sim->current_step > 0 && sim->current_step % 10000 == 0 )
		{
			printf( "Step %lu:\n", sim->current_step );
			printf( "\taccepted %lu of %lu (%.2f%%)\n", sim->accepted, sim->accepted+sim->rejected, 100.0*sim->accepted/(sim->accepted+sim->rejected) );
			
			/*
				Rought linear interpolation of function S to x == 0.
				ie.
					y = mx + c
					m = dy/dx
				so	c = y/mx etc.
				
				We have 2 bins; S1 and S2, the closest bins to the hard sphere cutoff (S1 is cutoff -> cutoff+delta, S2 is cutoff+delta -> cutoff+2*delta )
				
				Note that the paper we're copying used cubic interpolation, so we don't expect the S pressure to be as close as the other components.
				It should be pretty good, though!
			*/
			m = 1e3*(S1->block_means[0] - S2->block_means[0]) / p->S_delta;
			c = 1e3*S1->block_means[0] + (p->S_delta*0.5)*m; // as measured at halfway point of first bin
			
			printf( "\tP_kin: %f (%f)\n", kinetic->block_means[0], sqrt( kinetic->Variance(0) ) );
			printf( "\tP_col: %f (approx.)\n", c );
			printf( "\tP_el: %f (%f)\n", combined_electro->block_means[0], sqrt( combined_electro->Variance(0) ) );
			printf( "\t\tP_dc: %f (%f)\n", direct_coulomb->block_means[0], sqrt( direct_coulomb->Variance(0) ) );
			printf( "\t\tP_cp: %f (%f)\n", charged_plane_templates->block_means[0], sqrt( charged_plane_templates->Variance(0) ) );
			printf( "\tP_total: %f (approx)\n", kinetic->block_means[0] + c + combined_electro->block_means[0] );

			sim->accepted = 0;
			sim->rejected = 0;
			
			d->Save( "", sim );

			/*
				Update visualisation, where connected.
			*/
			js = GetJSocket( "localhost", KRONENBOURG_PORT, 0 );
			if( js != NULL )
			{
				WriteJSocket( js->socket, sim->cell, sizeof(double)*3 );
				WriteJSocket( js->socket, &sim->n_sites, sizeof(int) );
				WriteJSocket( js->socket, sim->site_template_indices, sizeof(int)*sim->n_sites );
				WriteJSocket( js->socket, sim->site_coords, sizeof(double)*sim->n_sites*3 );
				FreeJSocket( js );
			}
		}

		d->Accumulate( sim );
		if( sim->current_step > equil_period && sim->current_step % evaluate_pressure_every == 0 )
		{
			p->Get( sim, d, &dc_pressure, &cp_pressure, &kin_pressure, &S1_val, &S2_val );
			
			direct_coulomb->IndexAdd(  0, dc_pressure );
			charged_plane_templates->IndexAdd(  0, cp_pressure );
			//combined_electro->IndexAdd(  0, dc_pressure-cp_pressure );
			combined_electro->IndexAdd(  0, dc_pressure+cp_pressure );
			kinetic->IndexAdd( 0, kin_pressure );
			S1->IndexAdd(  0, S1_val );
			S2->IndexAdd(  0, S2_val );
		}
		
		mol_type = 0;
		mol_instance = (int) floor( ran1(&sim->ran1_seed) * sim->molecule_templates[mol_type].count );
		site = GetMoleculeStartSite( sim, mol_type, mol_instance );
		
		// get current energy
		oldU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL ) + d->GetLREECorrection( sim, mol_type, mol_instance, NULL );
		
		// offset for translation
		offset[0] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
		offset[1] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
		offset[2] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
		
		// save old coords and move molecule
		PushMoleculeCoords( sim, mol_type, mol_instance );
		TranslateMolecule( sim, mol_type, mol_instance, offset );
		
		// check for z boundary violation, as we're not periodic on that axis!
		if( fabs(sim->site_coords[(site*3) + 2]) >= sim->cell[2]/2.0 )
		{
			PopMoleculeCoords( sim, mol_type, mol_instance );
			sim->rejected++;
			continue;
		}

		// get new energy, work out the change in energy
		newU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL ) + d->GetLREECorrection( sim, mol_type, mol_instance, NULL );

		// accept new state?
		deltaU = newU - oldU;
		if( deltaU < 0.0 || ran1(&sim->ran1_seed) < exp( -(deltaU)/(KB*sim->T) ) )
		{
			sim->accepted++;
		}
		else
		{
			PopMoleculeCoords( sim, mol_type, mol_instance );
			sim->rejected++;
		}
	}
	
	delete d;

	delete p;
	delete direct_coulomb;
	delete charged_plane_templates;
	delete combined_electro;
	delete kinetic;
	delete S1;
	delete S2;
	
	FreeSim( sim );
	
}


/*
	Test pressures a la Gulbrand et al, J Chem Phys 80:2221-2228, 1984.
*/
void TestSaltG( double sigma, int ncounter, double q, double L )
{
	MCSim * sim;
	Distributions * d;
	SimplePressures * p;
	jsocket * js;
	
	StatBins *direct_coulomb, *charged_plane_templates, *combined_electro, *kinetic, *S1, *S2;
	double dc_pressure, cp_pressure, kin_pressure, S1_val, S2_val;

	int i, j;
	double hsr, adjusted_W, adjusted_sigma;
	
	int site, mol_instance, mol_type;
	double oldU, newU, deltaU;
	double r, offset[3];
	
	int equil_period, evaluate_pressure_every;
	
	hsr = 0.0;
	adjusted_sigma = sigma / (ELEM_CHARGE*1e20);
	
	printf( "adjusted_sigma: %f ELEM/A^2 ( = %f C/m^2; original was %f)\n", adjusted_sigma, adjusted_sigma*ELEM_CHARGE*1e20, sigma );
	
	/*
		Recalculate x and y dims to precisely neutralise system
	*/
	adjusted_W = sqrt( ncounter*fabs(q)/(2.0*fabs(adjusted_sigma)) );
	printf( "Adjusted system charge:\n" );
	printf( "\tWalls: 2.0 * %f * %f * %f = %f\n", adjusted_sigma, adjusted_W, adjusted_W, 2.0 * adjusted_sigma * adjusted_W * adjusted_W );
	printf( "\tCounter: %d * %f = %f\n", ncounter, q, q*ncounter );
	printf( "\tTotal: %f + %f = %f\n", 2.0 * adjusted_sigma * adjusted_W * adjusted_W, q*ncounter, 2.0 * adjusted_sigma * adjusted_W * adjusted_W  +  q*ncounter );
	
	/*
		Initialise sim structure
	*/
	sim = MakeEmptySim();
		AddSiteInfo( sim, "counter", q, hsr, 0.0, 1.0 );

		AddMoleculeInfo( sim, "counter", ncounter );
			AddSiteToMolecule( sim, "counter", "counter" );

		AddChargedPlaneInfo( sim, 2, -(L/2.0 + hsr), adjusted_sigma );
		AddChargedPlaneInfo( sim, 2,  (L/2.0 + hsr), adjusted_sigma );

		sim->cell[0] = adjusted_W;
		sim->cell[1] = adjusted_W;
		sim->cell[2] = L;
		sim->PBC[2] = 0; // not periodic on z axis!
		sim->e1 = 78.5;
		sim->delta_r = 5.0;

	InitialiseSim( sim, 298.0 );
	
	PrintSim( sim );
	
	equil_period = 260000;
	evaluate_pressure_every = 100;
	sim->max_steps = 740000;
		
	d = new Distributions( 2, 1000, (int) sim->cell[2]*5, sim );

	p = new SimplePressures( 2, 0.0, 0.2, sim ); // no hard sphere stuff, so S info ignored.
	direct_coulomb   = new StatBins( 5000/evaluate_pressure_every, 0.0,2.0,1 );
	charged_plane_templates   = new StatBins( 5000/evaluate_pressure_every, 0.0,2.0,1 );
	combined_electro = new StatBins( 5000/evaluate_pressure_every, 0.0,2.0,1 );
	kinetic          = new StatBins( 5000/evaluate_pressure_every, 0.0,2.0,1 );
	S1               = new StatBins( 5000/evaluate_pressure_every, 0.0,2.0,1 );
	S2               = new StatBins( 5000/evaluate_pressure_every, 0.0,2.0,1 );

	/*
		Place sites, ensuring hard spheres don't overlap in starting config
	*/
	printf( "Placing sites...\n" );
	for( i=0; i<ncounter; i++ )
	{
		if( i%10 == 0 ) printf( "\tdone %d...\n", i );
		
		sim->site_coords[(i*3)+0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
		sim->site_coords[(i*3)+1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
		sim->site_coords[(i*3)+2] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[2];

		for( j=0; j<i; j++ )
		{
			r = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[i*3], &sim->site_coords[j*3], offset, sim->cell, sim->PBC ) );
			if( r < 2.0*hsr )
			{
				i--;
				break;
			}
		}
	}

	/*
		MC loop
	*/
	for( sim->current_step = 0; sim->current_step < sim->max_steps; sim->current_step++ )
	{
		if( sim->current_step > 0 && sim->current_step % 10000 == 0 )
		{
			printf( "Step %lu:\n", sim->current_step );
			printf( "\taccepted %lu of %lu (%.2f%%)\n", sim->accepted, sim->accepted+sim->rejected, 100.0*sim->accepted/(sim->accepted+sim->rejected) );
			
			sim->accepted = 0;
			sim->rejected = 0;

			printf( "\tP_kin: %f (%f)\n", kinetic->block_means[0], sqrt( kinetic->Variance(0) ) );
			printf( "\tP_col: %f (approx.)\n", 0.0 );
			printf( "\tP_el: %f (%f)\n", combined_electro->block_means[0], sqrt( combined_electro->Variance(0) ) );
			printf( "\t\tP_dc: %f (%f)\n", direct_coulomb->block_means[0], sqrt( direct_coulomb->Variance(0) ) );
			printf( "\t\tP_cp: %f (%f)\n", charged_plane_templates->block_means[0], sqrt( charged_plane_templates->Variance(0) ) );
			printf( "\tP_total: %f (approx)\n", kinetic->block_means[0] + 0.0 + combined_electro->block_means[0] );

			d->Save( "", sim );

			/*
				Update visualisation, where connected.
			*/
			js = GetJSocket( "localhost", KRONENBOURG_PORT, 0 );
			if( js != NULL )
			{
				WriteJSocket( js->socket, sim->cell, sizeof(double)*3 );
				WriteJSocket( js->socket, &sim->n_sites, sizeof(int) );
				WriteJSocket( js->socket, sim->site_template_indices, sizeof(int)*sim->n_sites );
				WriteJSocket( js->socket, sim->site_coords, sizeof(double)*sim->n_sites*3 );
				FreeJSocket( js );
			}
		}

		d->Accumulate( sim );
		if( sim->current_step > equil_period && sim->current_step % evaluate_pressure_every == 0 )
		{
			p->Get( sim, d, &dc_pressure, &cp_pressure, &kin_pressure, &S1_val, &S2_val );
			
			direct_coulomb->IndexAdd(  0, dc_pressure );
			charged_plane_templates->IndexAdd(  0, cp_pressure );
			// using T,V,I simplification
			//combined_electro->IndexAdd(  0, dc_pressure-cp_pressure );
			// full treatment
			combined_electro->IndexAdd(  0, dc_pressure+cp_pressure );
			kinetic->IndexAdd( 0, kin_pressure );
			S1->IndexAdd(  0, S1_val );
			S2->IndexAdd(  0, S2_val );
		}
		
		mol_type = 0;
		mol_instance = (int) floor( ran1(&sim->ran1_seed) * sim->molecule_templates[mol_type].count );
		site = GetMoleculeStartSite( sim, mol_type, mol_instance );
		
		// get current energy
		oldU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL ) + d->GetLREECorrection( sim, mol_type, mol_instance, NULL );

		// offset for translation
		offset[0] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
		offset[1] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
		offset[2] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
		
		// save old coords and move molecule
		PushMoleculeCoords( sim, mol_type, mol_instance );
		TranslateMolecule( sim, mol_type, mol_instance, offset );
		
		// check for z boundary violation, as we're not periodic on that axis
		if( fabs(sim->site_coords[(site*3) + 2]) >= sim->cell[2]/2.0 )
		{
			PopMoleculeCoords( sim, mol_type, mol_instance );
			sim->rejected++;
			continue;
		}

		// get new energy, work out the change in energy - including the bias potential
		newU = GetMoleculeEnergy( sim, mol_type, mol_instance, NULL ) + d->GetLREECorrection( sim, mol_type, mol_instance, NULL );

		// accept new state?
		deltaU = newU - oldU;
		if( deltaU < 0.0 || ran1(&sim->ran1_seed) < exp( -(deltaU)/(KB*sim->T) ) )
		{
			sim->accepted++;
		}
		else
		{
			PopMoleculeCoords( sim, mol_type, mol_instance );
			sim->rejected++;
		}
	}
	
	delete d;

	delete p;
	delete direct_coulomb;
	delete charged_plane_templates;
	delete combined_electro;
	delete kinetic;
	delete S1;
	delete S2;

	FreeSim( sim );
	
}


void PrintUsageV()
{
	printf( "params: sigma counterion_charge counterion_diameter L W\n" );
	exit( -1 );
}
void PrintUsageG()
{
	printf( "params: sigma ncounter counterion_charge L\n" );
	exit( -1 );
}

int main( int argc, char ** argv )
{
	double sigma, q, d, L, W;
	int ncounter;
	#ifdef DEBUG
		printf( "# **************************\n" );
		printf( "# * RUNNING IN DEBUG MODE! *\n" );
		printf( "# **************************\n" );
		PrintBugs();
	#endif

	TestSaltMalek( 0.005, 225,
					 1.0, 2.1,
					 50.0, 100.0,
					-1.0, 0.0,
					 14.0 );
					
	exit( 0 );

	/*
		Valleau et al style
	*/
	if( argc < 6 ) PrintUsageV();
	
	sigma = atof( argv[1] );
	q = atof( argv[2] );
	d = atof( argv[3] );
	L = atof( argv[4] );
	W = atof( argv[5] );
	
	printf( "params:\n" );
	printf( "\tsigma %f\n", sigma );
	printf( "\tcounterion valence %f\n", q );
	printf( "\tcounterion diameter %f\n", d );
	printf( "\tL %f\n", L );
	printf( "\tW %f\n", W );
	
	TestSaltV( sigma, q, d, L, W );

	/*
		Gulbrand et al style
	*/
/*	if( argc < 4 ) PrintUsageG();
	
	sigma = atof( argv[1] );
	ncounter = atoi( argv[2] );
	q = atof( argv[3] );
	L = atof( argv[4] );
	
	printf( "params:\n" );
	printf( "\tsigma %f\n", sigma );
	printf( "\tcounterion number %d\n", ncounter );
	printf( "\tcounterion valence %f\n", q );
	printf( "\tW %f\n", L );
	
	TestSaltG( sigma, ncounter, q, L );*/
	
	return 0;
}
