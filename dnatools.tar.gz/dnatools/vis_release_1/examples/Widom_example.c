#include "../core/mc.h"

/*
	Attempts to produce a rho / mu plot (a la Frenkel & Smit, p177) via a series of canonical Monte
	Carlo simulations using Widom's particle insertion method.
	Writes the file "widom_mu.txt" which is mu vs. density, and is easily plottable.
	Compare output to that of GCExample().
*/
void WidomExample()
{
	int i, molecule_type, molecule_instance;
	long store = -1;
	double widom_r[3];
	double old_molU, new_molU;
	double mu_corr, mu_step_acc, mu_block_acc, widom_energy;
	FILE * f;

	MCSim * sim;
	int equil_period, widom_every, widom_n_steps, widom_n_blocks;
	double rho, rho_delta = 0.025; // density step for loop.
	
	widom_every = 1;
	
	f =  fopen( "widom_mu.txt", "w" );
	if( f != NULL ) fclose( f );
	
	for( rho = rho_delta; rho < 0.81; rho += rho_delta )
	{
		// uses LJ epsilon such that reduced eps = 1.0 at 298K. Energy functions assume per mole!
		sim = MakeEmptySim();
			AddSiteInfo( sim, "site", 0.0, 0.0, 1.0*NAV, 1.0 );
			AddSiteInfo( sim, "ghost site", 0.0, 0.0, 1.0*NAV, 1.0 );

			AddMoleculeInfo( sim, "molecule", 108 );
				AddSiteToMolecule( sim, "molecule", "site" );

			AddMoleculeInfo( sim, "ghost molecule", 0 );
				AddSiteToMolecule( sim, "ghost molecule", "ghost site" );

		InitialiseSim( sim, 298.0 );

		sim->cell[0] = cbrt( 108.0/rho ); // correct dimensions for current density with 108 sites.
		sim->cell[1] = cbrt( 108.0/rho );
		sim->cell[2] = cbrt( 108.0/rho );
		sim->LJ_cut = sim->cell[0]/2.0;
		sim->delta_r = 1.0;
		sim->T = 2.0; // change reduced temp to comparable to F&S; now 2.0 not 1.0!
		sim->ran1_seed = store; // restore last random seed value from previous sim

		sim->save_every =    500;
		equil_period    = 200000;
		sim->max_steps  = 200000+equil_period;
		
		// random coords to start.
		for( i=0; i<sim->n_sites; i++ )
		{
			sim->site_coords[(i*3) + 0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
			sim->site_coords[(i*3) + 1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
			sim->site_coords[(i*3) + 2] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[2];
		}
		
		mu_step_acc = 0.0;
		mu_block_acc = 0.0;
		widom_n_steps = 0;
		widom_n_blocks = 0;
		
		// Main MC loop
		for( sim->current_step = 1; sim->current_step <= sim->max_steps; sim->current_step++ )
		{
			/*
				It's a one-component system, with each molecule having only one site.
				Therfore, we can just pick a site at random to move.
			*/
			molecule_type = 0;
			molecule_instance = (int) floor(ran1( &sim->ran1_seed )*sim->n_sites);

			old_molU = GetMoleculeEnergy( sim, molecule_type, molecule_instance, NULL );
			PushMoleculeCoords( sim, molecule_type, molecule_instance ); // save current molecule coords

			// move site
			widom_r[0] = (ran1( &sim->ran1_seed )-0.5)*sim->delta_r;
			widom_r[1] = (ran1( &sim->ran1_seed )-0.5)*sim->delta_r;
			widom_r[2] = (ran1( &sim->ran1_seed )-0.5)*sim->delta_r;
			TranslateMolecule( sim, molecule_type, molecule_instance, widom_r );

			/*
				Calculate new energy, decide whether to accept move.
			*/
			new_molU = GetMoleculeEnergy( sim, molecule_type, molecule_instance, NULL );
			if( new_molU < old_molU || ran1(&sim->ran1_seed) < exp( -(new_molU-old_molU)/sim->T ) )
			{
				sim->accepted++;
			}
			else
			{
				sim->rejected++;
				PopMoleculeCoords( sim, molecule_type, molecule_instance ); // restore previous molecule coords
			}

			// get widom insertion energy of ghost molecule, add to accumulator. We do this regardless of accept or reject move.
			if( sim->current_step > equil_period && sim->current_step % widom_every == 0 )
			{
				/*
					All molecule, including the one we insert, are composed of a single site.
					We therefore need only 3 coords to specify them spacially,
					in this case just 3 random numers somewhere in sim cell.
				*/
				widom_r[0] = (ran1( &sim->ran1_seed )-0.5)*sim->cell[0];
				widom_r[1] = (ran1( &sim->ran1_seed )-0.5)*sim->cell[1];
				widom_r[2] = (ran1( &sim->ran1_seed )-0.5)*sim->cell[2];

				/*
					use molecule instance == -1 to signify that the molecule is not currently part of the simulation,
					and to use the coordinates in the "widom_r" array to work out the energy it would have if it were.
				*/
				widom_energy = GetMoleculeEnergy( sim, 1, -1, widom_r );
				
				/*
					There is a correction to the chemical potential due to the LJ energy tail correction:
					m_corr = 2*lj_corr
					As we already add the tail correcion in GetMoleculeEnergy, we only need to add 1*lj_corr.
					We can do this by increasing the system-wide counts of all the sites in the molecule by the
					appropriate number, calculating the correction, then restoring the old counts.
				*/
				mu_corr = GetLJ126TailCorrectionEnergy( sim ); // tail corrections without ghost molecule
				for( i=0; i<sim->molecule_templates[1].length; i++ )
				{
					sim->site_templates[ sim->molecule_templates[1].site_templates[i] ].count++; // increase site counts to reflect addition of ghost molecule
				}
				mu_corr = GetLJ126TailCorrectionEnergy( sim ) - mu_corr; // delta mu_corr due to ghost molecule tail corrections
				for( i=0; i<sim->molecule_templates[1].length; i++ )
				{
					sim->site_templates[ sim->molecule_templates[1].site_templates[i] ].count--; // reset site counts to old values.
				}
				widom_energy += mu_corr;

				mu_step_acc += exp( -widom_energy/sim->T );
				widom_n_steps++;
			}

			/*
				Add step average into block accumulator, and reset step info
			*/
			if( sim->current_step > equil_period && sim->current_step % sim->save_every == 0 )
			{
				mu_block_acc += mu_step_acc/widom_n_steps;
				mu_step_acc = 0.0;
				widom_n_steps = 0;
				widom_n_blocks++;
			}
		}
		
		store = sim->ran1_seed;
		mu_block_acc = mu_block_acc / widom_n_blocks;
		
		/*
			Print sim results
		*/
		printf( "Rho: %f: data from %lu samples\n", rho, sim->save_every*widom_n_blocks );
		printf( "\tmu = %e (cell %f,%f,%f : %d sites)\n", -sim->T*log( mu_block_acc ), sim->cell[0], sim->cell[1], sim->cell[2], sim->n_sites );

		/*
			Save sim results
		*/
		f =  fopen( "widom_mu.txt", "a" );
		if( f != NULL )
		{
			fprintf( f, "%e %e\n", rho, -sim->T*log( mu_block_acc ) );
			fclose( f );
		}
		
		
		FreeSim( sim );
	}
}

int main( int argc, char ** argv )
{
	WidomExample();
	return 0;
}
