#include "../util/distributions.h"
#include "../core/mc.h"

/*
	Gets the total energy of the system.
	
	Note - we don't have the double counting problem as in GetMoleculeEnergy(); as we can simply
	double loop over i=0->N, j=i+1->N we won't double count energies.
	
	ADDED LREE CORRECTION!
*/
double GetTotalEnergy( MCSim * sim, Distributions * d )
{
	int offset, length, i, j, t1, t2, s1, s2, s3, axis;
	int mol_type, mol_instance;
	double q1, q2, hs1, hs2, eps, sig, r12, r23, rv12[3], rv23[3];
	double theta;
	
	double LJ_energy, LJTC_energy, Q_energy, QP_energy, HS_energy, bond_energy, angle_energy;
	
	Molecule * mol;
	
	LJ_energy = 0.0;
	LJTC_energy = 0.0;
	Q_energy = 0.0;
	QP_energy = 0.0;
	HS_energy = 0.0;
	bond_energy = 0.0;
	angle_energy = 0.0;
	
	/*
		As we have contiguous blocks of data for each molecule, we can subsume the loop over
		pairs into a loop over molecules; this is also needed to check whether sites are bound!
	*/
	for( mol_type = 0; mol_type < sim->n_molecule_templates; mol_type++ )
	{
		mol = &sim->molecule_templates[mol_type];
		length = mol->length;
		for( mol_instance = 0; mol_instance < mol->count; mol_instance++ )
		{
			offset = GetMoleculeStartSite( sim, mol_type, mol_instance );
			/*
				Loop over sites in the current molecule
			*/
			for( i=offset; i<offset+length; i++ )
			{
				t1 = sim->site_template_indices[i];
				q1 = sim->site_templates[t1].q;
				hs1 = sim->site_templates[t1].hard_sphere_radius;
				/*
					Get nonbonded energies for sites in the sim.
				*/
				for( j=i+1; j<sim->n_sites; j++ )
				{
					if( AreBound( sim, mol_type, offset, i, j ) == 1 ) continue;

					t2 = sim->site_template_indices[j];
					q2 = sim->site_templates[t2].q;
					hs2 = sim->site_templates[t2].hard_sphere_radius;

					eps = GetLJEpsFromTable( sim, t1, t2 ) / NAV; // as eps is eexpressed per mole
					sig = GetLJSigFromTable( sim, t1, t2 );

					r12 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[i*3], &sim->site_coords[j*3], rv12, sim->cell, sim->PBC ) );

					if( r12 < sim->LJ_cut )
						LJ_energy += GetLJ126Energy( r12, eps, sig );

					Q_energy += GetDirectCoulombEnergy( r12, q1, q2, sim->e1 );
					HS_energy += GetHardSphereEnergy( r12, hs1 + hs2 );

					/* test for inf energy and bail, to save time avaluating rest of stuff. */
					if( HS_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
				}
				/*
					Site to charged plane interactions
				*/
				for( j=0; j<sim->n_charged_plane_templates; j++ )
				{
					axis = sim->charged_plane_templates[j].axis;
					rv12[0] = 0.0;
					rv12[1] = 0.0;
					rv12[2] = 0.0;
					rv12[axis] = sim->site_coords[(i*3) + axis] - sim->charged_plane_templates[j].pos;
				
					MIC( 1, rv12, rv12, sim->cell, sim->PBC );
					r12 = fabs( rv12[axis] ); /* important; want absolute distance for GetInfiniteWallCoulombEnergy below. */
					QP_energy += GetInfiniteWallCoulombEnergy( r12, q1, sim->charged_plane_templates[j].sigma, sim->e1 );
				}
				/*
					ADDED - LREE correction.
					
					THIS IS THE ONLY DIFFERENCE OVER THE DEFAULT GETTOTALENERGY()
				*/
				Q_energy += d->GetLREECorrection( sim, mol_type, mol_instance, NULL );
			}
			/*
				Get bond energies for sites in this molecule.
			*/
			for( i=0; i<mol->n_bonds; i++ )
			{
				s1 = offset + mol->bonds[(i*2)+0];
				s2 = offset + mol->bonds[(i*2)+1];

				r12 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[s1*3], &sim->site_coords[s2*3], rv12, sim->cell, sim->PBC ) );

				bond_energy += GetSpringEnergy( r12, mol->bond_k[i]/NAV, mol->bond_eq[i], mol->bond_rigid[i] ); // k divided by NAV as expressed per mole

				/* test for rigid bond violation and bail, to save time avaluating rest of stuff. */
				if( bond_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
			}
			/*
				Get angle energies for sites in this molecule.
			*/
			for( i=0; i<mol->n_angles; i++ )
			{
				s1 = offset + mol->angles[(i*3)+0];
				s2 = offset + mol->angles[(i*3)+1];
				s3 = offset + mol->angles[(i*3)+2];

				r12 = GetSeparationSquaredAndVectorMIC( &sim->site_coords[s1*3], &sim->site_coords[s2*3], rv12, sim->cell, sim->PBC );
				r23 = GetSeparationSquaredAndVectorMIC( &sim->site_coords[s3*3], &sim->site_coords[s2*3], rv23, sim->cell, sim->PBC );

				r12 = sqrt( r12 );
				r23 = sqrt( r23 );
				
				/*
					Sometimes, when you have EXACTLY straight angles, acos( stuff ) won't work, as |stuff| has overflowed
					ever so slightly over 1.0. This occurred in testing with straight polymers, so now we have a little guard
					in here to fix that.
				*/
				theta = ( rv12[0]*rv23[0] + rv12[1]*rv23[1] + rv12[2]*rv23[2] ) / (r12*r23);
				if( theta >  1.0 - 1e-10 ) theta =  1.0 - 1e-10;
				if( theta < -1.0 + 1e-10 ) theta = -1.0 + 1e-10;
				theta = acos( theta );
				
				angle_energy += GetSpringEnergy( theta, mol->angle_k[i]/NAV, mol->angle_eq[i], mol->angle_rigid[i] ); // k divided by NAV as expressed per mole

				/* test for rigid angle violation and bail, to save time avaluating rest of stuff. */
				if( angle_energy == HUGE_VAL ) return HUGE_VAL; /* infinity on IEEE machines, else largest floating point value representable */
			}
		}
	}
	
	/*
		Should really have a term for the charged plane energies if you are planning on moving planes which share an axis during the sim,
		otherwise it will always be a constant contribution to the energy which we should be able to ignore. Planes with orthogonal axes
		will always supply a constant energy as they are infinite, so any possible arrangement of their position gives the same energy.
		
		IMPORTANT: this will obviously be a different situation entirely if the charge on the infinite planes is changing during the simulation!
		Then we will need to consider the interactions between all the planes on all the axes!
	*/
	
	LJTC_energy += GetLJ126TailCorrectionEnergy( sim );

	return LJ_energy + LJTC_energy + Q_energy + QP_energy + HS_energy + bond_energy + angle_energy;
}


MCSim * make_sim(	int wdim1, int wdim2, double wq1, double wq2, double whsr1, double whsr2,
					int ndipole, double dq1, double dq2, double dhsr1, double dhsr2, double dlen,
					double x, double y, double z,
					double extent,
					double sig1, double sig2,
					double T,
					int is_spherical )
{
	MCSim * sim;
	int i, j, k;
	double a, theta, r1, r2, rvec[3];

	sim = MakeEmptySim();
		AddSiteInfo( sim, "w1", wq1, whsr1, 0.0, 1.0 );
		AddSiteInfo( sim, "w2", wq2, whsr2, 0.0, 1.0 );

		AddSiteInfo( sim, "d1", dq1, dhsr1, 0.0, 1.0 );
		AddSiteInfo( sim, "d2", dq2, dhsr2, 0.0, 1.0 );

		AddMoleculeInfo( sim, "wall1", wdim1*wdim1 );
			AddSiteToMolecule( sim, "wall1", "w1" );

		AddMoleculeInfo( sim, "wall2", wdim2*wdim2 );
			AddSiteToMolecule( sim, "wall2", "w2" );

		AddMoleculeInfo( sim, "dipole", ndipole );
			AddSiteToMolecule( sim, "dipole", "d1" );
			AddSiteToMolecule( sim, "dipole", "d2" );
			AddBondToMolecule( sim, "dipole", 1, 2, dlen, 1.0, 1 );

		AddChargedPlaneInfo( sim, 2, -z/2.0, sig1 );
		AddChargedPlaneInfo( sim, 2,  z/2.0, sig2 );

		sim->cell[0] = x;
		sim->cell[1] = y;
		sim->cell[2] = z;
		
		sim->PBC[0] = 1;
		sim->PBC[1] = 1;
		sim->PBC[2] = 0;
		
		sim->e1 = 78.3;

	InitialiseSim( sim, T );
	PrintSim( sim );
	
	/*
		Place wall sites, where they exist
	*/
	k = 0;
	a = x / wdim1;
	for( i=0; i<wdim1; i++ )
	{
		for( j=0; j<wdim1; j++ )
		{
			sim->site_coords[(k*3)+0] = (-sim->cell[0]/2.0) + a/2.0 + a*i;
			sim->site_coords[(k*3)+1] = (-sim->cell[1]/2.0) + a/2.0 + a*j;
			sim->site_coords[(k*3)+2] = (-sim->cell[2]/2.0);
			k++;
		}
	}
	a = x / wdim2;
	for( i=0; i<wdim2; i++ )
	{
		for( j=0; j<wdim2; j++ )
		{
			sim->site_coords[(k*3)+0] = (-sim->cell[0]/2.0) + a/2.0 + a*i;
			sim->site_coords[(k*3)+1] = (-sim->cell[1]/2.0) + a/2.0 + a*j;
			sim->site_coords[(k*3)+2] = ( sim->cell[2]/2.0);
			k++;
		}
	}
	/*
		Place dipoles; same starting config, random offset, random rotate.
		Check for boundary violation on z, and hard sphere clash.
		
		Note; I had a sneaky bug where the dipole length was equal to the x dimension of
		the sim, and the initial site placments were at x = -dlen/2 and x = dlen/2 so after
		PDB wrapping they were actually sat right on top of one another! This led to 100% accept
		on rotate (as rotationally invarient structure) and about 97% accept for translate
		(as effectively a single, neutral site formed of 2 superimposed +1 and -1 charges,
		so only reject was where moved out of z bounds)!
		
		Therefore, place on z axis because:
			a. Likely to be much longer than x and y
			b. No PBC wrapping, so impossible to have that situation!
			
		Because the dipoles are bound sites, the sites can't interact. However, where
		dlen < box/2, the dipole length will always be incorrect due to PBC - PBC causes the
		separation between any sites in the system to be < box/2!
	*/
	
	if( dlen >= sim->cell[0]/2.0 || dlen >= sim->cell[1]/2.0 )
	{
		printf( "Dipole length: %f. [x,y] = [%f,%f]\n", dlen, sim->cell[0], sim->cell[1] );
		JERROR( "Dipole length is > box/2 on x or y, so incorrect length will always be returned." );
	}
	for( i=0; i<ndipole; i++ )
	{
		if( i > 0 && i % 10 == 0 ) printf( "attempting to place dipole %d ...\n", i );
		k = GetMoleculeStartSite( sim, 2, i );
		sim->site_coords[(k*3)+0] = 0.0;
		sim->site_coords[(k*3)+1] = 0.0;
		sim->site_coords[(k*3)+2] = -dlen/2.0;

		sim->site_coords[((k+1)*3)+0] = 0.0;
		sim->site_coords[((k+1)*3)+1] = 0.0;
		sim->site_coords[((k+1)*3)+2] = dlen/2.0;
		
		// random COM in cell.
		rvec[0] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[0];
		rvec[1] = (ran1(&sim->ran1_seed)-0.5) * sim->cell[1];
		rvec[2] = (ran1(&sim->ran1_seed)-0.5) * 2.0*extent;
		TranslateMolecule( sim, 2, i, rvec );
		// random orientation
		UniformSpherePoint( rvec, &sim->ran1_seed );
		theta = ran1(&sim->ran1_seed) * 2.0*M_PI;
		RotateMolecule( sim, 2, i, rvec, theta );
		
		/*
			Check z bounds violation.
		*/
		if( is_spherical > 0 )
		{
			rvec[0] = 0.5*(sim->site_coords[((k+0)*3)+2] + sim->site_coords[((k+1)*3)+2]);
			rvec[1] = rvec[0];
		}
		else
		{
			rvec[0] = sim->site_coords[ (k*3)   +2];
			rvec[1] = sim->site_coords[((k+1)*3)+2];
		}
		
		if( fabs(rvec[0]) >= extent || fabs(rvec[1]) >= extent )
		{
			printf( "Extent rejection.\n" );
			i--;
			continue;
		}

		// check hard sphere collisions with other sites. only check dipoles, as wall sites are in exluded volume.
		for( j=GetMoleculeStartSite( sim, 2, 0 ); j<k; j++ )
		{
			// first dipole site
			r1 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[j*3], &sim->site_coords[(k+0)*3], rvec, sim->cell, sim->PBC ) );
			// second dipole site
			r2 = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[j*3], &sim->site_coords[(k+1)*3], rvec, sim->cell, sim->PBC ) );
			if( r1 < dhsr1+dhsr2 || r2 < dhsr1+dhsr2 )
			{
				printf( "clash rejection: %f, %f\n", r1, r2 );
				i--; // ensure this dipole is randomly positioned again
				j = k;
				break;
			}
		}
	}
	
	return sim;
}



void DipoleRun( MCSim * sim, double extent, double rotate_prob, double delta_theta, double *meanU, double *meanU_variance, int is_spherical, long equil, long max )
{
	Distributions * d;
	StatBins * s;
	jsocket * js;
	
	int start_site, mol_type, mol_inst, N;
	int doing_what, did_what[2][2];
	
	double oldU, newU, deltaU, totalU;
	double rvec[3], theta;
	
	d = new Distributions( 2, 500, 101, sim );
	s = new StatBins( 50000, 0.0, 2.0, 1 ); // was 20k
	
	sim->max_steps  = max;
	sim->save_every = 10000;
	
	totalU = 0.0;
	N = sim->n_sites;
	
	/*
		Main MC loop is here
	*/
	for( sim->current_step=0; sim->current_step<sim->max_steps; sim->current_step++ )
	{
		d->Accumulate( sim );
		
		/*
			If we've passed the equil period, start accumulating the total energy
		*/
		if( sim->current_step >= equil )
		{
			if( sim->current_step == equil ) totalU = GetTotalEnergy( sim, d );
			s->IndexAdd( 0, totalU/(KB*sim->T*sim->T) );
		}
		
		mol_type = 2;
		mol_inst = (int) floor( ran1(&sim->ran1_seed) * sim->molecule_templates[mol_type].count );

		oldU = GetMoleculeEnergy( sim, mol_type, mol_inst, NULL ) + d->GetLREECorrection( sim, mol_type, mol_inst, NULL );
		PushMoleculeCoords( sim, mol_type, mol_inst );

		/*
			Move or rotate, as appropriate
		*/
		if( ran1(&sim->ran1_seed) < rotate_prob )
		{
			UniformSpherePoint( rvec, &sim->ran1_seed );
			theta =  (ran1(&sim->ran1_seed)-0.5) * delta_theta;
			RotateMolecule( sim, mol_type, mol_inst, rvec, theta );
			doing_what = 0;
		}
		else
		{
			rvec[0] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
			rvec[1] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
			rvec[2] = (ran1(&sim->ran1_seed)-0.5) * sim->delta_r;
			TranslateMolecule( sim, mol_type, mol_inst, rvec );
			doing_what = 1;
		}
		
		did_what[doing_what][0]++; // increase attempt account for the type of move

		/*
			Accept or reject on boundary violations, and new energy.
		*/
		start_site = GetMoleculeStartSite( sim, mol_type, mol_inst );

		if( is_spherical > 0 )
		{
			rvec[0] = 0.5*(sim->site_coords[(start_site*3)+2] + sim->site_coords[((start_site+1)*3)+2]);
			rvec[1] = rvec[0];
		}
		else
		{
			rvec[0] = sim->site_coords[ (start_site*3)   +2];
			rvec[1] = sim->site_coords[((start_site+1)*3)+2];
		}

		if( fabs(rvec[0]) >= extent || fabs(rvec[1]) >= extent )
		{
			PopMoleculeCoords( sim, mol_type, mol_inst );
			sim->rejected++;
		}
		else
		{
			newU = GetMoleculeEnergy( sim, mol_type, mol_inst, NULL ) + d->GetLREECorrection( sim, mol_type, mol_inst, NULL );
				
			deltaU = newU - oldU;
			if( deltaU < 0.0 || ran1(&sim->ran1_seed) < exp( -deltaU/(KB*sim->T) ) )
			{
				sim->accepted++;
				did_what[doing_what][1]++; // increase accept count for the type of move
				if( sim->current_step >= equil ) totalU += deltaU;
			}
			else
			{
				PopMoleculeCoords( sim, mol_type, mol_inst );
				sim->rejected++;
			}
		}

		/*
			Save info etc.
		*/
		if( sim->current_step > 0 && sim->current_step % sim->save_every == 0 )
		{
			/*
				Update visualisation, where connected.
			*/
			js = GetJSocket( "localhost", KRONENBOURG_PORT, 0 );
			if( js != NULL )
			{
				WriteJSocket( js->socket, sim->cell, sizeof(double)*3 );
				WriteJSocket( js->socket, &sim->n_sites, sizeof(int) );
				WriteJSocket( js->socket, sim->site_template_indices, sizeof(int)*sim->n_sites );
				WriteJSocket( js->socket, sim->site_coords, sizeof(double)*sim->n_sites*3 );
				FreeJSocket( js );
			}
			
			/*
				Print some info
			*/
			printf( "Step %lu (%d%%); %lu accepted (%d%%), %lu rejected.\n", sim->current_step, (int) (100.0*sim->current_step/sim->max_steps), sim->accepted, (int) (100.0*sim->accepted/sim->save_every), sim->rejected );
			if( did_what[0][1] > 0 )
				printf( "\tRotate: %d accepted (%d%%) of %d.\n", did_what[0][1], (int) (100.0*did_what[0][1]/did_what[0][0]), did_what[0][0] );
			if( did_what[1][1] > 0 )
				printf( "\tTranslate: %d accepted (%d%%) of %d.\n", did_what[1][1], (int) (100.0*did_what[1][1]/did_what[1][0]), did_what[1][0] );
			if( sim->current_step >= equil ) printf( "U = %e, <U> = %e, +/- %e\n", totalU/(KB*sim->T), s->block_means[0], s->Variance(0) );

			d->Save( "", sim );
			
			/*
				Reset any appropriate step counters and sim info
			*/
			sim->accepted = 0;
			sim->rejected = 0;
			did_what[0][0] = did_what[0][1] = 0;
			did_what[1][0] = did_what[1][1] = 0;
		}
	}
	
	*meanU = s->block_means[0];
	*meanU_variance = s->Variance( 0 );

	delete d;
	delete s;
}


/*
MCSim * make_sim(	int wdim1, int wdim2, double wq1, double wq2, double whsr1, whsr2,
					int ndipole, double dq1, double dq2, double dhsr1, double dhsr2, double dlen,
					double x, y, z,
					double extent,
					double sig1, double sig2,
					double T )

void SphericalDipoleRun( MCSim * sim, double extent, double rotate_prob, double delta_theta, double meanU, double meanU_variance )
*/


int main( int argc, char ** argv )
{
	MCSim * sim;
	double meanU, meanU_variance;
	
	double sigma, x, y, z, dlen, q, extent;
	int i, ndipoles;
	
	FILE * f;
	

	/*
		Spherical dipole: J Chem Phys 129:105101, 2009
	*/
/*	sigma = -0.07;
	printf( "original sigma: %f\n", sigma );
	sigma = (sigma*1e-20)/ELEM_CHARGE;
	printf( "adjusted sigma: %f\n", sigma );
	
	ndipoles = 100;
	q = 1.0;
	
	x = sqrt( ndipoles*q/fabs(sigma) );
	y = x;

	z = 25.0;
	dlen = 20.0;
	extent = (z/2.0) - (dlen/2.0);

	printf( "x = y = %f, z = %f\n", x, z );
	printf( "total surface charge = 2.0 * %f = %f\n", sigma*x*y, 2.0*sigma*x*y ); 
	printf( "total dipole charge %d * 2.0 * %f = %f\n", ndipoles, q, q*ndipoles*2 ); 
	printf( "dipole length %f\n", dlen );

	sim = make_sim(	0, 0, 0.0, 0.0, 0.0, 0.0,
					ndipoles, q, q, 1.0, 1.0, dlen,
					x, y, z,
					extent,
					sigma, sigma,
					298.0,
					1 );
					
	DipoleRun( sim, extent, 0.5, M_PI, &meanU, &meanU_variance, 1, 1000000, 2000000 );
	printf( "Mean %e, variance %e\n", meanU, meanU_variance );
*/

	/*
		Cylindrical dipole: J Phys A: Math Theor 40:11815-11826 2007
	*/
/*	sigma = -0.005;
	printf( "original sigma: %f\n", sigma );
	sigma = (sigma*1e-20)/ELEM_CHARGE;
	printf( "adjusted sigma: %f\n", sigma );
	
	ndipoles = 25;
	q = 1.0;
	
	x = 100.0;
	y = x;

	z = 100.0;
	dlen = 20.0;
	extent = (z/2.0); // no longer spherical exclusion zone!

	printf( "x = y = %f, z = %f\n", x, z );
	printf( "total surface charge = %f + %f = %f\n", sigma*x*y, -sigma*x*y, x*y*(sigma + -sigma) ); 
	printf( "total dipole charge %d * (%f + %f) = %f\n", ndipoles, q, -q, (q + -q)*ndipoles ); 
	printf( "dipole length %f\n", dlen );
	
	// 1.78 hsr as pi.r^2 = a, and a is 1nm^2 in paper - very rough approximation
	sim = make_sim(	0, 0, 0.0, 0.0, 0.0, 0.0,
					ndipoles, q, -q, 0.5, 0.5, dlen,
					x, y, z,
					extent,
					sigma, -sigma,
					300.0,
					0 );
					
	sim->delta_r = 30.0;
					
	DipoleRun( sim, extent, 0.5, M_PI, &meanU, &meanU_variance, 0, 1000000, 10000000 );
	printf( "Mean %e, variance %e\n", meanU, meanU_variance );
*/	



	/*
		Parameter scaling for thermo integration.
		
		Note that we can scale the charge post-initialisation, but we can't do this to the LJ params
		without using RebuildLJTable()!
	*/
	long seed_store;
	int nscales;
	double param, param_start, param_end, param_delta;
	char buffer[1024];
	double integral, integral_var;
	
	sigma = -0.005;
	printf( "original sigma: %f\n", sigma );
	sigma = (sigma*1e-20)/ELEM_CHARGE;
	printf( "adjusted sigma: %f\n", sigma );
	
	ndipoles = 25;
	q = 1.0;
	
	x = 100.0;
	y = x;
	z = 100.0;
	dlen = 20.0;
	extent = (z/2.0) - (dlen/2.0);
	
	
	printf( "x = y = %f, z = %f\n", x, z );
	printf( "total surface charge = %f + %f = %f\n", sigma*x*y, -sigma*x*y, x*y*(sigma + -sigma) ); 
	printf( "total dipole charge %d * (%f + %f) = %f\n", ndipoles, q, -q, (q + -q)*ndipoles ); 
	printf( "dipole length %f\n", dlen );



	//nscales = 50;
	nscales = atoi( argv[1] );
	param_start = 2000.0;
	param_end = 300.0;
	param_delta = (param_end-param_start)/nscales;
	param = param_start;


/*	sim = make_sim(	0, 0, 0.0, 0.0, 0.0, 0.0,
					ndipoles, q, -q, 0.0, 0.0, param,
					x, y, z,
					extent,
					sigma, -sigma,
					300.0,
					1 );

	int j, mol_type, mol_instance, start_site;
	for( i=0; i<sim->n_sites; i++ )
	{
		GetParentMolecule( sim, i, &mol_type, &mol_instance );
		start_site = GetMoleculeStartSite( sim, mol_type, mol_instance );
		printf( "Site %d: type %d, instance %d (%d)\n", i, mol_type, mol_instance, start_site );
		
		printf( "\tPeers:\n" );
		for( j=start_site; j<start_site+sim->molecule_templates[mol_type].length; j++ )
		{
			printf( "\t\t%d : %d\n", j, AreBound( sim, mol_type, start_site, i, j ) );
		}
		printf( "\tOthers:\n" );
		for( j=start_site+sim->molecule_templates[mol_type].length; j<sim->n_sites; j++ )
		{
			printf( "\t\t%d : %d\n", j, AreBound( sim, mol_type, start_site, i, j ) );
		}
	}
	
	exit( -1 );*/


	sprintf( buffer, "scale_%d_%.1fnm_%.1fnm.txt", nscales, z/10.0, dlen/10.0 );
	f = fopen( buffer, "w" );
	if( f == NULL )
	{
		printf( "unable to open file\n" );
		exit( -1 );
	}
	fclose( f );

	/*
		Reuses previous coords, which should help the gradual scaling.
		Note that distributions and stats are regenerated each time we call DipoleRun, so don't worry about that.
		Also reuses final seed from previous sim, so no worries about the same sequence of pseudorandom numbers for each sim.
	*/
	seed_store = -1;
	integral = 0.0;
	integral_var = 0.0;
	for( i=0; i<=nscales; i++ )
	{
		param = param_start + param_delta*i;

		sim = make_sim(	0, 0, 0.0, 0.0, 0.0, 0.0,
						ndipoles, q, -q, 1.0, 1.0, dlen,
						x, y, z,
						extent,
						sigma, -sigma,
						param,
						1 );
		sim->delta_r = 30.0;
		sim->ran1_seed = seed_store;

		DipoleRun( sim, extent, 0.5, M_PI, &meanU, &meanU_variance, 0, 1000000, 2000000 );
		
		integral -= meanU * param_delta;
		integral_var += meanU_variance;
		
		f = fopen( buffer, "a" );
		fprintf( f, "%e %e %e %e %e\n", param, meanU, meanU_variance, integral, integral_var );
		fclose( f );
		
		seed_store = sim->ran1_seed;
		
		FreeSim( sim );
	}
}