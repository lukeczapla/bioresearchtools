#include "../core/mc.h"

/*
	Tests IO functions of sim.
	
	Creates an example simulation containing all of the aspects of the structure, saves it,
	and then loads it before saving a second time.
	
	Using the console command "diff" on the two files (sim1.sim, sim2.sim) should reveal no differences.
	
	This also shows how to construct a simulation without writing the input text files; this is not reccommended,
	as it can be very verbose and prone to errors. When creating a simulation in this manner, you must call
	InitialiseSim() to change the temperature and all the energies into reduced units. HOWEVER, you should not call
	this routine when you load a file; it is called in the LoadMCSim() routine, and calling it twice will break all
	the energies etc.
	
	Remember that the site indices are zero based!
*/
int main( int argc, char ** argv )
{
	MCSim * sim;

	sim = MakeEmptySim();
		AddSiteInfo( sim, "a",  1.0, 5.0,  6.3, 1.1 );
		AddSiteInfo( sim, "b", -0.5, 0.2, 10.0, 2.3 );

		AddMoleculeInfo( sim, "test", 1 );
			AddSiteToMolecule( sim, "test", "a" );
			AddSiteToMolecule( sim, "test", "b" );
			AddSiteToMolecule( sim, "test", "a" );

			AddBondToMolecule( sim, "test", 1, 2, 3.5, 500e3, 1 );
			AddBondToMolecule( sim, "test", 2, 3, 4.0, 450e3, 0 );

			AddAngleToMolecule( sim, "test", 1, 2, 3, M_PI/2.0, 100e3, 1 );

		/*
			Add two charged planes
		*/
		AddChargedPlaneInfo( sim, 1, 10.0, 1.2 );
		AddChargedPlaneInfo( sim, 2,  0.8, 2.0 );
	InitialiseSim( sim, 202.0 );
	
	sim->cell[0] = 25.0;
	sim->cell[1] = 15.0;
	sim->cell[2] = 23.0;
	
	sim->PBC[1] = 0; // no periodic boundaries on the x axis.

	sim->delta_r = 0.5;
	sim->e1 = 71.2;

	sim->max_steps =    2000000;
	sim->save_every =    500000;
	sim->current_step =       5;
	
	sim->accepted = 12;
	sim->rejected =  5;
	
	/*
		Initial coords for the sites; note that the coordinates are stored as a flat array,
		so three consecutive entries form the x,y,z coords of a site.
		
		Easy to find x coord of site 10, as the offset if therefore (10*3)+0, and the
		z coord of site 52 has offset (52*3)+2 for example.
		
		To get the starting site of a molecule, you can use GetMoleculeStartSite( sim, molecule_type, molecule_instance ).
		Here, molecule_type is the index in the sim->molecule_templates[] array, and molecule_instance is the molecule number
		of that type. Both are zero-based, so for the 5th instance of the first molecule type in the sim you would use
		site_index = GetMoleculeStartSite( sim, 0, 4 ), for example.
	*/
	sim->site_coords[(0*3)+0] = -2.5;
	sim->site_coords[(0*3)+1] = 0.0;
	sim->site_coords[(0*3)+2] = 0.0;

	sim->site_coords[(1*3)+0] = 0.0;
	sim->site_coords[(1*3)+1] = 0.0;
	sim->site_coords[(1*3)+2] = 0.0;

	sim->site_coords[(2*3)+0] = 2.5;
	sim->site_coords[(2*3)+1] = 0.0;
	sim->site_coords[(2*3)+2] = 0.0;

	/*
		Save this sim as "sim1.sim", and then load it in before saving again to file "sim2.sim".
	*/
	SaveMCSim( sim, "sim1.sim" );
	FreeSim( sim );
	
	sim = LoadMCSim( "sim1.sim" );
	SaveMCSim( sim, "sim2.sim" );
	FreeSim( sim );
	
	return 0;
}
