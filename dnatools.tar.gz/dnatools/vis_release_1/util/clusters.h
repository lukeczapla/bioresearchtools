#ifndef CLUSTERS_DEFINED

#include <math.h>

/*
	Class to generate lists of clustered sites in a simulation, and some info on
	the mean cluster radius of gyration and mean cluster size.
*/
class Clusters
{
	public:
		int *cluster_starts, *cluster_nexts, *cluster_ids, *cluster_lengths;
		int max_sites;
		
		double * coords;
		double * cell;
		int * PBC;
		double MIC_val[3];
		double cutsq;

		double mean_rg, mean_size, sigma_rg, sigma_size;
		
		Clusters( int max_sites );
		~Clusters();

		void _recurse( int site, int nsites, int current_cluster );
		double _radius_of_gyration( int cluster );
		
		void GetClusters( int nsites, double cutoff, double * coords_ptr, double * cell_ptr, int * PBC_ptr );
		
};
Clusters::Clusters( int max_clustered_sites )
{
	max_sites = max_clustered_sites+1;
	cluster_starts = new int[max_sites];
	cluster_nexts = new int[max_sites];
	cluster_ids = new int[max_sites];
	cluster_lengths = new int[max_sites];
}
Clusters::~Clusters()
{
	delete [] cluster_starts;
	delete [] cluster_nexts;
	delete [] cluster_ids;
	delete [] cluster_lengths;
}
void Clusters::_recurse( int site, int nsites, int current_cluster )
{	
	int i, site3, i3;
	double r, rvec[3];

	site3 = site*3;

	/*
		This loop is not site+1 ... nsites as we also need to consider sites with lower index; imagine a
		fairly low index site close to a cluster, which should be a part of that cluster; if none of the
		even lower numbered cluster sites are close enough to that site, with only the higher numbered
		cluster sites adjacent to it, we can easily get the situation where the higher numbered sites
		do not even check it as it's lower than their starting recursion number!

		Therefore, index is 0 ... nsites, with checks for previous assignment.
	*/
	for( i=0; i<nsites; i++ )
	{
		/* ignore site i if already assigned to cluster, or if it's checking itself */
		if( cluster_ids[i] != -1 ) continue;
		if( i == site ) continue;

		i3 = i*3;

		/* faster than calling MIC functions, no overhead for calls. */
		rvec[0] = coords[site3 +0] - coords[i3 +0];
		rvec[1] = coords[site3 +1] - coords[i3 +1];
		rvec[2] = coords[site3 +2] - coords[i3 +2];
		rvec[0] -= MIC_val[0] * round( rvec[0]/cell[0] );
		rvec[1] -= MIC_val[1] * round( rvec[1]/cell[1] );
		rvec[2] -= MIC_val[2] * round( rvec[2]/cell[2] );
		r = rvec[0]*rvec[0] + rvec[1]*rvec[1] + rvec[2]*rvec[2];

		if( r < cutsq )
		{
			cluster_lengths[current_cluster]++; /* increase length of current cluster */
			cluster_nexts[i] = cluster_starts[current_cluster]; /* set "next" index of curent cluster to whatever was at the start of this cluster before now */
			cluster_starts[current_cluster] = i; /* add current site to start of the appropriate cluster */
			cluster_ids[i] = current_cluster; /* set cluster id of this site */

			_recurse( i, nsites, current_cluster );
		}
	}
}
double Clusters::_radius_of_gyration( int cluster )
{
	int N, site_i, site_j;
	double acc;
	double r12[3];

	N = cluster_lengths[cluster];

	acc = 0.0;
	if( N == 1 ) return acc;

	for( site_i = cluster_starts[cluster]; site_i != -1; site_i = cluster_nexts[site_i] )
	{
		for( site_j = cluster_starts[cluster]; site_j != -1; site_j = cluster_nexts[site_j] )
		{
			r12[0] = coords[site_i*3 +0] - coords[site_j*3 +0];
			r12[1] = coords[site_i*3 +1] - coords[site_j*3 +1];
			r12[2] = coords[site_i*3 +2] - coords[site_j*3 +2];

			r12[0] -= MIC_val[0] * round( r12[0]/cell[0] );
			r12[1] -= MIC_val[1] * round( r12[1]/cell[1] );
			r12[2] -= MIC_val[2] * round( r12[2]/cell[2] );

			acc += r12[0]*r12[0] + r12[1]*r12[1] + r12[2]*r12[2];
		}
	}

	return sqrt( (1.0/(2.0*N*N)) * acc );
}
void Clusters::GetClusters( int nsites, double cutoff, double * coords_ptr, double * cell_ptr, int * PBC_ptr )
{
	int i, current_cluster;
	double rg;
	
	coords = coords_ptr;
	cell = cell_ptr;
	PBC = PBC_ptr;
	cutsq = cutoff*cutoff;

	MIC_val[0] = cell[0] * PBC[0];
	MIC_val[1] = cell[1] * PBC[1];
	MIC_val[2] = cell[2] * PBC[2];

	if( nsites > max_sites )
	{
		printf( "%s(): passed number of sites (%d) bigger than max (%d)\n", __func__, nsites, max_sites );
		exit( -1 );
	}

	/*
		Clear initial cluster link data.
	*/
	for( i=0; i<max_sites; i++ )
	{
		cluster_starts[i] = -1;
		cluster_nexts[i] = -1;
		cluster_ids[i] = -1;
		cluster_lengths[i] = -1;
	}
	
	current_cluster = 0;
	for( i=0; i<nsites; i++ )
	{
		/* ignore if we already dealt with this site in a previous recursion. */
		if( cluster_ids[i] != -1 ) continue;
		
		/* otherwise we're starting new cluster, as the current site was not assigned to any previous cluster. */
		cluster_starts[current_cluster] = i;
		cluster_lengths[current_cluster] = 1;
		cluster_ids[i] = current_cluster;
		
		_recurse( i, nsites, current_cluster );
		current_cluster++;
	}

	/*
		Mean radius of gyration and cluster size for all the clusters found.
		Also shows you how to walk the linked lists that describe the clusters.
	*/
	mean_rg = 0.0;
	mean_size = 0.0;
	for( i=0; cluster_starts[i] != -1; i++ )
	{
		mean_rg += _radius_of_gyration( i );
		mean_size += cluster_lengths[i];
	}
	mean_rg = mean_rg / i;
	mean_size = mean_size / i;
	
	/*
		Stdev of radius of gyration and cluster size for all the clusters found.
	*/
	sigma_rg = 0.0;
	sigma_size = 0.0;
	for( i=0; cluster_starts[i] != -1; i++ )
	{
		rg = _radius_of_gyration( i );
		sigma_rg += ( mean_rg - rg ) * ( mean_rg - rg );

		sigma_size += (mean_size - cluster_lengths[i]) * (mean_size - cluster_lengths[i]); /* remember - doubles first to force ints into double format! */
	}
	sigma_rg = sqrt( sigma_rg / i );
	sigma_size = sqrt( sigma_size / i );
}

#define CLUSTERS_DEFINED
#endif
