#ifndef DISTRIBUTIONS_INCLUDED

#include "../core/mc.h"
#include "../util/bins.h"

/*
	This class handles the recording of concentration profiles on a given axis for the system.
	
	Note that it also maintains Torrie & Valleau style "charged slabs" data for the calculation
	of the long ranged electrostatic energy correction. This can be accessed via the GetLREECorrection
	routine.
	
	IMPORTANT: the LREE functionality assumes periodicity only on the plane perpendicular to the profile axis,
	and assumes that the distribution on the axis is symmetrical!
*/

class Distributions
{
	public:
		StatBins ** concs;
		StatBins * charge;
		StatBins * LREE_correction;

		int axis, n_concs;
		double bin_vol;
		
		Distributions( int profile_axis, int block_len, int nbins, MCSim * sim );
		~Distributions();
		
		void Accumulate( MCSim * sim );
		double GetLREECorrection( MCSim * sim ); // entire sim
		double GetLREECorrection( MCSim * sim, int site ); // single site
		double GetLREECorrection( MCSim * sim, int mol_type, int mol_instance, double * coords ); // single molecule
		int Save( char * prefix, MCSim * sim );
};

#define DISTRIBUTIONS_INCLUDED
#endif
