#include "distributions.h"

Distributions::Distributions( int profile_axis, int block_len, int nbins, MCSim * sim )
{
	int i;
	double extent;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( profile_axis < 0 || profile_axis > 2 ) JERROR( "Bad profile axis" );
	#endif

	n_concs = sim->n_site_templates;
	axis = profile_axis;
	
	extent = sim->cell[axis] + 1e-10; // add a bit to allow sites to be located right on the sim boundaries.
	
	if( axis == 0 ) bin_vol = (extent/nbins) * sim->cell[1] * sim->cell[2];
	if( axis == 1 ) bin_vol = (extent/nbins) * sim->cell[0] * sim->cell[2];
	if( axis == 2 ) bin_vol = (extent/nbins) * sim->cell[0] * sim->cell[1];

	concs = (StatBins **) malloc( sizeof(StatBins *) * n_concs );
	if( concs == NULL )
	{
		printf( "%s(): unable to allocate concs\n", __func__ );
		exit( -1 );
	}
	
	for( i=0; i<n_concs; i++ ) concs[i] = new StatBins( block_len, -extent/2.0, extent/2.0, nbins );
	charge = new StatBins( block_len, -extent/2.0, extent/2.0, nbins );
	LREE_correction = new StatBins( block_len, -extent/2.0, extent/2.0, nbins );
}
Distributions::~Distributions()
{
	int i;
	for( i=0; i<n_concs; i++ )
	{
		delete concs[i];
	}
	free( concs );
	
	delete charge;
	delete LREE_correction;
}
void Distributions::Accumulate( MCSim * sim )
{
	int i, j, type, bin;
	double r, q, dim1, dim2, sigma, e_acc;
	double last_block;
	
	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
	#endif
	
	/*
		Go through all sites in sim, and add 1 to appropriate bin accumulators for that type and position.
		Note that we're not using the standard StatBins add functions, as we don't want the bin counts to be
		incremented on each addition - only increment each bin PER ACCUMULATE CALL!
	*/
	for( i=0; i<sim->n_sites; i++ )
	{
		type = sim->site_template_indices[i];
		q = sim->site_templates[type].q;
		r = sim->site_coords[(i*3) + axis];
		
		bin = concs[type]->Map( &r );
		if( bin == -1 )
		{
			printf( "%s(): unable to map coordinate %e of type %d\n", __func__, r, type );
			exit( -1 );
		}
		concs[type]->accs[bin] += 1.0;
		charge->accs[bin] += q;
	}
	
	/*
		Update all acc counts at the same time.
	*/
	for( type=0; type<n_concs; type++ ) concs[type]->IncrementAllAccumulatorCounts();
	for( bin=0; bin<charge->total_nbins; bin++ ) charge->acc_counts[bin]++;
	
	/*
		Block complete? Then symmetrise the charge accumulator and update the block info.
		We also update the LREE correction when we update the charge block data.
	*/
	if( charge->acc_counts[0] >= charge->block_len )
	{
		/*
			Get charge accumulators as symmetrised average over previous block.
			Note - WE HAVE TO DO THIS HERE OR THE CODE BELOW WILL NOT WORK! WE END UP WITH THE CENTRAL BIN(S)
			HAVING THE WRONG VALUE, WHICH SCREWS UP THE LREE CALCULATIONS! WE CAN'T SIMPLY COMBINE IT INTO THE
			LOOP BELOW AS WE NEED TO MAKE SURE BOTH SIDES OF THE PROFILE ARE DIVIDED BY THE ACC COUNT BEFORE WE USE THEM!
			
			Note that the commented loop should only be enabled where the system is actually symmetrical! It's not used by default, as I
			don't know what your system is!
		*/
		for( bin=0; bin<charge->total_nbins; bin++ ) charge->accs[bin] /= charge->acc_counts[bin];
/*		for( bin = 0; bin <= charge->total_nbins/2; bin++ )
		{
			i = (charge->total_nbins-1)-bin; // "mirror" bin

			charge->accs[bin]  = charge->accs[bin];
			charge->accs[bin] += charge->accs[i];

			charge->accs[bin] /= 2.0;
			charge->accs[i]  = charge->accs[bin];
		}*/

		/*
			Update the block charge profile from the accumulator.

			We've already divided the charge accumulator bins by the accumulator count in the symmetrisation code above,
			so we can use the value of the accumulation bins directly.

			Running average and variance stuff; see Knuth, The Art of C Programming volume 2, 3rd edition (p. 232)
		*/
		for( bin=0; bin<charge->total_nbins; bin++ )
		{
			if( charge->fptr != NULL ) fprintf( charge->fptr, "%d %e\n", bin, charge->accs[bin]/bin_vol );


			last_block = charge->accs[bin];

			charge->block_sum_sqs[bin] = charge->block_sum_sqs[bin] + (last_block*last_block);
			charge->block_means[bin] = (charge->block_means[bin]*charge->block_counts[bin]) + last_block;
			charge->block_counts[bin]++;
			charge->block_means[bin] = charge->block_means[bin]/charge->block_counts[bin];

			// reset accumulator data
			charge->accs[bin] = 0.0;
			charge->acc_counts[bin] = 0;
   		}
			
		/*
			Calculate long ranged electrostatic energy correction.
			site and plane r are simplified, due to same start point (min_r) and bin width (delta_r).
			
			distance = fabs( site_r - plane_r )
			with site_r = min_r + (0.5+i)*delta_r
			with plane_r = min_r + (0.5+j)*delta_r
			fabs( [min_r + 0.5*delta_r + i*delta_r] - [min_r + 0.5*delta_r + j*delta_r] )
			
			So separation = fabs( delta_r*i - delta_r*j ) - floats must come first to cast entire expression as float!
		*/
		if( axis == 0 ) { dim1 = sim->cell[1]; dim2 = sim->cell[2]; }
		if( axis == 1 ) { dim1 = sim->cell[0]; dim2 = sim->cell[2]; }
		else			{ dim1 = sim->cell[0]; dim2 = sim->cell[1]; }
	
		for( i=0; i<LREE_correction->total_nbins; i++ )
		{
			e_acc = 0.0;
			for( j=0; j<LREE_correction->total_nbins; j++ )
			{
				r = fabs(charge->deltas[0]*i - charge->deltas[0]*j );

				sigma = charge->block_means[j] / (dim1*dim2);

				e_acc += GetInfiniteWallCoulombEnergy( r, 1.0, sigma, sim->e1 );
				e_acc -= GetFiniteWallCoulombEnergyTV( r, 1.0, sigma, sim->e1, dim1 ); /* ASSUMES PLANE IS SQUARE! ie. d1 == d2! */
			}
			LREE_correction->block_means[i] = e_acc;
		}
	}
}
/*
	For entire sim
*/
double Distributions::GetLREECorrection( MCSim * sim )
{
	int i, bin, type;
	double q, r, U;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
	#endif

	U = 0.0;

	for( i=0; i<sim->n_sites; i++ )
	{
		type = sim->site_template_indices[i];
		q = sim->site_templates[type].q;
		r = sim->site_coords[(i*3) + axis];

		bin = LREE_correction->Map( &r );
		if( bin == -1 ) JERROR( "Unable to map bin" );

		U += LREE_correction->block_means[bin] * q;
	}
	return U;
}
/*
	For single site.
*/
double Distributions::GetLREECorrection( MCSim * sim, int site )
{
	int bin, type;
	double q, r, U;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( site < 0 || site >= sim->n_sites ) JERROR( "Bad site index" );
	#endif

	U = 0.0;

	type = sim->site_template_indices[site];
	q = sim->site_templates[type].q;
	r = sim->site_coords[(site*3) + axis];

	bin = LREE_correction->Map( &r );
	if( bin == -1 ) JERROR( "Unable to map bin" );

	U += LREE_correction->block_means[bin] * q;

	return U;
}
/*
	For single molecule, internal or external.
*/
double Distributions::GetLREECorrection( MCSim * sim, int mol_type, int mol_instance, double * coords )
{
	int i, bin, offset, length, type;
	double q, r, U;

	#ifdef DEBUG
		if( sim == NULL ) JERROR( "NULL sim passed" );
		if( mol_type < 0 || mol_type >= sim->n_site_templates ) JERROR( "Bad molecule type" );
		if( mol_instance < 0 && coords == NULL ) JERROR( "External molecule instance specified, but coords pointer is NULL" );
	#endif

	offset = 0;
	length = sim->molecule_templates[mol_type].length;
	U = 0.0;

	if( mol_instance > -1 )
	{
		offset = GetMoleculeStartSite( sim, mol_type, mol_instance );
		coords = sim->site_coords;
	}
	
	for( i=offset; i<offset+length; i++ )
	{
		type = sim->molecule_templates[mol_type].site_templates[i-offset];
		q = sim->site_templates[type].q;
		r = coords[(i*3) + axis];

		bin = LREE_correction->Map( &r );
		if( bin == -1 ) JERROR( "Unable to map bin" );

		U += LREE_correction->block_means[bin] * q;
	}
	return U;
}
int Distributions::Save( char * prefix, MCSim * sim )
{
	char buffer[1024];
	int type;
	
	for( type=0; type<n_concs; type++ )
	{
		sprintf( buffer, "%s%s.dist", prefix, sim->site_templates[type].name );
		concs[type]->Save( buffer, 1.0/bin_vol );
	}
	sprintf( buffer, "%scharge.dist", prefix );
	charge->Save( buffer, 1.0/bin_vol );
	
	return 1;
}
