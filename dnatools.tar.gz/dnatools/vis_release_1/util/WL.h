#ifndef WL_INCLUDED

#include "../core/misc.h"
#include "jsocket.h"
#include "jthread.h"

#define WL_MAGIC "skynet"
#define WL_VERSION 1

#define WL_REFINE_RELATIVE 0
#define WL_REFINE_ABSOLUTE 1

#define WL_NO_SERVER_DEFINED   -1
#define WL_NO_CONNECTION       -2
#define WL_COMMUNICATION_ERROR -3
#define WL_SIMULATION_FINISHED -4

#define WL_HINT_UPDATE 0
#define WL_HINT_KILL   1

#define WL_STATUS_INACTIVE 0
#define WL_STATUS_CLOSING  1
#define WL_STATUS_ACTIVE   2


/*
	This structure is used in the communications to ensure that a connection is
	actually valid, and not random data from some other process.
*/
typedef struct
{
	char magic[10];
	uint32_t simID;
	uint32_t version;
} WLSimHeader;



/*
	Info on a WL simulation.
	
	Initial generation is zero, which is assumed by WLServer and WLNode to provide automatic
	setup, so don't change it!
	
	Get, GetServerInfo and Set can be overwritten to use HTTP server to allow Internet enabled
	simulations.
	
	excess_acc is the excess bias accumulated since last refinement of the dU.
	bias is the overal total bias function.
*/
class WLInfo
{
	public:
	
		uint32_t simID;
		
		char server_IP[1024];
		int server_port;
		uint32_t server_pid;
		
		uint32_t finished;
		uint32_t generation;
		uint32_t bias_length;
		uint32_t refine_type;
		double dU, dU_decay;
		double refine_tol, conv_tol;
		
		double *excess_acc, *bias, *temp;
		
		WLInfo( uint32_t simulation_ID, int server_TCPIP_port, uint32_t bias_array_length );
		~WLInfo();
		
		int Get( uint32_t simulation_ID );
		int GetServerInfo( uint32_t simulation_ID ); // limited version of above. ignores arrays etc
		int Set( uint32_t simulation_ID );
};



/*
	The WLServer listens on a specified port for incoming excess bias information, and updates the connected client with the new
	overall bias function.
	
	--------------------------------------------------------------------------------------------------------
	Note that it expects the incoming data to be the excess bias over the last time the simulation contacted
	a server! This is ensured in the WLNode class, but of you are writing your own version you must bear
	this in mind!
	--------------------------------------------------------------------------------------------------------
	
	Where generation mismatches occur between the server data and incoming client data,	the server ignores the incoming data and
	simply writes the current, correct simulation info back to the client. As WLInfo objects start with generation 0, and servers
	set their startup generation to 1 on creation (new sim) or whatever the snapshot says, when a node joins a simulation for the
	first time the current client values will be ignored and automatically overwritten with the contemporary sim data from the server.
	
	Activate(): opens socket to listen on for incoming connections, and launches the server listen thread with the contents of the last
		snapshot as the current data (if exists, else uses initial server data).
	Deactivate(): closes the socket, shuts down the listener thread.
	
	There are perdiodic checks in the server thread, where active, that will shut the server down if it detects that another
	server has taken over. This is handy as only one process can bind to a particular port; a multicore machine with separate
	nodes on each core can therefore have problems in each node trying to bind to the same port. We should therefore only keep the
	port bound when we need to, and release it when we're not actively serving, in order to allow other nodes on that multicore
	machine to promote themselves to the sim server if they need to.
	
	Note 1: The server will not discover it's been usurped for a maximum of x seconds, with x defined in the server loop.
		However, AmServer() will IMMEDIATELY TELL YOU whether it is!
		
	Note 2: Due to this delay on the server detecting it has been usurped, it's problematic to force-usurp the active server
		with a different node on the same machine, for example where multicore, as the socket is already bound by the server
		and so the node won't be able to open the listening socket. Could get around this with a WL_USURP messge to
		the active server, but this doesn't solve the problems where the server is unresponsive; one other method is to swap
		to a different port; the nodes will automatically detect this when they try to sync and use the new port, but we don't
		know what port we'll end up using and this could cause problems with other unrelated on the machine which might use that socket!
*/
class WLServer
{
	public:
		
		WLInfo *info;
		
		int server_thread_status;
		pthread_t server_thread;
		jsocket * js;
		
		WLServer( uint32_t simID, int port, uint32_t length, double * initial_bias );
		~WLServer();
		
		void * _serve();
		int _handle_update( int socket );
		
		int AmIServer();
		
		int Activate();
		void Deactivate();
};



/*
	WLInfo object "info" is barely used; only server info functionality and generation are needed, along with bias.
	The initial parameters you pass are only used if the WLNode is the first to start in this simulation (the internal
	server uses them), otherwise the node gets the important info from the active server on Sync(), and the internal
	server loads the last snapshot if and when it comes online.
	
	Recall that the generation variable in WLInfo is set to zero on construction; therefore, a new WLNode object will
	automatically sync to current server data on first call to Sync(), with the appropriate arrays therefore also initialised.
	The server will ignore whtaever we pass as the excess bias on initial sync, so don't worry.
	
	The parameters passed to the constructor are only relevent when we're the first node to start the sim; otherwise they are
	ignored, as they aren't used in the WLNode anyway, and the server will try to load a snapshot to restart the sim at an appropriate
	place. Only where this snapshot does not exist will the information passed to the constructor be used to seed the simulation, as
	the server then assumes that the simulation is starting from scratch.
	
	PromoteToServer() attempts to promote the node to the server for this sim. Care should be taken with this. It's also problematic
	to promote a node to server when another node on the same machine currently hold the server position; this is due to the server
	binding the specified port, which it will not release until it detects another server has usurped it. However, you can only
	usurp on successful server creation, which will be prevented as we can;t get the socket. Hence, deadlock. See WLServer comments
	for some ideas on how to get around this, unfortunately none of which are particularly elegant.
*/
class WLNode
{
	public:
		
		uint32_t simID;
		
		WLInfo * active_server_info;
		WLServer * internal_server;
		
		char node_string[1024];
		
		WLNode( uint32_t simulation_ID, int server_port, uint32_t bias_length, double * initial_bias, double deltaU, double deltaU_decay, uint32_t refine_type, double refine_tolerance, double converge_tolerance );
		~WLNode();
		
		int AmIServer();
		char * GetNodeString();

		int Sync( double *bias, double *deltaU );

		jsocket * GetConnectionToServer( int * result );
		int PromoteToServer();

		int PromotingSync( double *bias, double *deltaU, int n_attempts_before_promoting, int n_attempts_after_promoting, int delay_deconds );
		
};


#define WL_INCLUDED
#endif

