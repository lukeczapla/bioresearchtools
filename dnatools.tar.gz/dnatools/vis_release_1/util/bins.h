#ifndef BINS_INCLUDED

#include <unistd.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "../core/misc.h"

/*
	The Bins object allows arbitrary dimensional binning.
	
	Internally, these bins are a 1D array of double precision floating point values, but an n-dimensional
	set of bins may be added to, for example, via CoordAdd( [r1, ..., rn], value ) with the appropriate coords
	passed as an array.
	
	To get the index of the bin corresponding to a particular set of coordinates you can call the Map() function
	which takes an array of coords as the parameter.
	
	IndexAdd(), CoordAdd(), Map() and Unmap() should all return -1 for failure and 1 for
	success. Only exception is where NULL pointers passed - then it's an automatic exit(-1).
	
	Other routines should only exit(-1) where there's simply no chance of the program being
	correct, such as NULL pointers and where it's impossible the parameters are correct.
	
	The Statbins has 2 ways to generate statistics; the default is a Knuth-style running mean and
	variance, but you can also switch on explicit file spooling, where each block average is written
	to a specified file (either as overwrite existing file or append) which allows postprocessing. Be
	careful with this mode; it can create large files quickly, and the disk IO can severely slow the
	program execution and cause network issues where your home directory is not on the local machine!
*/
class Bins
{
	public:
		int ndims, total_nbins;
		double *accs;
		int * acc_counts;
		
		double *mins, *maxs, *deltas;
		int *nbins, *offset_multipliers;

		/*
			Is it possible to have variable length constructor arguments?
			Would make this easier, that's for sure.
		*/
		Bins();
		Bins( char * filepath );
		Bins( int number_of_dimensions, ... );
		virtual ~Bins();
		
		/*
			These don't change regardless of what you're going to do.
		*/
		int Map( double * coords );
		int Unmap( int bin_index, double * coords );
		int CoordAdd( double * coords, double value );
		
		void _print();
		
		/*
			These, however, DO change.
			
			IndexAdd is called by CoordAdd(), after calling Map( coords ); therefore,
			change IndexAdd to support whatever you're interested doing when a value is
			added to the bins. By default, this simply adds the value to the appropriate bin.
			
			Save() is also dependent on what you want to do; by default, it writes all the bins
			as a series of lines containing:
			
			the bin index, coord1, ..., coordn, acc_count, acc, acc*multiplier
		*/
		virtual int IndexAdd( int i, double value );
		virtual int Save( char * fpath, double multiplier );
		virtual void Clear();
};

class StatBins : public Bins
{
	public:
		int block_len;
		int *block_counts;
		double *block_means, *block_sum_sqs;
		FILE * fptr;
		
		StatBins( char * filepath );
		StatBins( int block_length, double rmin, double rmax, int nbins );
		StatBins( int block_length, double rmin1, double rmax1, int nbins1, double rmin2, double rmax2, int nbins2 );
		virtual ~StatBins();
		
		/*
			These don't change regardless of what you're going to do.
			
			SetStatsOutput() should not really be used! It was a debug method to check the running variance etc.
		*/
		int SetStatsOutput( char * fpath, char * flags );
		void IncrementAllAccumulatorCounts(); // +1 to all acc_counts. Frequently used where StatBins represents a function, as opposed to discrete values, and you want to update them all at once.

		/*
			Return the variance of a particular bin, via the index or coords.
		*/
		double Variance( int bin );
		double Variance( double * coords );

		/*
			These, however, COULD change.
			
			IndexAdd differs from the one in Bins as it performs block averages on the accumulator and puts the results in block_means etc.
			Save is similar to the function in Bins, but also saves the block count, raw block average, and block average*multiplier on the end
			of each line.
		*/
		virtual int IndexAdd( int i, double value );
		virtual int Save( char * fpath, double multiplier );
		virtual void Clear();
};

#define BINS_INCLUDED
#endif
