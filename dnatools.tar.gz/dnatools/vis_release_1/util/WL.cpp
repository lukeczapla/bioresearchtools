#include "WL.h"

/*
	Validates a socket connection, to check whether it's valid for this simulation.
*/
int _validate_socket( int socket, uint32_t simID, int go_first )
{
	WLSimHeader me, them;
	
	strcpy( me.magic, WL_MAGIC );
	me.version = htonl( WL_VERSION );
	me.simID = htonl( simID );
	
	if( go_first == 1 )
	{
		if( WriteJSocket( socket, me.magic, sizeof(me.magic) ) == -1 ) return -1;
		if( WriteJSocket( socket, &me.version, sizeof(me.version) ) == -1 ) return -1;
		if( WriteJSocket( socket, &me.simID, sizeof(me.simID) ) == -1 ) return -1;
		
		if( ReadJSocket( socket, them.magic, sizeof(them.magic) ) == -1 ) return -1;
		if( ReadJSocket( socket, &them.version, sizeof(them.version) ) == -1 ) return -1;
		if( ReadJSocket( socket, &them.simID, sizeof(them.simID) ) == -1 ) return -1;
	}
	else
	{
		if( ReadJSocket( socket, them.magic, sizeof(them.magic) ) == -1 ) return -1;
		if( ReadJSocket( socket, &them.version, sizeof(them.version) ) == -1 ) return -1;
		if( ReadJSocket( socket, &them.simID, sizeof(them.simID) ) == -1 ) return -1;

		if( WriteJSocket( socket, me.magic, sizeof(me.magic) ) == -1 ) return -1;
		if( WriteJSocket( socket, &me.version, sizeof(me.version) ) == -1 ) return -1;
		if( WriteJSocket( socket, &me.simID, sizeof(me.simID) ) == -1 ) return -1;
	}
	
	if( strcmp( me.magic, them.magic) != 0 )
	{
		printf( "%s(): failed validation on magic string\n", __func__ );
		return -1;
	}
	if( me.version != them.version )
	{
		printf( "%s(): failed validation on version\n", __func__ );
		return -1;
	}
	if( me.simID != them.simID )
	{
		printf( "%s(): failed validation on simID\n", __func__ );
		return -1;
	}

	return 1;	
}





/*

	WLInfo code.

*/
WLInfo::WLInfo( uint32_t simulation_ID, int server_TCPIP_port, uint32_t bias_array_length )
{
	uint32_t i;

	simID = simulation_ID;

	// default server info is whoever created this object
	GetMyIP( server_IP, 1024 );
	server_port = server_TCPIP_port;
	server_pid = getpid();

	finished = 0;
	generation = 0;
	bias_length = bias_array_length;
	refine_type = WL_REFINE_RELATIVE;
	dU = 1.0;
	dU_decay = 0.25;
	refine_tol = 0.8;
	conv_tol = 0.0;

	excess_acc = new double[bias_length];
	bias = new double[bias_length];
	temp = new double[bias_length];
	
	for( i=0; i<bias_length; i++ )
	{
		excess_acc[i] = 0.0;
		bias[i] = 0.0;
		temp[i] = 0.0;
	}
}
WLInfo::~WLInfo()
{
	delete [] excess_acc;
	delete [] bias;
	delete [] temp;
}
int WLInfo::Get( uint32_t simulation_ID )
{
	uint32_t i, old_length;
	char filepath[1024], buffer[1024];
	FILE * f;
	
	sprintf( filepath, "%d.siminfo", simulation_ID );
	if( (f = fopen(filepath,"r")) == NULL )
	{
		printf( "%s(): unable to get simulation info\n", __func__ );
		return -1;
	}
	
	old_length = bias_length;
	
	fscanf( f, "%u\n", &simID );
	
	if( simID != simulation_ID )
	{
		printf( "%s(): unexpected simID (%u) read; expected %u\n", __func__, simID, simulation_ID );
		fclose( f );
		return -1;
	}

	fscanf( f, "%s\n", server_IP );
	fscanf( f, "%d\n", &server_port );
	fscanf( f, "%u\n", &server_pid );

	fscanf( f, "%u\n", &finished );
	fscanf( f, "%u\n", &generation );
	fscanf( f, "%u\n", &bias_length );
	fscanf( f, "%u\n", &refine_type );
	
	fscanf( f, "%s\n", buffer );
	dU = atof( buffer );
	
	fscanf( f, "%s\n", buffer );
	dU_decay = atof( buffer );

	fscanf( f, "%s\n", buffer );
	refine_tol = atof( buffer );
	
	fscanf( f, "%s\n", buffer );
	conv_tol = atof( buffer );
	
	if( old_length != bias_length )
	{
		printf( "%s(): ERROR: bias length has changed from %u to %u\n", __func__, old_length, bias_length );
		exit( -1 );
	}
	
	for( i=0; i<bias_length; i++ )
	{
		fscanf( f, "%s\n", buffer );
		excess_acc[i] = atof( buffer );
	}
	for( i=0; i<bias_length; i++ )
	{
		fscanf( f, "%s\n", buffer );
		bias[i] = atof( buffer );
	}
	
	fclose( f );
	return 1;
}
int WLInfo::GetServerInfo( uint32_t simulation_ID )
{
	uint32_t old_length;
	char filepath[1024], buffer[1024];
	FILE * f;
	
	sprintf( filepath, "%d.siminfo", simulation_ID );
	if( (f = fopen(filepath,"r")) == NULL )
	{
		printf( "%s(): unable to get simulation info\n", __func__ );
		return -1;
	}
	
	old_length = bias_length;
	
	fscanf( f, "%u\n", &simID );
	
	if( simID != simulation_ID )
	{
		printf( "%s(): unexpected simID (%u) read; expected %u\n", __func__, simID, simulation_ID );
		fclose( f );
		return -1;
	}

	fscanf( f, "%s\n", server_IP );
	fscanf( f, "%d\n", &server_port );
	fscanf( f, "%u\n", &server_pid );

	fscanf( f, "%u\n", &finished );
	fscanf( f, "%u\n", &generation );
	fscanf( f, "%u\n", &bias_length );
	fscanf( f, "%u\n", &refine_type );
	
	fscanf( f, "%s\n", buffer );
	dU = atof( buffer );
	
	fscanf( f, "%s\n", buffer );
	dU_decay = atof( buffer );

	fscanf( f, "%s\n", buffer );
	refine_tol = atof( buffer );
	
	fscanf( f, "%s\n", buffer );
	conv_tol = atof( buffer );
	
	fclose( f );
	return 1;
}
int WLInfo::Set( uint32_t simulation_ID )
{
	uint32_t i;
	char filepath[1024];
	FILE * f;
	
	sprintf( filepath, "%d.siminfo", simulation_ID );
	if( (f = fopen(filepath,"w")) == NULL )
	{
		printf( "%s(): unable to get simulation info\n", __func__ );
		return -1;
	}
	
	fprintf( f, "%u\n", simID );
	
	fprintf( f, "%s\n", server_IP );
	fprintf( f, "%d\n", server_port );
	fprintf( f, "%u\n", server_pid );

	fprintf( f, "%u\n", finished );
	fprintf( f, "%u\n", generation );
	fprintf( f, "%u\n", bias_length );
	fprintf( f, "%u\n", refine_type );
	
	fprintf( f, "%e\n", dU );
	fprintf( f, "%e\n", dU_decay );

	fprintf( f, "%e\n", refine_tol );
	fprintf( f, "%e\n", conv_tol );
	
	for( i=0; i<bias_length; i++ ) fprintf( f, "%e\n", excess_acc[i] );
	for( i=0; i<bias_length; i++ ) fprintf( f, "%e\n", bias[i] );
	
	fclose( f );
	return 1;
}






/*

	WLServer code.

*/
void * _server_thread_launcher( void * ptr )
{
	if( ptr == NULL ) JERROR( "NULL pointer passed" );
	return ((WLServer *)ptr)->_serve();
}
WLServer::WLServer( uint32_t simID, int port, uint32_t length, double * initial_bias )
{
	uint32_t i;
	
	info = new WLInfo( simID, port, length );
	if( initial_bias != NULL )
	{
		for( i=0; i<length; i++ )
		{
			info->excess_acc[i] = initial_bias[i];
			info->bias[i] = initial_bias[i];
		}
	}
	else
	{
		for( i=0; i<length; i++ )
		{
			info->excess_acc[i] = 0.0;
			info->bias[i] = 0.0;
		}
	}
	
	/*
		IMPORTANT! By default, the WLInfo generation is zero
		on creation, but we set it to 1 in a server so any incoming
		client connections which have joined the sim for the first time
		are recognised as such, and their incoming excess bias data is
		ignored - with the current sim data being written back to the client.
	*/
	info->generation = 1;

	js = NULL;
	
	server_thread_status = WL_STATUS_INACTIVE;
}
WLServer::~WLServer()
{
	Deactivate();
	delete info;
}
/*
	Launches the listener socket and thread for the server.
*/
int WLServer::Activate()
{
	char hostname[1024];
	WLInfo * temp_info;
	
	if( server_thread_status == WL_STATUS_ACTIVE ) return 1;
	
	/*
		check for activating in a closing period; this an awkward
		edge case, but shouldn't take long to resolve.
		Wait for full shutdown; the jsocket is deleted in the server
		thread loop, so creating a new one here in a WL_STATUS_CLOSING
		situation runs the risk of a race condition where we create
		a new one, and then the thread loop deletes it afterwards when
		it closes down!
		could mutex some stuff, but this is a little simpler.
	*/
	while( server_thread_status == WL_STATUS_CLOSING )
	{
		usleep( 100000 ); // delay for 1/10 second
	}
	
	if( gethostname( hostname, 1024 ) != 0 )
	{
		printf( "%s(): unable to call gethostname(). This server will not be activated.\n", __func__ );
		return -1;
	}

	/*
		As we're attempting to bind the socket, this should bail if it's already bound, saving us the possibility
		of a race condition overwriting a snapshot that has been created by another server coming online below.
		
		If the socket is already bound, there are 2 possibilities; the previous server was this one, and it's come online
		again so fast that the OS has not had a chance to release the port yet, or the other server is running on the same
		machine, as might be the case for a multicore or multi CPU machine.
	*/
	js = GetJSocket( hostname, info->server_port, 1 );
	if( js == NULL )
	{
		printf( "%s() unable to create jsocket. This server will not be activated.\n", __func__ );
		return -1;
	}

	/*
		Can we get the previous snapshot for this simulation?
	*/
	temp_info = new WLInfo( info->simID, info->server_port, info->bias_length );
	if( temp_info->Get( info->simID ) == -1 )
	{
		printf( "%s(): no snapshot, creating one.\n", __func__ );
		/*
			Looks like we can't; assume we're starting simulation from scratch.
		*/
		if( info->Set( info->simID ) == -1 )
		{
			printf( "%s() unable to create snapshot, having failed to load a previous restart point. This server will not be activated.\n", __func__ );
			FreeJSocket( js );
			delete temp_info;
			return WL_COMMUNICATION_ERROR;
		}
		delete temp_info;
	}
	else
	{
		if( temp_info->finished == 1 )
		{
			printf( "%s(): attempting to activate on finished simulation.\n", __func__ );
			FreeJSocket( js );
			delete temp_info;
			return WL_SIMULATION_FINISHED;
		}
		/*
			Write over the loaded server data with out own current
			node info, and set our data to be the snapshot with the
			corrected server info.
		*/
		strcpy( temp_info->server_IP, info->server_IP );
		temp_info->server_pid = info->server_pid;

		delete info;
		info = temp_info;

		/*
			Write our updated stuff
		*/
		if( info->Set( info->simID ) == -1 )
		{
			printf( "%s() unable to update snapshot to reflect change in server. This server will not be activated.\n", __func__ );
			FreeJSocket( js );
			delete temp_info;
			return WL_COMMUNICATION_ERROR;
		}

		printf( "%s(): snapshot located: generation %u, resuming.\n", __func__, info->generation );
	}
	
	/*
		Only create thread etc after we've loaded previous snapshot! Prevents
		race condition on loading the snapshot data. Again, could mutex stuff
		but this is simpler.
	*/
	if( pthread_create( &server_thread, NULL, _server_thread_launcher, this ) != 0 )
	{
		printf( "%s() unable to create pthread. This server will not be activated.\n", __func__ );
		FreeJSocket( js );
		return -1;
	}

	return 1;
}
/*
	Closes the listener socket and thread for the server.
*/
void WLServer::Deactivate()
{
	if( server_thread_status != WL_STATUS_ACTIVE ) return;
	
	server_thread_status = WL_STATUS_CLOSING;
	if( pthread_join( server_thread, NULL ) != 0 ) JERROR( "Unable to join server thread" );
	server_thread_status = WL_STATUS_INACTIVE;
}
int WLServer::AmIServer()
{
	WLInfo * check;
	
	if( server_thread_status != WL_STATUS_ACTIVE ) return -1;

	check = new WLInfo( info->simID,1,1 ); // last 2 params irrelevent, overwritten below.

	if( check->GetServerInfo( info->simID ) == -1 )
	{
		printf( "%s(): failed on getting info\n", __func__ );
		delete check;
		return -1;
	}

	if( info->server_pid != check->server_pid )
	{
		printf( "%s(): failed on pid: %u %u\n", __func__, info->server_pid, check->server_pid );
		delete check;
		return -1;
	}

	if( info->server_port != check->server_port )
	{
		printf( "%s(): failed on port\n", __func__ );
		delete check;
		return -1;
	}

	/*
		Do IP strcmp last, as it's slowest check.
	*/
	if( strcmp(info->server_IP,check->server_IP) != 0 )
	{
		printf( "%s(): failed on IP\n", __func__ );
		delete check;
		return -1;
	}
	
	return 1;
}
void * WLServer::_serve()
{
	int new_connection, returned;

	char buffer[1024];
	int client_port, client_family;
	struct sockaddr_storage client_ss;
	socklen_t client_ss_len;
	uint32_t client_hint;
	
	WLInfo * usurper;
	time_t old_time, current_time;

	usurper = new WLInfo( info->simID,1,1 ); // second 2 params irrelevent, overwritten where used.

	time( &old_time );
	
	server_thread_status = WL_STATUS_ACTIVE;

	printf( "%s(): Server %s : port %u, pid %u has come online, %s", __func__, info->server_IP, info->server_port, info->server_pid, ctime(&old_time) );
	printf( "\tgeneration %d\n", info->generation );
	printf( "\tdU %e, dU_decay %e\n", info->dU, info->dU_decay );
	printf( "\trefine_type %d, refine_tol %e, conv_tol %e\n", info->refine_type, info->refine_tol, info->conv_tol );

	while( 1 )
	{
		/*printf( "ping! %d\n", server_thread_status );
		printf( "\tgeneration %u, dU %e, dU_decay %e\n", info->generation, info->dU, info->dU_decay );
		printf( "\trefine_type %u, refine_tol %e, conv_tol %e\n", info->refine_type, info->refine_tol, info->conv_tol );*/

		/*
			Check whether we should stop the loop.
		*/
		if( server_thread_status == WL_STATUS_CLOSING )
		{
			printf( "%s(): server_status changed to close, leaving loop.\n", __func__ );
			break;
		}

		/*
			Periodic checks on whether we're still the server for this simulation. If not, switch to
			idle mode. If we are, then save a snapshot of the sim data for restarts if it all goes wrong
			at some point..
		*/
		time( &current_time );
		if( current_time - old_time >= 60 )
		{
			/*
				Check to see if something has usurped us as the server before we save any snapshots etc.
				We don't want to overwrite more recent data, or start a tug-of-war race condition with the current server.
			*/
			if( AmIServer() == -1 )
			{
				usurper->GetServerInfo( info->simID );
				printf( "%s(): Usurped! Me / them\n", __func__ );
				printf( "\tIP: %s  / %s\n", info->server_IP, usurper->server_IP );
				printf( "\tPort: %d  / %d\n", info->server_port, usurper->server_port );
				printf( "\tpid: %u  / %u\n", info->server_pid, usurper->server_pid );
				break;
			}
			/*
				I am still king! Well, server anyway. Take a snapshot for future servers to take over efficiently.
			*/
			else
			{
				printf( "%s(): writing snapshot, %s", __func__, ctime(&current_time) );
				printf( "\tgeneration %u\n", info->generation );
				printf( "\tdU %e, dU_decay %e\n", info->dU, info->dU_decay );
				printf( "\trefine_type %d, refine_tol %e, conv_tol %e\n", info->refine_type, info->refine_tol, info->conv_tol );
				info->Set( info->simID );
			}
			time( &old_time );
		}
	
		/*
			Timout wait on incoming connections.
		*/
		new_connection = ListenJSocket( js, &client_ss, &client_ss_len, 1, 0 );
		if( new_connection > 0 )
		{
			get_socketaddr_info( &client_ss, &client_family, &client_port, buffer, sizeof(buffer) );
			/*
				Is this a valid communications attempt, or has one of us got lost somewhere?
				This prevents data from other programs on the listen port ruining the simulation data.
			*/
			if( _validate_socket( new_connection, info->simID, 0 ) == -1 )
			{
				printf( "%s(): validate failed for client %s port %d via socket fd %d.\n", __func__, buffer, client_port, new_connection );
				close( new_connection );
				continue;
			}
	
			/*
				Decide what to do with the connection
			*/
			if( ReadJSocket( new_connection, &client_hint, sizeof(client_hint) ) == -1 )
			{
				printf( "%s(): unable to read hint for client %s port %d via socket fd %d.\n", __func__, buffer, client_port, new_connection );
				close( new_connection );
				continue;
			}
			client_hint = ntohl( client_hint );
			
			switch( client_hint )
			{
				case WL_HINT_UPDATE:
					returned = _handle_update( new_connection );
					if( returned == -1 )
					{
						printf( "%s(): there was a problem in the update.\n", __func__ );
					}
				break;

				case WL_HINT_KILL:
					printf( "%s(): got kill message\n", __func__ );
					server_thread_status = WL_STATUS_CLOSING;
				break;

				default:
					printf( "%s(): unknown client intention; hint is %u\n", __func__, client_hint );
				break;
			}

			close( new_connection );
		}
	}
	
	// change our status and cleanup etc
	delete usurper;
	FreeJSocket( js );
	js = NULL;
	server_thread_status = WL_STATUS_INACTIVE;
	printf( "%s(): Server %s:%u pid %u has gone offline, %s", __func__, info->server_IP, info->server_port, info->server_pid, ctime(&old_time) );
	
	return NULL;
}
int WLServer::_handle_update( int socket )
{
	uint32_t i, incoming_gen;
	int should_refine;
	double minU, maxU;
	
	/*printf( "Server info before update (gen %u, dU %e):\n", info->generation, info->dU );
	printf( "index, excess, bias\n" );
	for( i=0; i<info->bias_length; i++ )
	{
		printf( "%u %e %e\n", i, info->excess_acc[i], info->bias[i] );
	}*/
	
	/*
		Assumes the incoming data is the excess bias potential over the last time the client talked to a server!
	*/
	if( ReadJSocket( socket, &incoming_gen, sizeof(incoming_gen) ) == -1 )
	{
		return -1;
	}
	incoming_gen = ntohl( incoming_gen );
	
	if( ReadJSocket( socket, info->temp, sizeof(double)*info->bias_length ) == -1 )
	{
		return -1;
	}
	
	/*
		Only update the overall bias where incoming generation is consistent with ours!
		Otherwise, ignore incoming data; this is to prevent situations where very old data
		suddenly appears, with relatively large deltaU, which makes a nice refined surface
		all craggy again; this is VERY BAD, as we've probably since switched to a smaller
		deltaU so it'll take ages just to get back to where we were before!
		"should_refine" is first used as a check to see if we've initialised minU and maxU yet,
		and then used to check whether we should refine deltaU accordinag the the appropriate
		refinement parameter and tolerance.
	*/
	if( incoming_gen == info->generation )
	{
		should_refine = 0;
		maxU = 0.0;
		minU = 0.0;
		for( i=0; i<info->bias_length; i++ )
		{
			info->excess_acc[i] += info->temp[i];
			info->bias[i] += info->temp[i];

			if( should_refine == 0 )
			{
				should_refine = 1;
				minU = info->excess_acc[i];
				maxU = info->excess_acc[i];
			}
			else
			{
				if( info->excess_acc[i] < minU ) minU = info->excess_acc[i];
				if( info->excess_acc[i] > maxU ) maxU = info->excess_acc[i];
			}
		}
	
		should_refine = 0;
		if( info->refine_type == WL_REFINE_RELATIVE &&  minU/maxU >= info->refine_tol ) should_refine = 1;
		if( info->refine_type == WL_REFINE_ABSOLUTE &&  minU/info->dU >= info->refine_tol ) should_refine = 1;
		if( should_refine == 1 )
		{
			printf( "%s(): refining; minU is %.2e (%d visits) maxU is %.2e (%d visits)\n", __func__, minU, (int) (minU/info->dU), maxU, (int) (maxU/info->dU) );
			info->generation++;
			info->dU *= info->dU_decay;
			for( i=0; i<info->bias_length; i++ ) info->excess_acc[i] = 0.0;
		}
	}
	else
	{
		printf( "%s(): incorrect generation on incoming data (%d, as opposed to %d); ignoring data, and transmitting correct information.\n", __func__, incoming_gen, info->generation );
	}
	
	/*
		Have we actually converged after the new data is processed?
	*/
	if( info->dU <= info->conv_tol )
	{
		printf( "%s(): sim converged; dU (%e) < conv_tol (%e)\n", __func__, info->dU, info->conv_tol );
		/*
			Notify that the sim has finished via the sim information.
			Also, change the thread status; this will be caught immediately,
			as the loop in _serve() checks this value before accepting new connections.
		*/
		info->finished = 1;
		info->Set( info->simID );
		server_thread_status = WL_STATUS_CLOSING;
	}

	/*printf( "Server info after update (gen %u, dU %e):\n", info->generation, info->dU );
	printf( "index, excess, bias\n" );
	for( i=0; i<info->bias_length; i++ )
	{
		printf( "%u %e %e\n", i, info->excess_acc[i], info->bias[i] );
	}*/

	/*
		Write updated information to the connected client
	*/
	incoming_gen = htonl( info->generation );
	if( WriteJSocket( socket, &incoming_gen, sizeof(incoming_gen) ) == -1 )
	{
		printf( "%s(): problem in writing updated sim info\n", __func__ );
		return -1;
	}
	if( WriteJSocket( socket, &info->dU, sizeof(info->dU) ) == -1 )
	{
		printf( "%s(): problem in writing updated sim info\n", __func__ );
		return -1;
	}
	if( WriteJSocket( socket, info->bias, sizeof(double)*info->bias_length ) == -1 )
	{
		printf( "%s(): problem in writing updated sim info\n", __func__ );
		return -1;
	}
	
	return 1;
}




































/*

	WLNode code.

*/
WLNode::WLNode( uint32_t simulation_ID, int server_port, uint32_t bias_length, double * initial_bias, double deltaU, double deltaU_decay, uint32_t refine_type, double refine_tolerance, double converge_tolerance )
{
	time_t current_time;
	
	simID = simulation_ID;
	
	/*
		note that we don't use all the info we passed in the node itself; it will
		get the current sim information from the active server when it syncs. The
		starting setup is for the current node, in case we're the first to start
		for this sim.
	*/
	active_server_info = new WLInfo( simID, server_port, bias_length );
	sprintf( node_string, "%d.%s.%u", simID, active_server_info->server_IP, getpid() ); // active_server_info is currently just the info for this node.
	time( &current_time );
	printf( "%s(): Node %s has been created, %s", __func__, GetNodeString(), ctime(&current_time) );
	/*
		set up internal server info; this will be ignored unless this node is the first
		to start, and it can't find a snapshot to restart the sim. It will also come
		online when we can't locate or contact the server for this sim.
	*/
	internal_server = new WLServer( simID, server_port, bias_length, initial_bias );
		internal_server->info->refine_type = refine_type;
		internal_server->info->dU = deltaU;
		internal_server->info->dU_decay = deltaU_decay;
		internal_server->info->refine_tol = refine_tolerance;
		internal_server->info->conv_tol = converge_tolerance;
}
WLNode::~WLNode()
{
	time_t current_time;

	time( &current_time );

	delete active_server_info;
	delete internal_server;
	
	printf( "%s(): Node %s has been deleted, %s", __func__, GetNodeString(), ctime(&current_time) );
}
int WLNode::Sync( double *bias, double *deltaU )
{
	uint32_t i, hint, gen;
	double dU;
	
	int result;
	jsocket * js;
	
	if( bias == NULL || deltaU == NULL )
	{
		printf( "%s(): NULL bias or deltaU passed!", __func__ );
		exit( -1 );
	}
	
	js = GetConnectionToServer( &result );
	if( js == NULL )
	{
		printf( "%s(): unable to get connection to server\n", __func__ );
		return result;
	}
	
	/*
		Put excess bias over last sync into temp array; it's this array
		that we'll send to the server.
		
		Don't worry about what might happen here is we've not got info->bias
		set up; if this is the case, we're sync'ing for the first time, and
		the generation mismatch will cause the server to ignore it and send
		the correct data, which will correctly set up info->bias at the end
		of this routine. This also returns an appropriate array in "bias", so
		it's all good.
	*/
	for( i=0; i<active_server_info->bias_length; i++ )
	{
		active_server_info->temp[i] = bias[i] - active_server_info->bias[i];
	}
	
	/*printf( "node info before update (gen %u, dU %e):\n", info->generation, info->dU );
	printf( "index, temp, bias_in, bias_old\n" );
	for( i=0; i<info->bias_length; i++ )
	{
		printf( "%u %e %e %e\n", i, info->temp[i], bias[i], info->bias[i] );
	}*/
	
	
	/*
		Write our data to the server.
	*/
	hint = htonl( WL_HINT_UPDATE );
	if( WriteJSocket( js->socket, &hint, sizeof(hint) ) == -1 )
	{
		printf( "%s(): unable to write hint\n", __func__ );
		FreeJSocket( js );
		return WL_COMMUNICATION_ERROR;
	}

	gen = htonl( active_server_info->generation );
	if( WriteJSocket( js->socket, &gen, sizeof(gen) ) == -1 )
	{
		printf( "%s(): unable to write generation\n", __func__ );
		FreeJSocket( js );
		return WL_COMMUNICATION_ERROR;
	}

	if( WriteJSocket( js->socket, active_server_info->temp, sizeof(double)*active_server_info->bias_length ) == -1 )
	{
		printf( "%s(): unable to write excess bias\n", __func__ );
		FreeJSocket( js );
		return WL_COMMUNICATION_ERROR;
	}

	/*
		Read new data from server.
	*/
	if( ReadJSocket( js->socket, &gen, sizeof(gen) ) == -1 )
	{
		printf( "%s(): unable to read generation\n", __func__ );
		FreeJSocket( js );
		return WL_COMMUNICATION_ERROR;
	}
	gen = ntohl( gen );

	if( ReadJSocket( js->socket, &dU, sizeof(dU) ) == -1 )
	{
		printf( "%s(): unable to read deltaU\n", __func__ );
		FreeJSocket( js );
		return WL_COMMUNICATION_ERROR;
	}

	if( ReadJSocket( js->socket, active_server_info->temp, sizeof(double)*active_server_info->bias_length ) == -1 )
	{
		printf( "%s(): unable to read bias\n", __func__ );
		FreeJSocket( js );
		return WL_COMMUNICATION_ERROR;
	}
	
	FreeJSocket( js );
	
	if( gen != active_server_info->generation )
	{
		printf( "%s(): generation has changed from %u to %u:\n", __func__, active_server_info->generation, gen );
		printf( "\told deltaU %e, new deltaU %e\n", active_server_info->dU, dU );
		active_server_info->generation = gen;
	}
	
	/*
		Copy current bias into the user's array, and set up info->bias so the
		next time we call this routine we can send the correct excess bias since the
		last sync with a server.
		Also set user deltaU to the appropriate value.
	*/
	memcpy( active_server_info->bias, active_server_info->temp, sizeof(double)*active_server_info->bias_length );
	memcpy(                     bias, active_server_info->temp, sizeof(double)*active_server_info->bias_length );
	*deltaU = dU;
	active_server_info->dU = dU;

	/*printf( "node info after update (gen %u, dU %e):\n", info->generation, info->dU );
	printf( "index, temp, bias_out, bias_new\n" );
	for( i=0; i<info->bias_length; i++ )
	{
		printf( "%u %e %e %e\n", i, info->temp[i], bias[i], info->bias[i] );
	}*/
	
	return 1;
}
int WLNode::PromoteToServer()
{
	return internal_server->Activate();
}
int WLNode::PromotingSync( double *bias, double *deltaU, int n_attempts_before_promoting, int n_attempts_after_promoting, int delay_deconds )
{
	int i;
	int result;
	
	/*
		Special case; if there's only one attempt before promotion, we don't need to delay afterwards!
		The second delay in the loop is pretty useless if we're only trying once before promotion.
	*/
	if( n_attempts_before_promoting == 1 )
	{
		result = Sync( bias, deltaU );
		if( result >= 0 || result == WL_SIMULATION_FINISHED )
		{
			return result;
		}
		printf( "%s(): pre-promotion sync attempt failed\n", __func__ );
	}
	else
	{
		for( i=0; i<n_attempts_before_promoting; i++ )
		{
			result = Sync( bias, deltaU );
			if( result >= 0 || result == WL_SIMULATION_FINISHED )
			{
				return result;
			}
			printf( "%s(): pre-promotion sync attempt %d failed\n", __func__, i );
			usleep( 1000000 * delay_deconds );
		}
	}
	
	result = PromoteToServer();
	if( result == WL_SIMULATION_FINISHED ) return result;

	for( i=0; i<n_attempts_after_promoting; i++ )
	{
		usleep( 1000000 * delay_deconds );
		result = Sync( bias, deltaU );
		if( result >= 0 || result == WL_SIMULATION_FINISHED )
		{
			return result;
		}
		printf( "%s(): post-promotion sync attempt %d failed\n", __func__, i );
	}
	
	return result;
}
int WLNode::AmIServer()
{
	return internal_server->AmIServer();
}
char * WLNode::GetNodeString()
{
	return node_string;
}
jsocket * WLNode::GetConnectionToServer( int * returnval )
{
	jsocket * js;
	uint32_t gen_store;
	
	/*
		Try current info first, then try to update info if that fails.
	*/
	js = GetJSocket( active_server_info->server_IP, active_server_info->server_port, 0 );
	if( js == NULL || _validate_socket( js->socket, active_server_info->simID, 1 ) == -1 )
	{
		if( js != NULL ) delete js;
		
		/*
			Note that GetServerInfo() and Get() both overwrite the
			generation; we don't want this in a client sync, as then
			our generation would always end up matching that of the server
			after calling GetConnectionToServer! Obviously bad.
		*/
		gen_store = active_server_info->generation;
		if( active_server_info->GetServerInfo( active_server_info->simID ) == -1 )
		{
			active_server_info->generation = gen_store;
			*returnval = WL_NO_SERVER_DEFINED;
			return NULL;
		}
		active_server_info->generation = gen_store;
		
		/*
			As everything but the arrays is set to that of the
			server (excepting the generation, which we stored and reset)
			we can check for a finish here!
		*/
		if( active_server_info->finished == 1 )
		{
			*returnval = WL_SIMULATION_FINISHED;
			return NULL;
		}
		
		/*
			Fail on updated information as well! This is not good.
		*/
		js = GetJSocket( active_server_info->server_IP, active_server_info->server_port, 0 );
		if( js == NULL || _validate_socket( js->socket, simID, 1 ) == -1 )
		{
			if( js != NULL ) delete js;
			*returnval = WL_NO_CONNECTION;
			return NULL;
		}
	}

	*returnval = 1;
	return js;
}
