#include "bins.h"

/*
 **************************************************
 * Start of Bins class code.                      *
 **************************************************
*/
Bins::Bins()
{
	mins = NULL;
	maxs = NULL;
	deltas = NULL;
	nbins = NULL;
	offset_multipliers = NULL;
	accs = NULL;
	acc_counts = NULL;
	
	total_nbins = 0;
	ndims = 0;
}
Bins::Bins( char * filepath )
{
	FILE * f;
	char buffer[1024];
	char * tokens[10];
	char * delims = ":; \t\n\r";
	int ntokens, line_no, i, count, total_nbins_test;
	double value;
	
	if( filepath == NULL ) JERROR( "NULL filepath passed" );
	
	f = fopen( filepath, "r" );
	if( f == NULL ) JERROR( "Unable to open file" );
	
	line_no = 0;

	if( fscanf( f, "# %d\n", &total_nbins ) < 1 ) JERROR( "Unable to read total bin count" );
	line_no++;
	accs = new double[total_nbins];
	acc_counts = new int[total_nbins];
	
	if( fscanf( f, "# %d\n", &ndims ) < 1 ) JERROR( "Unable to read total number of dimensions" );
	line_no++;
	mins = new double[ndims];
	maxs = new double[ndims];
	deltas = new double[ndims];
	offset_multipliers = new int[ndims];
	nbins = new int[ndims];

	for( i=0; i<ndims; i++ )
	{
		/*
			Apple needs %Lf as opposed to %lf for reading doubles in fscanf() some fucking reason.
			To ensure this bit is portable, and to avoid deciding what data type to use on the current platform,
			I've just parsed the string myself.
		*/
		if( fgets( buffer, 1024, f ) == NULL ) JERROR( "Unable to read dimension line" );
		line_no++;
		ntokens = TokenizeString( buffer, delims, tokens, 10 );
		if( ntokens < 4 ) JERROR( "Bad data on dimension line" );
		
		mins[i] = StringToDouble( tokens[1], filepath, line_no );
		maxs[i] = StringToDouble( tokens[2], filepath, line_no );
		nbins[i] = StringToInt( tokens[3], 10, filepath, line_no );
		
		if( mins[i] >= maxs[i] ) JERROR( "min >= max in dimension line" );
		if( nbins[i] < 1 ) JERROR( "nbins < 1 in dimension line" );
	}
	
	total_nbins_test = 1;
	for( i=0; i<ndims; i++ )
	{
		deltas[i] = (maxs[i]-mins[i])/nbins[i];
		offset_multipliers[i] = total_nbins_test;
		total_nbins_test *= nbins[i];
	}
	
	if( total_nbins_test != total_nbins ) JERROR( "Mismatch between read and calculated bin count" );

	Clear();

	while(1)
	{
		line_no++;

		if( fgets( buffer, 1024, f ) == NULL ) break;

		ntokens = TokenizeString( buffer, delims, tokens, 10 );

		if( ntokens < 1 || buffer[0] == '#' || tokens[0][0] == '#' ) continue;
		if( ntokens < 1 + ndims + 3 ) JERROR( "Too few tokens in bin data line" );
	
		i = StringToInt( tokens[0], 10, filepath, line_no );
		if( i<0 || i>=total_nbins ) JERROR( "Bad bin index in in data line" );

		count = StringToInt( tokens[0+ndims+1], 10, filepath, line_no );
		value = StringToDouble( tokens[0+ndims+2], filepath, line_no );

		acc_counts[i] = count;
		accs[i] = value;
	}

	fclose( f );
}
Bins::Bins( int number_of_dimensions, ... )
{
	int i;
	va_list arg_ptr;
	
	if( number_of_dimensions < 1 ) JERROR( "ndims < 1" );

	ndims = number_of_dimensions;
	
	mins = new double[ndims];
	maxs = new double[ndims];
	deltas = new double[ndims];
	nbins = new int[ndims];
	offset_multipliers = new int[ndims];
	
	va_start( arg_ptr, number_of_dimensions );
	for( i=0; i<ndims; i++ )
	{
		/*
			Get passed params
		*/
		mins[i] = va_arg( arg_ptr, double );
		maxs[i] = va_arg( arg_ptr, double );
		nbins[i] = va_arg( arg_ptr, int );
		/*
			Check they're sane.
		*/
		if( mins[i] >= maxs[i] ) JERROR( "min >= max" );
		if( nbins[i] < 1 ) JERROR( "nbins < 1" );
	}
	va_end( arg_ptr );

	/*
		Set up total n bins, and offsets;
		offset[0] = x = 1;
		offset[1] = y = nbins[x];
		offset[2] = z = nbins[y]*nbins[x];
		... etc ...
	*/
	total_nbins = 1;
	for( i=0; i<ndims; i++ )
	{
		deltas[i] = (maxs[i]-mins[i])/nbins[i];
		offset_multipliers[i] = total_nbins;
		total_nbins *= nbins[i];
	}
	va_end( arg_ptr );
	
	accs = new double[total_nbins];
	acc_counts = new int[total_nbins];
	
	Clear();
}
void Bins::_print()
{
	int i;

	printf( "%d dims, %d bins total:\n", ndims, total_nbins );
	for( i=0; i<ndims; i++ )
	{
		printf( "\t%d: %e -> %e, %e, %d, %d\n", i, mins[i], maxs[i], deltas[i], nbins[i], offset_multipliers[i] );
	}
}
Bins::~Bins()
{
	delete [] mins;
	delete [] maxs;
	delete [] deltas;
	delete [] nbins;
	delete [] offset_multipliers;
	
	delete [] accs;
	delete [] acc_counts;
}
int Bins::Map( double * coords )
{
	int i, bin, bin_offset;
	
	#ifdef DEBUG
		if( coords == NULL ) JERROR( "NULL coords passed" );
	#endif

	bin_offset = 0;
	for( i=ndims-1; i >= 0; i-- )
	{
		if( coords[i] < mins[i] || coords[i] >= maxs[i] ) return -1;
		bin = (int) floor( ((coords[i]-mins[i])/(maxs[i]-mins[i])) * nbins[i] );
		bin_offset += bin * offset_multipliers[i];
	}
	return bin_offset;
}
int Bins::Unmap( int bin_index, double * coords )
{
	int i, int_coord_on_dimension;

	#ifdef DEBUG
		if( coords == NULL ) JERROR( "NULL coords passed" );
	#endif

	if( bin_index < 0 || bin_index >= total_nbins ) return -1;

	for( i=ndims-1; i >= 0; i-- )
	{
		int_coord_on_dimension = bin_index / offset_multipliers[i];
		coords[i] = mins[i] + (0.5+int_coord_on_dimension) * deltas[i];
		
		bin_index -= int_coord_on_dimension * offset_multipliers[i];
	}
	return 1;
}
int Bins::CoordAdd( double * coords, double value )
{
	int i;
	
	#ifdef DEBUG
		if( coords == NULL ) JERROR( "NULL coords passed" );
	#endif

	i = Map( coords );
	if( i == -1 ) return -1;
	
	if( IndexAdd( i, value ) == -1 ) return -1;
	return 1;
}
int Bins::IndexAdd( int i, double value )
{
	if( i < 0 || i >= total_nbins ) return -1;
	accs[i] += value;
	acc_counts[i] += 1;
	return 1;
}
void Bins::Clear()
{
	int i;
	
	for( i=0; i<total_nbins; i++ )
	{
		accs[i] = 0.0;
		acc_counts[i] = 0;
	}
}
int Bins::Save( char * fpath, double multiplier )
{
	FILE * f;
	int i, j;
	double coords[10], old_coords[10];
	
	if( fpath == NULL ) JERROR( "NULL fpath passed" );

	f = fopen( fpath, "w" );
	if( f == NULL )
	{
		printf( "%s(): unable to open file %s\n", __func__, fpath );
		return -1;
	}
	
	fprintf( f, "# %d\n", total_nbins );
	fprintf( f, "# %d\n", ndims );
	for( i=0; i<ndims; i++ )
		fprintf( f, "# %e %e %d\n", mins[i], maxs[i], nbins[i] );
	fprintf( f, "#\n" ); // as StatBins writes block length on this line, write a blank line starting with a hash
	fprintf( f, "# dim_1 .. dim_n, acc count, raw acc, acc * multiplier\n" );
	
	Unmap( 0, old_coords );
	for( i=0; i<total_nbins; i++ )
	{
		Unmap( i, coords );
		
		/*
			Should work for all dimensionalities, as at least the y coord changes on dim break.
		*/
		if( ndims > 1 && coords[1] != old_coords[1] )
		{
			fprintf( f, "\n" );
			old_coords[1] = coords[1];
		}

		fprintf( f, "%d ", i );
		for( j=0; j<ndims; j++ ) fprintf( f, "%e ", coords[j] );
		
		fprintf( f, "%d %e %e\n", acc_counts[i], accs[i], accs[i]*multiplier );
	}
	
	fclose( f );
	return 1;
}



/*
 **************************************************
 * Start of StatBins class code.                  *
 **************************************************
*/
StatBins::StatBins( char * filepath )
{
	FILE * f;
	char buffer[1024];
	char * tokens[10];
	char * delims = ":; \t\n\r";
	int ntokens, line_no, i, total_nbins_test, count;
	double value;
	
	if( filepath == NULL ) JERROR( "NULL filepath passed" );
	
	mins = NULL;
	maxs = NULL;
	deltas = NULL;
	nbins = NULL;
	offset_multipliers = NULL;
	accs = NULL;
	acc_counts = NULL;
	block_means = NULL;
	block_sum_sqs = NULL;
	block_counts = NULL;

	total_nbins = 0;
	ndims = 0;
	
	fptr = NULL;

	f = fopen( filepath, "r" );
	if( f == NULL ) JERROR( "Unable to open file" );
	
	line_no = 0;

	if( fscanf( f, "# %d\n", &total_nbins ) < 1 ) JERROR( "Unble to read total bin count" );
	line_no++;
	accs = new double[total_nbins];
	acc_counts = new int[total_nbins];

	block_means = new double[total_nbins];
	block_sum_sqs = new double[total_nbins];
	block_counts = new int[total_nbins];
	
	if( fscanf( f, "# %d\n", &ndims ) < 1 ) JERROR( "Unable to read ndims line" )
	line_no++;
	mins = new double[ndims];
	maxs = new double[ndims];
	deltas = new double[ndims];
	offset_multipliers = new int[ndims];
	nbins = new int[ndims];
	
	for( i=0; i<ndims; i++ )
	{
		/*
			Apple needs %Lf as opposed to %lf for reading doubles for this to work, but I'm not sure how portable
			that data type is in terms of this code. To ensure portability,
			and to avoid deciding what data type to use on the current platform, I've just parsed the string myself.
		*/
		if( fgets( buffer, 1024, f ) == NULL ) JERROR( "Unable to read dimension line" );
		line_no++;
		ntokens = TokenizeString( buffer, delims, tokens, 10 );
		if( ntokens < 4 ) JERROR( "Too few tokens on dimension line" );
		
		mins[i] = StringToDouble( tokens[1], filepath, line_no );
		maxs[i] = StringToDouble( tokens[2], filepath, line_no );
		nbins[i] = StringToInt( tokens[3], 10, filepath, line_no );
	}
	
	total_nbins_test = 1;
	for( i=0; i<ndims; i++ )
	{
		deltas[i] = (maxs[i]-mins[i])/nbins[i];
		offset_multipliers[i] = total_nbins_test;
		total_nbins_test *= nbins[i];
	}
	
	if( total_nbins_test != total_nbins ) JERROR( "Mismatch between read and calculated bin count" );

	fscanf( f, "# %d\n", &block_len );

	if( block_len < 1 ) JERROR( "Block length < 1" );

	while( fgets( buffer, 1024, f ) != NULL )
	{
		line_no++;
		ntokens = TokenizeString( buffer, delims, tokens, 10 );

		if( ntokens < 1 || buffer[0] == '#' || tokens[0][0] == '#' ) continue;
		if( ntokens < 1 + ndims + 3 ) JERROR( "Too few tokens on bin data line" );
		if( i<0 || i>=total_nbins ) JERROR( "Bad bin index in bin data line" );

		i = StringToInt( tokens[0], 10, filepath, line_no );

		count = StringToInt( tokens[0+ndims+1], 10, filepath, line_no );
		value = StringToDouble( tokens[0+ndims+2], filepath, line_no );
		//if( count >= block_len ) printf( "%s(): suspicious, due to accumulator count (%d) larger than block length (%d) on line %d\n", __func__, count, block_len, line_no );
		acc_counts[i] = count;
		accs[i] = value;

		count = StringToInt( tokens[0+ndims+4], 10, filepath, line_no );
		value = StringToDouble( tokens[0+ndims+5], filepath, line_no );
		block_counts[i] = count;
		block_means[i] = value;
		
		value = StringToDouble( tokens[0+ndims+6], filepath, line_no );
		block_sum_sqs[i] = value;
	}

	fclose( f );
}
StatBins::StatBins( int block_length, double rmin, double rmax, int nbins ) : Bins( 1, rmin, rmax, nbins )
{
	if( block_length < 1 ) JERROR( "Block length < 1" );
	
	block_len = block_length;

	block_counts = new int[total_nbins];
	block_means = new double[total_nbins];
	block_sum_sqs = new double[total_nbins];

	fptr = NULL;
	Clear();
}
StatBins::StatBins( int block_length, double rmin1, double rmax1, int nbins1, double rmin2, double rmax2, int nbins2 ) : Bins( 2, rmin1, rmax1, nbins1, rmin2, rmax2, nbins2 )
{
	if( block_length < 1 ) JERROR( "Block length < 1" );
	
	block_len = block_length;

	block_counts = new int[total_nbins];
	block_means = new double[total_nbins];
	block_sum_sqs = new double[total_nbins];

	fptr = NULL;
	Clear();
}
StatBins::~StatBins()
{
	delete [] block_counts;
	delete [] block_means;
	delete [] block_sum_sqs;
	
	if( fptr != NULL ) fclose( fptr );
}
int StatBins::SetStatsOutput( char * fpath, char * flags )
{
	time_t now;
	int i;
	
	if( fptr != NULL ) fclose( fptr );
	fptr = NULL;

	/* assume fpath == NULL just means stop writing. */
	if( fpath == NULL ) return 1;
	
	fptr = fopen( fpath, flags );
	
	if( fptr == NULL ) JERROR( "NULL file path passed" );
	
	time(&now);
	fprintf( fptr, "# %d\n", total_nbins );
	fprintf( fptr, "# %d\n", ndims );
	for( i=0; i<ndims; i++ ) fprintf( fptr, "# %e %e %d\n", mins[i], maxs[i], nbins[i] );
	fprintf( fptr, "# bin last_block_mean\n" );

	return 1;
}
void StatBins::IncrementAllAccumulatorCounts()
{
	int i;
	double last_block;
	
	for( i=0; i<total_nbins; i++ )
	{
		acc_counts[i] ++;
		
		if( acc_counts[i] >= block_len )
		{
			last_block = accs[i]/acc_counts[i];

			block_sum_sqs[i] = block_sum_sqs[i] + (last_block*last_block);

			block_means[i] = (block_means[i]*block_counts[i]) + last_block;
			block_counts[i]++;
			block_means[i] = block_means[i]/block_counts[i];

			/*
				Write acc average here.
			*/
			if( fptr != NULL ) fprintf( fptr, "%d %e\n", i, last_block );

			accs[i] = 0.0;
			acc_counts[i] = 0;
		}
	}
}
int StatBins::IndexAdd( int i, double value )
{
	double last_block;
	
	if( i < 0 || i >= total_nbins ) 
	{
		printf( "%s(): bin %d is out of range (%d -> %d)\n", __func__, i, 0, total_nbins );
		return -1;
	}
	
	accs[i] += value;
	acc_counts[i]++;
	
	if( acc_counts[i] >= block_len )
	{
		last_block = accs[i]/acc_counts[i];
		
		block_sum_sqs[i] = block_sum_sqs[i] + (last_block*last_block);
		
		block_means[i] = (block_means[i]*block_counts[i]) + last_block;
		block_counts[i]++;
		block_means[i] = block_means[i]/block_counts[i];
		
		/*
			Write acc average here.
		*/
		if( fptr != NULL ) fprintf( fptr, "%d %e\n", i, last_block );
		
		accs[i] = 0.0;
		acc_counts[i] = 0;
	}
	return 1;
}
void StatBins::Clear()
{
	int i;
	
	for( i=0; i<total_nbins; i++ )
	{
		accs[i] = 0.0;
		
		block_means[i] = 0.0;
		block_sum_sqs[i] = 0.0;

		acc_counts[i] = 0;
		block_counts[i] = 0;
	}
}
double StatBins::Variance( int bin )
{
	double sum_sq;
	if( bin < 0 || bin >= total_nbins ) JERROR( "Bad bin index passed" );
	
	if( block_counts[bin] > 1 )
	{
		sum_sq = block_means[bin]*block_counts[bin]; // block sum
		sum_sq = sum_sq*sum_sq; // sum^2
		// sig^2 = 1/(N-1) * (sum_of_squares - sum^2/N)
		return ( block_sum_sqs[bin] - (sum_sq/block_counts[bin]) )/(block_counts[bin]-1);
	}
	else return 0.0;
}
double StatBins::Variance( double * coords )
{
	return Variance( Map(coords) );
}
int StatBins::Save( char * fpath, double multiplier )
{
	FILE * f;
	int i, j;
	double coords[10], old_coords[10];
	
	if( fpath == NULL ) JERROR( "NULL file path passed" );

	f = fopen( fpath, "w" );
	if( f == NULL )
	{
		printf( "%s(): unable to open file %s\n", __func__, fpath );
		return -1;
	}
	
	fprintf( f, "# %d\n", total_nbins );
	fprintf( f, "# %d\n", ndims );
	for( i=0; i<ndims; i++ ) fprintf( f, "# %e %e %d\n", mins[i], maxs[i], nbins[i] );
	fprintf( f, "# %d\n", block_len );
	fprintf( f, "# dim_1 .. dim_n, acc count, raw acc, acc * multiplier, block count, block mean, sum of block squares, block mean * multiplier\n" );
	
	Unmap( 0, old_coords );
	for( i=0; i<total_nbins; i++ )
	{
		Unmap( i, coords );

		/*
			After each set of data, write a blank line; this is handy for plotting directly with gnuplot vis splot command.
			Should work for all dimensionaliites, as at least the minor coord changes on dim break.
		*/
		if( ndims > 1 && coords[1] != old_coords[1] )
		{
			fprintf( f, "\n" );
			old_coords[1] = coords[1];
		}

		fprintf( f, "%d ", i );
		for( j=0; j<ndims; j++ ) fprintf( f, "%e ", coords[j] );
		fprintf( f, "%d %e %e ", acc_counts[i], accs[i], accs[i]*multiplier );
		fprintf( f, "%d %e %e %e\n", block_counts[i], block_means[i], block_sum_sqs[i], block_means[i]*multiplier );

	}
	
	fclose( f );
	return 1;
}
