#ifndef PRESSURES_INCLUDED

/*
	Designed to produce the pressures on a given axis where symmetrical system using methods
	similar to Valleau et al, Gulbrand et al.
	
	The collisional pressure ("S_array") is a little different to the others, as it takes
	the form of a series of graphs that we later interpolate over. As such, it's an array of
	StatBins structures, each individual StatBin structure acting as the function for the
	corresponding bin index of the other contributions.
	
	The actual volume of the various bins used may be different; while all of direct_coulomb,
	charged_plane, combined_electro, and kinetic will have the same number of bins on the same range,
	the range and number of bins of the elements in S_array may (and probably WILL) be different; the
	same problem applies to the bins passed in the Distributions used by Accumulate(). One thing we do
	know is that the AREA of the bin plane normal to the profile axis will not change. This area is
	used often to calculate the pressure contributions from various things, so we store it as a member variable.
	We need to calculate a bin volume in various places, so we use surface_area and whatever delta may be
	used in the appropriate set of bins we're considering.
	
	Note that this class actually supports an array of bins to allow calculation of average pressures over a range of values;
	a lot of the time, you'll only be using one bin so set range_min=0, range_max=2 and pass binning_coord = 1 or something similar.

	This code has been tested to reproduce the values in Table 1 from [1], and also the
	values of Table 1 from [2]  - the latter case only when altered to use the Valleau et al simplification!

	[1] Valleau, Ivkov & Torrie, J Chem Phys 95:520-531, 1991.
	[2] Gulbrand, Jonsson, Wennerstrom & Linse, J Chem Phys 80:2221-2228, 1984.
*/
class SimplePressures
{
	public:

	int axis;
	double W, surface_area, S_min, S_max, S_delta;

	double _infinitePlaneForce( double q1, double sigma, double e1 );
	double _finitePlaneForceG(  double q,  double r,  double sigma, double W,  double e1 );
	double _finitePlaneForceTV( double q,  double r,  double sigma, double W,  double e1 );
	double _directCoulombForce( double q1, double q2, double r,     double dr, double e1 );

	SimplePressures( int acting_axis, double S_min, double S_max, MCSim * sim );
	~SimplePressures();

	void Get( MCSim * sim, Distributions * d, double *dc, double *cp, double *kin, double *S1, double *S2 );
};
SimplePressures::SimplePressures( int acting_axis, double Smin, double Smax, MCSim * sim )
{
	double delta;
	
	axis = acting_axis;

	/*
		Pressure calculations assume axis is normal to a square surface!
		ie. W == dims on other axes than "axis"!
	*/
	
	W = sim->cell[0];
	if( axis == 0 )
	{
		delta = sim->cell[1] - sim->cell[2];
		surface_area = sim->cell[1] * sim->cell[2];
		W = sim->cell[1];
	}
	if( axis == 1 )
	{
		delta = sim->cell[0] - sim->cell[2];
		surface_area = sim->cell[0] * sim->cell[2];
	}
	if( axis == 2 )
	{
		delta = sim->cell[0] - sim->cell[1];
		surface_area = sim->cell[0] * sim->cell[1];
	}
	else
	{
		printf( "%s(): unrecognised axis %d\n", __func__, axis );
		exit( -1 );
	}
	if( fabs(delta) > 1e-20 ) printf( "*** WARNING %s(): functionality assumes square planes! difference between plane axes is %e ***\n", __func__, delta );
	
	S_min = Smin;
	S_max = Smax;
	S_delta = (Smax - Smin)/2.0;
}
SimplePressures::~SimplePressures()
{
}
double SimplePressures::_infinitePlaneForce( double q1, double sigma, double e1 )
{
	return (2.0*M_PI*sigma*q1)/(E0*e1) * ELEM_CHARGE * (ELEM_CHARGE/1e-20);
}
double SimplePressures::_finitePlaneForceG(  double q,  double r,  double sigma, double W,  double e1 )
{
	/* a la Gulbrand et al, J Chem Phys 80:2221 */
	double F, W2, r2;
	
//	W = W/2.0; mimic the V et al value in certain circumstances.
	
	r2 = r*r;
	W2 = W*W;
	
	F = (W2*W2 - r2*r2 - 2.0*W2*r2) / ( (W2+r2) * (W2+r2) ); // this is unitless - multiply out the denominator and see.
	F = asin( F ) + M_PI/2.0;
	return ( (q*sigma)/(2.0*M_PI*E0*e1) ) * F * ELEM_CHARGE * (ELEM_CHARGE/1e-20);
}
double SimplePressures::_finitePlaneForceTV( double q,  double r,  double sigma, double W,  double e1 )
{
	/* a la Valleau et al, J Chem Phys 95:520 - note converted into non-reduced units. Original was 4.q.sigma/e1 ... */
	double F, r2;
	
	r = r/W; // unitless.
	r2 = r * r;
	F = 4.0*r2 * sqrt( 1.0 + 1.0/(2.0*r2) ); // unitless, again.
	F = atan( 1.0 / F );
	return ( (4.0*q*sigma)/(4.0*M_PI*E0*e1) ) * F * ELEM_CHARGE * (ELEM_CHARGE/1e-20);
}
double SimplePressures::_directCoulombForce( double q1, double q2, double r,     double dr, double e1 )
{
	return ( (q1*q2)/(4.0*M_PI*E0*e1*(r*r*1e-20)) ) * ( fabs(dr)/r ) * ELEM_CHARGE * ELEM_CHARGE; // units cancel in dr and r, so use as is.
}
/*
	S1, S2 are designed to represent the 2 closest S bins to the hard sphere radius for the S function.
	There are 2 bins between S_min and S_max, and only the S values for these bins are recorded to allow a linear
	interpolation of S to the hard sphere radius of the site. The values of these two bins go into S1 and S2.
*/
void SimplePressures::Get( MCSim * sim, Distributions * d, double *dc, double *cp, double *kin, double *S1, double *S2 )
{
	int i, j;
	double dc_force, cp_force, S_acc1, S_acc2, total_conc, cell_side;
	double precalculated_charged_plane_force_negative_side, precalculated_charged_plane_force_positive_side;
	StatBins *Q;
	
	double r, q1, q2, r12[3], S_bin_vol;
	double electro_pressure_to_M, kin_pressure_to_M;
	
	S_bin_vol = surface_area*S_delta;
	Q = d->charge; // charge distribution bins
	
	/*
		Electrostatic contributions from direct coulomb and charged plane interactions.
		S function calculation piggybacks on top of this.
		
		NOTE - this gets the average over both halves of the sim! This is important,
		as in certain testing situations I got values that were consistently too large
		when simply considering one half of the cell. When I put both in, it worked -
		as the system was not exactly asymmetrical!
	*/
	dc_force = 0.0;
	cp_force = 0.0;
	S_acc1 = 0.0;
	S_acc2 = 0.0;
	/*
		Figure out how many explicit analytical charged planes we have defined in the sim in either half of the cell;
		as interaction energy of point charge with analytical charged plane is linear in separation, force
		is independent of position, so we can precalculate a force for ions in either side of the box due to
		those explicit charged planes without worrying about the ion position!
		
		The precalculated force variables are for a point charge of 1.0, so can multiply them by the ion charge
		to get the force contribution on that ion.
	*/
	precalculated_charged_plane_force_negative_side = 0.0;
	precalculated_charged_plane_force_positive_side = 0.0;
	for( i=0; i<sim->n_charged_plane_templates; i++ )
	{
		if( sim->charged_plane_templates[i].axis == axis )
		{
			// plane in "positive" side, so will contribute to force felt by ions in "negative" side
			if( sim->charged_plane_templates[i].pos > 0.0 )
			{
				precalculated_charged_plane_force_negative_side += _infinitePlaneForce( 1.0, sim->charged_plane_templates[i].sigma, sim->e1 );
			}
			// plane in "negative" side, so will contribute for force felt by ions in "positive" side
			else
			{
				precalculated_charged_plane_force_positive_side += _infinitePlaneForce( 1.0, sim->charged_plane_templates[i].sigma, sim->e1 );
			}
		}
	}
	
	for( i=0; i<sim->n_sites; i++ )
	{
		/*
			the cell_side variable is used to check whether something is on the same side of the sim cell as the
			current ion (i); if we multiply two things of the same sign, we get a positive number. So multiply the
			other ion or charged plane coord by cell_sde, and if the result is > 0, they are on the same side and so
			should not be considered!
		*/
		if( sim->site_coords[(i*3) + axis] < 0.0 ) cell_side = -1.0;
		else cell_side = 1.0;
		
		//if( cell_side > 0.0 ) continue; // ie average over just one half for speed - GENERALLY MESSES UP THE RESULTS, THOUGH!
		
		q1 = sim->site_templates[ sim->site_template_indices[i] ].q;
		/*
			Direct Coulomb interactions between ions on opposite halves of the simulation cell.
		*/
		for( j=0; j<sim->n_sites; j++ )
		{
			if( i == j || sim->site_coords[(j*3) + axis] * cell_side > 0.0 ) continue; // ie. same ion, or in same side of box.
	
			r = sqrt( GetSeparationSquaredAndVectorMIC( &sim->site_coords[i*3], &sim->site_coords[j*3], r12, sim->cell, sim->PBC ) );
			q2 = sim->site_templates[ sim->site_template_indices[j] ].q;
	
			dc_force += _directCoulombForce( q1, q2, r, fabs(r12[axis]), sim->e1 );
			/*
				Collision contribution, denoted S(r) in the literature.
				Direct accumulation, bypasses the usual block routines etc as we don't want
				the accumulator counts to be incremented each time! We want to increment them all
				at once, after the set of bins are updated.
			*/
			if( r < S_min || r > S_max ) continue;
			
			if( r < S_min + S_delta )
			{
				S_acc1 += (fabs(r12[2])/r)/S_bin_vol;
			}
			else
			{
				S_acc2 += (fabs(r12[2])/r)/S_bin_vol;
			}
		}
		/*
			Interaction of the ion with the infinite sheets of charge due to the ion distribution on opposite half of the simulation cell.
			Remember, we subtract the finite sheet which lies in the simulation cell so we don't double count the interactions between the ions
			themselves!
		*/
		for( j = 0; j < Q->nbins[0]; j++ )
		{
			if( (Q->mins[0] + (0.5+j)*Q->deltas[0]) * cell_side > 0.0 ) continue; // check ion and sheet are on separate sides
			r = fabs( sim->site_coords[(i*3) + axis] ) + fabs(Q->mins[0] + (0.5+j)*Q->deltas[0]); // as we don't know which is negtive, fabs() both coords.
			// Torrie & Ivkov simplification - REMOVE EXPLICIT CHARGED PLANE STUFF BELOW WHEN USING THIS!
			// cp_force += _finitePlaneForceTV( q1, r, Q->block_means[j]/surface_area, W, sim->e1 );
			// full treatment
			 cp_force += _infinitePlaneForce( q1, Q->block_means[j]/surface_area, sim->e1 ) - _finitePlaneForceTV( q1, r, Q->block_means[j]/surface_area, W, sim->e1 );
		}
		/*
			Interaction of ion with any explicit charged planes that exist on the other side of the cell
			Comment this out where you're using the TVI simplification.
		*/
		r = sim->site_coords[(i*3) + axis];
		if( r < 0.0 ) cp_force += q1 * precalculated_charged_plane_force_negative_side;
		else cp_force += q1 * precalculated_charged_plane_force_positive_side;
	}
	
	/*
		We want the force acting from one half of the cell, so divide
		force accumulators for direct and charged plane electrostatics
		by half.
	*/
	cp_force = cp_force/2.0;
	dc_force = dc_force/2.0;
	
	/*
		For the electrostatic contributions:
		
		P = N/m^2 = kg.m.s^-2/m^2
		Valleau et al express pressure in Molar by dividing the pressure by RT.
		P/RT = N/(m^2.NAV.KB.T) = kg.m.s^-2/(m^2 . NAV . kg.m^2.s^-2), as units of KBT = J = kg.m^2.s^-2
		Cancel stuff out:
		P/RT = m / (m^2 . NAV . m^2) = 1 / (NAV . m^3).
		Therefore, we see that pressure can indeed be expressed in units of Molar when divided by RT.
		
		To do so, we divide the pressure by RT ( ie. NAV * KB * T ), but we also have to bear in mind we're in units
		of Angstrom^2 for the surface area, so multiply by 1e20 to get into m^2. Then, to go from units of 1/NAV.m^3 to
		1/NAV.dm^3 (ie. Molar), we multiply by 1e-3.
		
	*/
	electro_pressure_to_M = (1e20*1e-3)/(NAV*KB*sim->T);
	
	/*
		Kinetic contribution. Get the total concentration of all species in the bin at the midplane (ie. r = 0.0 )
	*/
	kin_pressure_to_M = 1e27/NAV; // p_kin = KB.T.[x] ( where [x] in M ). So for p_kin/RT, just convert density from moles per Angstrom^3 to moles per dm^3 (Molar).
	r = 0.0; // location of concentration bin we're interested in - the midplane!
	total_conc = 0.0;
	for( i=0; i<d->n_concs; i++ )
	{
		j = d->concs[i]->Map( &r ); // recycle S_bin_no variable.
		if( j == -1 )
		{
			printf( "%s(): unable to map concentration bin from coordinate %e.\n", __func__, r );
			exit( -1 );
		}
		total_conc += d->concs[i]->block_means[j];
	}
	
	*dc = electro_pressure_to_M * dc_force/surface_area;
	*cp = electro_pressure_to_M * cp_force/surface_area;
	*kin = kin_pressure_to_M * total_conc/(surface_area*d->concs[0]->deltas[0]);
	*S1 = S_acc1;
	*S2 = S_acc2;
}

#define PRESSURES_INCLUDED
#endif
