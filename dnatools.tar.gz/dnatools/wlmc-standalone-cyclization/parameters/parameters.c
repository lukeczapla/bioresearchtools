#include <stdio.h>
#include <stdlib.h>

#include "parameters.h"

// requestreturnoparameters :
// asks the server to supply the needed Wang-Landau parameters for simulation
// retrieves the current values
parameter_type *readreturnparameters() {
	
	parameter_type *p = new parameter_type;

	FILE *f = fopen("parameters.dat", "r");

	if (f == NULL) {
		printf("parameters not found!\n");
		exit(0);
	}

	fscanf(f, "%d %d %f %f %f %f %f", &p->Nbins, &p->measure, &p->start, &p->end, &p->dUstar, &p->dpstar, &p->dUstartol);

	fclose(f);
	
	return p;
	
}



// requestdataparameters : 
// Sends only the updated U* values and also the current value of dUstar, 
// retrieves the client-summed U* and any updated dUstar
data_type *requestupdateparameters(socket_type *s, data_type *d) {

	int request = REQUEST_UPDATE_DATA;
	int mysock = connectsocket(s);

	int size = (d->size + 3) * sizeof(int) + sizeof(float);
	data_type *new_data = new data_type;

	int i = 0;

// tell the server we're asking to update
	writesocket(mysock, &request, sizeof(int));
// send the data to the server
	if (writesocket(mysock, d, size) != size) printf("something fucked up\n");

// retrieve the summed data and new dUstar
	if (readsocket(mysock, new_data, size) != size) printf("something fucked up\n");
		
	closesocket(mysock);
	
	return new_data;

}
