#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <unistd.h>
#include <time.h>
#include <pthread.h>


#include "socket/socket.h"
#include "parameters/parameters.h"
#include "pdna/pdna.h"
#include "mc/mc.h"

#include "wlmc_args.c"

void randomize(unsigned short *key) {
	printf("Key = %d %d %d\n", key[0], key[1], key[2]);
	seed48(key);
}

int main(int argc, char **argv) {

	parsecmdline(argc, argv);
	
	randomize(key);
	
	printf("\ninitializing system: placing the polymer and proteins\n");
	dna mydna(inputfile);
	pdna *b = new pdna();
	b->initialize_bdna(mydna);
	b->initialize_params(beta);
	b->init_proteins();
	
	printf("requesting parameters\n");
	parameter_type *params = readreturnparameters();
	

	printf("Finding starting configuration between %f and %f\n", params->start, params->end);

	b->generate_config();
	b->convert_steps();
	b->dE();
	b->revert();
	printf("%lf\n", mold(b, params));

    while (((mold(b, params) < params->start) || (mold(b, params) > params->end)) && (params->measure != 3)) {
		b->move(1.0);
		b->dE();
		if (b->dE() > 0.0) b->accept();
		else b->revert();
	};
		
	printf("End-to-end = %d percent\n", b->oldEE());
		
	
	printf("\nrunning system simulation\n");
	runsimulation(b, params, beta, Neq, savefile, Nc);
	delete params;
	delete b;
	
	return 0;
}


