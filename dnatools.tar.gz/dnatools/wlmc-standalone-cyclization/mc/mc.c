#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mc.h"


double dUstar;

void clear(data_type *d) {
	for (int i = 0; i < d->size; i++) d->Ustar[i] = 0;
}



int bin(parameter_type *p, double v) {
	if ((v >= p->start) && (v < p->end)) return (int)((v-p->start)*(double)(p->Nbins)/(p->end-p->start));
	else if (v <= p->start) return 0;
	else return (p->Nbins - 1);
}


double penalty(parameter_type *p, data_type *d, double v) {
	if ((v >= p->start) && (v < p->end)) return (dUstar * d->Ustar[bin(p, v)]);
// if outside the bins, return "infinity"
	return 1e20;
}


int accept(double dE) {

	// if the new energy is lower, accept
	if (dE < 0.0) return 1;
	
	// if the random number between 0 and 1 is less than exp(-dE), where dE is positive, accept
	if (drand48() < exp(-dE)) return 1;
	
	// otherwise, reject
	return 0;
	
}

double mold(pdna *b, parameter_type *p) {
	if (p->measure == 1) return b->oldEE();
	if (p->measure == 2) return b->oldEEt();
	if (p->measure == 3) return (double)b->Pnum();
	if (p->measure == 5) return b->oldEEfull();
	if (p->measure == 6) return b->oldEElac();
}

double mnew(pdna *b, parameter_type *p) {
	if (p->measure == 1) return b->newEE();
	if (p->measure == 2) return b->newEEt();
	if (p->measure == 3) return (double)b->Pnumnew();
	if (p->measure == 5) return b->newEEfull();
	if (p->measure == 6) return b->newEElac();
}

void set_top(bdna *a, pdna *b) {
	for (int i = 0; i < b->nsteps; i++) {
		a->v[i].setv(1,1, b->v2[i](1,1));
		a->v[i].setv(2,1, b->v2[i](2,1));
		a->v[i].setv(3,1, b->v2[i](3,1));
		a->v[i].setv(4,1, b->v2[i](4,1));
		a->v[i].setv(5,1, b->v2[i](5,1));
		a->v[i].setv(6,1, b->v2[i](6,1));
	}
}

void runsimulation(pdna *b, parameter_type *p, double beta, int Neq, char *savefile, int Nc) {
	data_type *d = new data_type;
	
// request the parameters that start the simulation
	d->size = p->Nbins;
	d->dUstar = p->dUstar;
	dUstar = p->dUstar;
	clear(d);

	bdna top(b->nsteps);

	double measureold, measurenew;
	double Uold, Unew;

	measureold = mold(b, p);
	measurenew = measureold;
		
	printf("starting measure = %lf, minimum = %d, equilibrating (%d moves)...\n", measureold, (int)p->start, Neq);
	
	double dE;
	int m;
	
	double S = 0.0;
	
	for (int i = 0; i < Neq; i++) {
		S = b->move(beta);
		dE = b->dE();
		m = mnew(b, p);
		if (accept(beta*(dE + S)) && (((m < p->end) && (m > p->start)) || (p->measure == 3))) {
			b->accept();
		} else b->revert();
	}
	
	measureold = mold(b, p);
	
	set_top(&top, b);
	
	printf("starting... measure = %lf\n", measureold);
		
	long int Nt = 0;
	long int Naccept = 0;
	
	long int avgp = 0;
	long int *M = new long int[1000];
	long int *Mt = new long int[1000];
	
	int propos[1000][400];
	double avgE[1000];

	long int Mp[1000][50];
	int mpic[1000][50];
	long int Lkp[1000][50];
	double avg_tw[1000][50];
	double avg_wr[1000][50];
	long int ps[1000];

	for (int i = 0; i < 1000; i++) for (int j = 0; j < 400; j++) {
		propos[i][j] = 0;
	}

	for (int i = 0; i < 1000; i++) for (int j = 0; j < 50; j++) {
		mpic[i][j] = 0;
		Lkp[i][j] = 0;
		avg_tw[i][j] = 0.0;
		avg_wr[i][j] = 0.0;
		Mp[i][j] = 0;
	}


	for (int i = 0; i < 1000; i++) {
		M[i] = 0;
		Mt[i] = 0;
		ps[i] = 0;
		avgE[i] = 0.0;
	}

	double Tw = top.calculate_twist();
	double Wr = top.calculate_writhe();
	
	printf("%lf %lf\n", Tw, Wr);
	
	int *posi;
	int Npr;
	
	posi = b->getpositions(Npr);

	int i = 0;
	int j = 0;

	
	int pmax = 0;
	S = 0.0;
	Uold = penalty(p, d, measureold);
//	printf("entering main loop\n");
//	b->set_straight();
	while (1) {
		S = b->move(beta);
		dE = b->dE();
//		printf("dE = %lf\n", dE);
		Nt++;
		measurenew = mnew(b, p);
		Unew = penalty(p, d, measurenew);
//		printf("%lf %lf %lf %d %d\n", dE, Unew, Uold, measurenew, measureold);
		if (accept(beta*(dE + S + Unew - Uold))) {
			b->accept();
			if (posi != NULL) delete [] posi;
			posi = b->getpositions(Npr);
			set_top(&top, b);
			Naccept++;
			measureold = measurenew;
			d->Ustar[bin(p, measurenew)]++;
			if (bin(p, measurenew) >= 178) {
				Tw = top.calculate_twist();
				Wr = top.calculate_writhe();
				avg_tw[bin(p, measurenew)][lround(Tw+Wr)] += Tw;
				avg_wr[bin(p, measurenew)][lround(Tw+Wr)] += Wr;
				Lkp[bin(p, measurenew)][lround(Tw+Wr)]++;
				for (int q = 0; q < Npr; q++) {
					propos[bin(p, measurenew)][posi[q]]++;
				}
			}
			ps[bin(p, measurenew)]++;
			Uold = Unew + dUstar;
			avgp += b->Pnum();
			M[bin(p, measurenew)] += b->Pnum();
			Mp[bin(p, measurenew)][lround(Tw+Wr)] += b->Pnum();
			Mt[bin(p, measurenew)]++;
			avgE[bin(p, measurenew)] += b->calculate_elenergy();
			if ((mpic[bin(p, measurenew)][lround(Tw+Wr)] == 0) && (bin(p, measurenew) >= 178)) {
				char sdna[256];
				char sprotein[256];
				sprintf(sdna, "structure-%d-%d.dat", lround(Tw+Wr), bin(p, measurenew)+1-178);
				sprintf(sprotein, "protein-%d-%d.pdb", lround(Tw+Wr), bin(p, measurenew)+1-178);
				b->illustrate_config(sdna, sprotein);
				mpic[bin(p, measurenew)][lround(Tw+Wr)] = 1;
			}
		} else {
			b->revert();
			d->Ustar[bin(p, measureold)]++;
			ps[bin(p, measureold)]++;
			if (bin(p, measureold) >= 178) {
				avg_tw[bin(p, measureold)][lround(Tw+Wr)] += Tw;
				avg_wr[bin(p, measureold)][lround(Tw+Wr)] += Wr;
				Lkp[bin(p, measureold)][lround(Tw+Wr)]++;
				for (int q = 0; q < Npr; q++) {
					propos[bin(p, measureold)][posi[q]]++;
				}
			}
			Uold += dUstar;
			avgp += b->Pnum();
			M[bin(p, measureold)] += b->Pnum();
			Mp[bin(p, measureold)][lround(Tw+Wr)] += b->Pnum();
			Mt[bin(p, measureold)]++;
			avgE[bin(p, measureold)] += b->calculate_elenergy();
			if (b->Pnum() > pmax) pmax = b->Pnum();
		}
		i++;
		if (i == Nc) {
			int compute = 1;
			double avgps = 0.0;
			for (int k = 0; k < p->Nbins; k++) {
				if (ps[k] == 0) compute = 0;
				avgps += (double)ps[k];
			}
			avgps /= (double)p->Nbins;
			int update = 1;
			if (compute) {
				int min = 100000;
				for (int k = 0; k < p->Nbins; k++) {
					if (fabs(avgps-ps[k])/avgps > p->dpstar) update = 0;
					if (ps[k] < min) min = ps[k];
				}
				if ((min > 5000) && (dUstar > 0.0005)) update = 1;
				if (update) {
					printf("Updating dU* from %lf to %lf, %lf moves\n", dUstar, dUstar/4.0, avgps * p->Nbins);
					dUstar /= 4.0;
					if (dUstar < p->dUstartol) {
						for (int k = 0; k < p->Nbins; k++) {
							printf("%d %f\n", k+1, 4.0*dUstar*d->Ustar[k]);
						}
						return;
					}
					for (int k = 0; k < p->Nbins; k++) {
						d->Ustar[k] *= 4;
						ps[k] = 0;
					}
				}
			}
			j++;
			i=0;	
		}
		if (j == 1000) {
			printf("Acceptance rate = %lf, nP = %d, avg p = %lf avg p (closed) = %lf\n", (double)Naccept/(double)Nt, b->Pnum(), (double)(avgp) / (double)(Nt), (double)(M[0])/(double)(Mt[0]));
			for (int k = 0; k < 178; k++) printf("%d %lf ", Mt[k], dUstar*d->Ustar[k]);
			printf("\n");
			long double D = 0.0;
			long double avgPro = 0.0;
			double minv = 1000.0;
			for (int k = 0; k < p->Nbins; k++) {
				if ((dUstar*d->Ustar[k]) < minv) minv = dUstar*d->Ustar[k];
			}
			for (int k = 0; k < p->Nbins; k++) {
				D += expl(dUstar*d->Ustar[k]-minv);
				avgPro += (double)M[k] * expl(dUstar*d->Ustar[k]-minv) / (double)Mt[k];
			}
			for (int k = 178; k < p->Nbins; k++) {
				printf("%d %lf %lf %ld %lf %Le (", k-178+1, (double)M[k]/(double)Mt[k], avgE[k]/(double)Mt[k], Mt[k], dUstar*d->Ustar[k], 4.0*M_PI*expl(dUstar*d->Ustar[k]-minv)/(D*4.0*M_PI*6.022e23*0.05*powl(0.025*3.4*b->nsteps*1e-9, 3.0)*2.0*M_PI/(8.57*3.0)));
				for (int q = 0; q < 50; q++) {
					if (Lkp[k][q] != 0) {
						printf("%d,%d,%lf,%lf,%lf;", q, Lkp[k][q], avg_tw[k][q]/(double)Lkp[k][q], avg_wr[k][q]/(double)Lkp[k][q], (double)Mp[k][q]/(double)Lkp[k][q]);
					}
				}
				printf(")\n");
			}
			printf("Average Protein Number = %Le\n", avgPro/D);
			j = 0;
		}
	}

}

