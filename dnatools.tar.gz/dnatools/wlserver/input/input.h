#ifndef _INPUT_H
#define _INPUT_H

#include "../parameters/parameters.h"

serverdata_type *readinput(char *input, char *start);

#endif

