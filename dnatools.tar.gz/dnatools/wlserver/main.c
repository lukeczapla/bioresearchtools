#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

#include "serversocket/serversocket.h"
#include "parameters/parameters.h"
#include "input/input.h"

#include "server_args.c"

#define FOREVER_EVER_EVER 1

int main(int argc, char **argv) {

	int usemenu = parsecmdline(argc, argv);

	short unsigned int key[3];
	key[0] = getpid();
	key[1] = time(NULL);
	seed48(key);
			
    serverdata_type *s = readinput(inputfile, sdata);

	pthread_t thread;
	if (usemenu) pthread_create(&thread, NULL, runmenu, (void *)s);
	
	int socket = bindsocket(port);

	if (!usemenu) printf("No menu will be available\n");
	initparameters(s);
	printf("key = %d\n", s->key);
// main loop - we read requests and complete transactions
	while (FOREVER_EVER_EVER) {

		processrequest(socket, s);

	}

	return 0;

}

