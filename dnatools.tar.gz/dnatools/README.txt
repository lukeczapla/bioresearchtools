
*** There are numerous program codes here for DNA and molecular simulations ***

"+" denotes program has OpenGL visualizer support

-------------------------------------------------------------------------------


mclosure:  The original Gaussian sampling method & DNA utilities

mcion (+): Reads a PQR file and computes the ion distribution around the molecule, either within a spherical simulation cell or a box with periodic boundary conditions and the minimum image convention

wlmc-standalone-cyclization: A single node version of the Wang and Landau algorithm used to solve the ring closure problem and looping with cooperativity in protein binding

vis:  The OpenGL visualizer for watching the Metropolis MC simulations (written by John Grime at Uppsala now in Greg Voth's lab)


----------------------------------------


** CLIENT/SERVER CODES **

wlserver:  The server that must be running to do the wlmc programs

wlmc-mdna:  Wang and Landau biased Metropolis MC for DNA-protein chains, such as DNA stretching with Remus Dame

wlmc-screened (+):  The ion-DNA electrostatics program, intended for condensing DNA in the presence of multivalent counterions. VERY DIFFICULT!

wlmc-circle (+):  This one simulates a circular DNA with fixed linking number and with ions, very similar to wlmc-screened and not quite as difficult to sample with Metroplis MC



