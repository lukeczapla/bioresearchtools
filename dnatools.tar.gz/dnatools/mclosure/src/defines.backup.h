#ifndef _DEFINES_H
#define _DEFINES_H

#define FLOAT_float

#define FLOAT float
#define FLOAT_ESTR "%e"
#define FLOAT_ESTRF "%8.4f"
#define FLOAT_ESTR6 "%e %e %e %e %e %e"

#endif
