#ifndef _DEFINES_H
#define _DEFINES_H

#define FLOAT_double

#define FLOAT double
#define FLOAT_ESTR "%le"
#define FLOAT_ESTR6 "%le %le %le %le %le %le"

#endif
