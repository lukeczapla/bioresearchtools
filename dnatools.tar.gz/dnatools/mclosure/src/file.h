
#ifndef __FILE__H
#define __FILE__H

#include <stdio.h>

FILE *openfwrite(char *filename);

#endif
