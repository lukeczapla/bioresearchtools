#include <stdio.h>
#include <math.h>
#include "energy.h"


// calculate the electrostatic energy of the system
double calculateESenergy(system_type *s) {

	double E = 0.0;
	double d;

	double K = 0.329*sqrt(s->salt);

	float ix, iy, iz, jx, jy, jz;
	float *ph = s->dna.add_phosphates();
		
	for (int i = 0; i < s->dna.nsteps; i++) {
		for (int j = i+1; j < s->dna.nsteps; j++) {
			d = sqrt((ph[9*i]-ph[9*j])*(ph[9*i]-ph[9*j])+(ph[9*i+1]-ph[9*j+1])*(ph[9*i+1]-ph[9*j+1])+(ph[9*i+2]-ph[9*j+2])*(ph[9*i+2]-ph[9*j+2]));
			
			if (((j-i) == s->dna.nsteps+1) && (d < 3.4)) {
				delete [] ph;
				return 1e10;
			}
			if (((j-i) > 40) && ((j-i) < (s->dna.nsteps-6)) && (d < 22.0)) {
				delete [] ph;
				return 1e10;
			}
			d = sqrt((ph[9*i+3]-ph[9*j+3])*(ph[9*i+3]-ph[9*j+3])+(ph[9*i+4]-ph[9*j+4])*(ph[9*i+4]-ph[9*j+4])+(ph[9*i+5]-ph[9*j+5])*(ph[9*i+5]-ph[9*j+5]));
			E += exp(-K*d) / d;
			d = sqrt((ph[9*i+6]-ph[9*j+3])*(ph[9*i+6]-ph[9*j+3])+(ph[9*i+7]-ph[9*j+4])*(ph[9*i+7]-ph[9*j+4])+(ph[9*i+8]-ph[9*j+5])*(ph[9*i+8]-ph[9*j+5]));
			
			E += exp(-K*d) / d;
			d = sqrt((ph[9*i+6]-ph[9*j+6])*(ph[9*i+6]-ph[9*j+6])+(ph[9*i+7]-ph[9*j+7])*(ph[9*i+7]-ph[9*j+7])+(ph[9*i+8]-ph[9*j+8])*(ph[9*i+8]-ph[9*j+8]));
			
			E += exp(-K*d) / d;
			d = sqrt((ph[9*i+3]-ph[9*j+6])*(ph[9*i+3]-ph[9*j+6])+(ph[9*i+4]-ph[9*j+7])*(ph[9*i+4]-ph[9*j+7])+(ph[9*i+5]-ph[9*j+8])*(ph[9*i+5]-ph[9*j+8]));

			E += exp(-K*d) / d;
		}
	}
	
	for (int i = 0; i < s->Nions; i++) {
		for (int j = i+1; j < s->Nions; j++) {
			ix = s->ions[i].x;
			iy = s->ions[i].y;
			iz = s->ions[i].z;
			jx = s->ions[j].x;
			jy = s->ions[j].y;
			jz = s->ions[j].z;
			d = sqrt((ix-jx)*(ix-jx) + (iy-jy)*(iy-jy) + (iz-jz)*(iz-jz));
			if (d < s->ions[i].r + s->ions[j].r) {
				delete [] ph;
				return 1e10;
			}
			E += (double)(s->ions[i].charge * s->ions[j].charge) * exp(-K*d) / d;
		}
	}
	
	
	for (int i = 0; i < s->dna.nsteps+1; i++) {
		for (int j = 0; j < s->Nions; j++) {
			jx = s->ions[j].x;
			jy = s->ions[j].y;
			jz = s->ions[j].z;
			ix = ph[9*i];
			iy = ph[9*i+1];
			iz = ph[9*i+2];
			d = sqrt((ix-jx)*(ix-jx) + (iy-jy)*(iy-jy) + (iz-jz)*(iz-jz));
			if (d < 11.0 + s->ions[j].r) {
				delete [] ph;
				return 1e10;
			}
			if (i != s->dna.nsteps) {
			ix = ph[9*i+3];
			iy = ph[9*i+4];
			iz = ph[9*i+5];
			d = sqrt((ix-jx)*(ix-jx) + (iy-jy)*(iy-jy) + (iz-jz)*(iz-jz));
			E += (double)(-1.0 * s->ions[j].charge) * exp(-K*d) / d;
			ix = ph[9*i+6];
			iy = ph[9*i+7];
			iz = ph[9*i+8];
			d = sqrt((ix-jx)*(ix-jx) + (iy-jy)*(iy-jy) + (iz-jz)*(iz-jz));
			E += (double)(-1.0 * s->ions[j].charge) * exp(-K*d) / d;
			}
		}
	}
	delete [] ph;
	return K_ES * E / DIELECTRIC;
	
}


double calculatepolymerenergy(system_type *s) {
	return s->dna.calculate_elenergy();	
}


double calculateenergy(system_type *s) {
//	printf("%lf %lf\n", calculateESenergy(s), calculatepolymerenergy(s));
	return calculateESenergy(s) + calculatepolymerenergy(s);
}
