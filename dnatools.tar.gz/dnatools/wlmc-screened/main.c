#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mpi.h>

#include <unistd.h>
#include <time.h>
#include <pthread.h>

#include "init/init.h"
#include "mc/mc.h"
#include "socket/socket.h"
#include "parameters/parameters.h"
#include "energy/energy.h"
#include "tools/tools.h"

#include "wlmc_args.c"

void randomize(unsigned short *key) {
	printf("Key = %d %d %d\n", key[0], key[1], key[2]);
	seed48(key);
}

int main(int argc, char **argv) {

        MPI_Init(&argc, &argv);

        int rank;
        MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	printf("Loading node %d\n", rank);

	parsecmdline(argc, argv);
	
	randomize(key);
	
	system_type *s = readinput(inputfile);

	float V = 4.0 * 3.1415 * powf(s->cell_radius, 3.0)/ 3.0;
	printf("box radius = %f, volume = %e cubic Ång, 1 particle = %e mM, 1 mM = %f particles\n", s->cell_radius, V, 1660600.0 / V, 1.0 / (1660600.0 / V));

	socket_type *connection;
	parameter_type *params;

	if (!calcP) {
		printf("contacting server\n");
		connection = initsocket(host, port);
		printf("requesting parameters\n");
		params = requestreturnparameters(connection);
	}

	printf("\ninitializing system: placing the polymer and the ions (this could take awhile)\n");
	initsystem(s, params);
	
	if (usevis && rank==0) {
		printf("spawning visualization client to connect to local port 7001\n");
		pthread_t thread;
    	pthread_create(&thread, NULL, runvisualization, (void *)s);
	}
	
	printf("\nrunning system simulation\n");
	if (calcP) runpersistence(s, Neq);

	runsimulation(s, params, connection, Neq, savefile, rank);
	
	delete params;
	delete connection;
	delete s;
	
	return 0;
}


