#ifndef _TOOLS_H
#define _TOOLS_H

#include "../input/input.h"

float distance(ion I1, ion I2);

float distance2(ion I1, ion I2);

float persistence(system_type *s);
double persistencelength(float *P, int *Pi, unsigned int *Ustar, double dUstar, int size);

void printionpositions(system_type *s);

#endif

