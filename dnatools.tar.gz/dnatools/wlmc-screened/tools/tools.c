#include <stdio.h>
#include <math.h>

#include "tools.h"

float distance(ion I1, ion I2) {
	return sqrtf((I1.x - I2.x) * (I1.x - I2.x) + (I1.y - I2.y) * (I1.y - I2.y) + (I1.z - I2.z) * (I1.z - I2.z));
}

float distance2(ion I1, ion I2) {
	return ((I1.x - I2.x) * (I1.x - I2.x) + (I1.y - I2.y) * (I1.y - I2.y) + (I1.z - I2.z) * (I1.z - I2.z));
}


float persistence(system_type *s) {
	return 1.0;
}


double persistencelength(float *P, int *Pi, unsigned int *Ustar, double dUstar, int size) {
	double Ftot = 0.0;
	double Ptot = 0.0;
	for (int i = 0; i < size; i++) {
		Ptot += (double)P[i] * exp(Ustar[i]*dUstar) / (double)Pi[i];
		Ftot += exp(Ustar[i]*dUstar);
	}
	return Ptot / Ftot;
}


void printionpositions(system_type *s) {
	for (int i = 0; i < s->Nions; i++) {
		printf("ion %d: %f %f %f\n", i+1, s->ions[i].x, s->ions[i].y, s->ions[i].z);
		
	}
}

