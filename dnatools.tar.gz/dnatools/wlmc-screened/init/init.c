#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "init.h"
#include "../mc/mc.h"
#include "../tools/tools.h"
#include "../energy/energy.h"

// initsystem(system *s) takes the system argument and positions ions and the polymer
// the polymer is placed on z-axis with the middle monomer at (0, 0, 0)
// the ions are distributed randomly
void initsystem(system_type *s, parameter_type *p) {


	float x, y, z;
	x = 0.0;
	y = 0.0;
	z = 0.0;

	float theta;

// position monomer units, with random bending that is very small

	do {
		s->dna.set_straight();
	} while (calculatemeasure(s, p) >= p->end);

	float *ph = s->dna.add_phosphates();

// position ions in random locations
	float R, phi;
	int overlap = 0;
	float d;
	for (int i = 0; i < s->Nions; i++) {
	// generate a random position, where the angles are randomly distributed and p(R) ~= R^2
		do {
			if (overlap) overlap = 0;
			R = (s->cell_radius - s->ions[i].r) * sqrtf(drand48());
			if (i == 0) R = 30.0;
			phi = M_PI * drand48();
			theta = 2.0 * M_PI * drand48();
			s->ions[i].x = R * cosf(theta) * sinf(phi);
			s->ions[i].y = R * sinf(theta) * sinf(phi);
			s->ions[i].z = R * cosf(phi);
			if (i == 0) {
			  s->ions[i].z = 0.0;
			  if (sqrt(s->ions[i].x*s->ions[i].x+s->ions[i].y*s->ions[i].y) < 20.0) overlap = 1;
			}
		// check overlap with both polymer monomer units and other ions;
			for (int j = 0; (j <= s->dna.nsteps) && (!overlap); j++) {
				d = sqrt((ph[9*j]-s->ions[i].x)*(ph[9*j]-s->ions[i].x)+(ph[9*j+1]-s->ions[i].y)*(ph[9*j+1]-s->ions[i].y)+(ph[9*j+2]-s->ions[i].z)*(ph[9*j+2]-s->ions[i].z));
				if (d < s->ions[i].r + 11.0) overlap = 1;
			}
			for (int j = 0; (j < i) && (!overlap); j++) {
				if (distance(s->ions[i], s->ions[j]) < s->ions[i].r + s->ions[j].r) overlap = 1;
			}
		} while (overlap);
	}

	delete [] ph;
	
}

