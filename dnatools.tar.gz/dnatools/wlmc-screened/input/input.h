#ifndef _INPUT_H
#define _INPUT_H

#include "../bdna/bdna.h"

struct polymer_type {
  int N;
  float L;
  float r;
  int potential;
  float F;
};

struct ion_type {
  int N;
  float charge;
  float r;
};

struct ion {
  float x, y, z;
  float charge;
  float r;
};

struct monomer {
  double tilt, roll, twist;
  float r;
};

struct bond {
	float L;
	int potential;
	float F;
};

struct system_type {
	float pivot_r;
	float pivot_P;
	float d_max;
	float angle_max;
	float cell_radius;
	float salt;
	float polymer_charge;
	int Nions;
	int Nmonomers;
	bdna dna;
	ion *ions;
};

void copychange(system_type *s1, system_type *s2);
void copyion(system_type *s1, system_type *s2, int index);
system_type *copysystem(system_type *s);


system_type *readinput(char *filename);

/*
void writeconfig(char *filename, system_type *s, int append);
system_type *readconfig(char *filename, int n);
*/
#endif

