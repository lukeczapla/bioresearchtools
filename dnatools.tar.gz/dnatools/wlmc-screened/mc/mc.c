#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "mc.h"
#include "../energy/energy.h"
#include "../mcmoves/mcmoves.h"
#include "../tools/tools.h"

#define FOREVER 1

double dUstar;

void clear(data_type *d) {
	for (int i = 0; i < d->size; i++) d->Ustar[i] = 0;
}


float calculatemeasure(system_type *s, parameter_type *p) {

	float m = 0.0;

	if (p->measure == 1) {
	// end-to-end distance
		return s->dna.calculateEE();
	}
	
	if (p->measure == 2) {
	// radius of gyration
		return s->dna.calculateR();
	}
	
	if (p->measure == 3) {
		return s->dna.calculateEEp();
	}
        if (p->measure == 4) {
		return sqrt(s->ions[0].x*+s->ions[0].x+s->ions[0].y*s->ions[0].y);
        }
	return m;
}

int bin(parameter_type *p, float v) {
	if ((v > p->start) && (v < p->end)) return (int)(p->Nbins * ((v - p->start) / (p->end - p->start)));
	else if (v <= p->start) return 0;
	else return (p->Nbins - 1);
}


double penalty(system_type *s, parameter_type *p, data_type *d, float v) {
	if ((v > p->start) && (v < p->end)) return (dUstar * d->Ustar[bin(p, v)]);
// if outside the bins, return "infinity", which is 1e6 here (an unreasonable penalty) :)
	return 1e8;
}


int accept(double dE) {

	// if the new energy is lower, accept
	if (dE < 0.0) return 1;
	
	// if the random number between 0 and 1 is less than exp(-dE), where dE is positive, accept
	if (drand48() < exp(-dE)) return 1;
	
	// otherwise, reject
	return 0;
	
}


void runpersistence(system_type *s, long int Neq) {

	system_type *change = copysystem(s);
	printf("equilibrating system (polymer and ions), %ld moves\n", Neq);

	double Eold = calculateenergy(s);
	double dE;
	int valid;

	matrix *W = new matrix[10];

	for (int i = 0; i < 10; i++) {
		W[i] = identity(4);
		W[i].setv(1,1, 0.0);
		W[i].setv(2,2, 0.0);
		W[i].setv(3,3, 0.0);
		W[i].setv(4,4, 0.0);
	}
	for (long int i = 0; i < Neq; i++) {
	
		if (i % (s->Nions+1) != 0) {
  			valid = moveion(change, (i % (s->Nions)) - 1, dE, s->d_max*10.0);
		} else {
			valid = movepolymer(change, s->angle_max);
			dE = calculateenergy(change)-calculateenergy(s);
		}
		if (valid && accept(dE)) {
			copychange(s, change);
			Eold += dE;
		} else {
			copychange(change, s);
		}
	}

	int i = 0;
	long int updates = 0;
	printf("E = %lf (%lf)\n", Eold, calculateenergy(s));

	while (1) {

	if (i % (s->Nions+1) != 0) {
		valid = moveion(change, (i % (s->Nions)) - 1, dE, s->d_max);
	} else {
		valid = movepolymer(change, s->angle_max);
		dE = calculateenergy(change)-calculateenergy(s);
	}
	if (valid && accept(dE)) {
		if (i % (s->Nions+1) == s->Nions) {
			for (int i = 0; i < 10; i++) W[i] = W[i]+calculateW(s->dna.v[s->dna.nsteps/2-5+i]);
			updates++;
		}
		copychange(s, change);
		Eold += dE;
	} else {
		copychange(change, s);
		if (i % (s->Nions+1) == s->Nions) {
			for (int i = 0; i < 10; i++) W[i] = W[i]+calculateW(s->dna.v[s->dna.nsteps/2-5+i]);
			updates++;
		}
	}		
	
	i++;
	if (i == 10) {
		i = 0;
		double avgP = 0.0;
		for (int j = 0; j < 10; j++) {
			matrix A = (1.0/(double)updates)*W[j];
			matrix PQ = identity(4);
			for (int j = 0; j < 10000; j++) PQ = PQ*A;
			avgP += PQ(3,4);
		}
		printf("P = %lf\n", avgP/10.0);
		printf("E = %lf (%lf)\n", Eold, calculateenergy(s));
	}
	}
}

// runsimulation: takes the system and the parameters and the data socket and runs the simulation
// THIS IS THE MAIN PART OF THE CODE WHERE ALL THE "FUN" HAPPENS!!!
void runsimulation(system_type *s, parameter_type *p, socket_type *c, long int Neq, char *savefile, int rank) {

	system_type *change = copysystem(s);
	printf("starting\n");
	data_type *d = new data_type;
	data_type *upd;
	
// request the parameters that start the simulation
	d->size = p->Nbins;
	d->dUstar = p->dUstar;
	clear(d);
	upd = requestupdateparameters(c, d);
        d->key = upd->key;
	
	double Eold;
	double Uold, Unew;

	FILE *outputfile;	

	float measureold, measurenew;
	
// initialize bins for computing persistence length
	float *P = new float[p->Nbins];
	int *Pi = new int[p->Nbins];
	double *minE = new double[p->Nbins];
	for (int i = 0; i < p->Nbins; i++) {
		P[i] = 0.0; Pi[i] = 0; minE[i] = 1e8;
	}
	
	measureold = calculatemeasure(s, p);
	Uold = penalty(s, p, upd, measureold);
	Unew = Uold;
	
	int valid;
	
	copychange(change, s);
	
	double dE = 0.0;
	
	printf("calculating starting energy\n");
	Eold = calculateenergy(s);
	printf("system starting energy = %lf kT, measure = %f\n", Eold, measureold);
	
	long int Naccept = 0;
	long int Ntrial = 0;
	int Naccept_p = 0;
	long int Ntrial_p = 0;

	measurenew = measureold;

	printf("equilibrating system (polymer and ions), %ld moves\n", Neq);
	int Nac = 0;
	int Nrj = 0;
	int si = 0;
	for (long int i = 0; i < Neq; i++) {
	
		if ((i % 400) == 0) {
			valid = movepolymer(change, s->angle_max);
                        dE = calculateenergy(change)-Eold;
                        if (dE > 1e8) valid = 0;
                        Unew = Uold;
		} else {
			valid = moveion(change, si=(int)((double)s->Nions*drand48()), dE, 5.0*s->d_max*drand48());
			Unew = Uold;
                        if (si == 0) {
			  measurenew = calculatemeasure(change, p);
			  Unew = penalty(change, p, upd, measurenew);
			}
		}
		if (valid && accept(dE + Unew - Uold)) {
			Nac++;
			if ((i % 400) == 0) copychange(s, change);
			else copyion(s, change, si);
			Eold += dE;
			Uold = Unew;
			measureold = measurenew;
		} else {
			Nrj++;
			if ((i % 400) == 0) copychange(change, s);
			else copyion(change, s, si);
		}
	}
	printf("%lf\n", (double)Nac/(double)(Nac+Nrj));
	
	printf("\nWang-Landau system starting energy = %lf kT (corrected to %lf kT), measure = %f\n\n", Eold, calculateenergy(s), measureold);
	Eold = calculateenergy(s);
	
	int counter = 0;
	int done = 0;
	
	dUstar = upd->dUstar;
	Uold = penalty(s, p, upd, measureold);
	
	if (strcmp(savefile, "") != 0) {
//		writeconfig(savefile, s, 0);
	}
	
	int *updates = new int[p->Nbins];
	double avgtwist = 0.0;
	matrix avgv(6,1);
	for (int q = 0; q < 6; q++) avgv.setv(q+1, 1, 0.0);
	printf("starting Wang-Landau simulation\n");
	
	double *avgbend = new double[p->Nbins];
        for (int i = 0; i < p->Nbins; i++) {                
		updates[i] = 0;
                avgbend[i] = 0.0;
        }


	matrix avgPW = identity(4);
	matrix W;
	for (int q = 1; q <= 4; q++) avgPW.setv(q,q, 0.0);

	printf("Maximum pivot angle = %lf\n", s->angle_max);
	
	while (FOREVER) {
		
		for (int i = 0; i < 100*(s->Nions+1); i++) {

			if (i % (s->Nions+1) == 0) {
				Ntrial_p++;
				valid = movepolymer(change, s->angle_max);
				dE = calculateenergy(change)-Eold;
				if (dE > 1e8) valid = 0;
				measurenew = calculatemeasure(change, p);
				Unew = Uold; //changed for new method;
			}
			else {
				valid = moveion(change, i % (s->Nions+1) - 1, dE, s->d_max*drand48());
				measurenew = measureold;
				Unew = Uold;
			}
			if (i % (s->Nions+1) == 1) {
				measurenew = calculatemeasure(change, p);
				Unew = penalty(change, p, upd, measurenew);
			}
			Ntrial++;

			if (valid && accept(dE + Unew - Uold)) {
				Naccept++;
				Eold += dE;
				if (i % (s->Nions+1) == 1) {
					copyion(s, change, 0);
					if (!done) {
						upd->Ustar[bin(p, measurenew)]++;
						d->Ustar[bin(p, measurenew)]++;
						updates[bin(p, measurenew)]++;
						W = identity(4);
						for (int q = 0; q < s->dna.nsteps; q++) {
							avgtwist += s->dna.v[q](3,1);
							avgv = avgv + s->dna.v[q];
							W = W*calculateW(s->dna.v[q]);
						}
						avgbend[bin(p, measurenew)] += 180.0*acos(W(3,3))/M_PI;
						avgPW = avgPW + W;
						Uold = Unew + dUstar;
					} else Uold = Unew;
					measureold = measurenew;
				} else {
					if (i % (s->Nions+1) == 0) {
						copychange(s, change);
						Naccept_p++; 
					}
					else copyion(s, change, i % (s->Nions+1) - 1);
				}
			} else {
				if (i % (s->Nions+1) == 0) copychange(change, s);
				else copyion(change, s, i % (s->Nions+1)-1);
				if ((i % (s->Nions+1) == 1) && (!done)) {
					upd->Ustar[bin(p, measureold)]++;
					d->Ustar[bin(p, measureold)]++;
					updates[bin(p, measureold)]++;
					W = identity(4);
					for (int q = 0; q < s->dna.nsteps; q++) {
						avgtwist += s->dna.v[q](3,1);
						avgv = avgv + s->dna.v[q];
						W = W*calculateW(s->dna.v[q]);
					}
					avgbend[bin(p, measureold)] += 180.0*acos(W(3,3))/M_PI;
					avgPW = avgPW + W;
					Uold += dUstar;
				}
			}
			
		}
		
		// print the system parameters every 10000 iterations, which is 100000 pivots
		counter++;
		if (counter == 1) {
			matrix Q = (1.0/(double)Ntrial_p)*avgPW;
			matrix A = Q;
			for (int q = 0; q < 1000; q++) A = A * Q; 
			printf("Measure = %f, Energy = %lf (%lf), Acceptance rate = %lf, Pivot acceptance = %f, avgtwist = %lf, pers = %lf\n", measureold, Eold, calculateenergy(s), (double)Naccept/(double)Ntrial, (double)Naccept_p/(double)Ntrial_p, avgtwist/(double)(Ntrial_p*(s->dna.nsteps)), A(3,4));
			char oname[32];
			sprintf(oname, "output-%dbp-%d", s->dna.nsteps, rank);
			outputfile = fopen(oname, "w");
			for (int i = 0; i < d->size; i++) {
				fprintf(outputfile, "%d %lf %lf\n", updates[i], dUstar * upd->Ustar[i], avgbend[i]/(double)updates[i]);
			}
			fclose(outputfile);
			printf("\n");
			writematrix(stdout, (1.0/(double)((s->dna.nsteps)*Ntrial_p))*avgv);
			if (strcmp(savefile, "") != 0) {
	//			writeconfig(savefile, s, 1);
			}
			counter = 0;
		}
		
		// send data "d" and get updated data "upd" from the server, clearing "d" to start over
		delete upd;
		upd = requestupdateparameters(c, d);
		if (upd->key != d->key) {
			printf("keys do not match! requesting parameters\n");
			p = requestreturnparameters(c);
			d->key = upd->key;
			d->size = p->Nbins;
		}
		clear(d);
		d->dUstar = upd->dUstar;
		dUstar = upd->dUstar;
		Uold = penalty(s, p, upd, measureold);

		if (upd->dUstar < p->dUstartol) {
		//	done = 1;
		}
	}
	
	delete [] P;
	delete [] Pi;
	delete change;

}

