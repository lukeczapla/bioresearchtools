#include <stdio.h>
#include <stdlib.h>

#include "socket/socket.h"
#include "parameters/parameters.h"

int main(int argc, char **argv) {
	socket_type *c = initsocket("127.0.0.1", atoi(argv[1]));
	parameter_type *p = requestreturnparameters(c);
	data_type *d = new data_type;
	d->size = p->Nbins;
	d->dUstar = p->dUstar;
	for (int i = 0; i < d->size; i++) d->Ustar[i] = 0;
	data_type *dr = requestupdateparameters(c, d);

	for (int i = 0; i < d->size; i++) {
	  printf("%d %f\n", i+1, dr->dUstar*dr->Ustar[i]);
	}
	printf("dU* = %e\n", dr->dUstar);

	delete c;
	delete d;
	delete p;
	delete dr;

	return 0;
}

