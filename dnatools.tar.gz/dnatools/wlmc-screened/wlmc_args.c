int port;
char host[128];
char inputfile[128];
char savefile[128];
long int Neq;
int calcP;
int usevis;

unsigned short key[3];

#include "jsocket/jsocket.h"

float *add_phosphates(matrix *v, int nsteps) {
	float *s = new float[9*nsteps+3];
	matrix temp = identity(4);
	matrix M;
	for (int i = nsteps/2; i < nsteps; i++) {
	    M = temp*calculateM(v[i]);
//	    writematrix(stdout, M);
	    s[9*i] = temp(1,4);
	    s[9*i+1] = temp(2,4);
	    s[9*i+2] = temp(3,4);
	    temp = temp*calculateW(v[i]);
	    float midx = (s[9*i]+temp(1,4))/2.0;
	    float midy = (s[9*i+1]+temp(2,4))/2.0;
            float midz = (s[9*i+2]+temp(3,4))/2.0;
	    s[9*i+3] = midx-3.0*M(1,1)+8.9*M(1,2)-0.4*M(1,3);
	    s[9*i+4] = midy-3.0*M(2,1)+8.9*M(2,2)-0.4*M(2,3);
	    s[9*i+5] = midz-3.0*M(3,1)+8.9*M(3,2)-0.4*M(3,3);
	    s[9*i+6] = midx-3.0*M(1,1)-8.9*M(1,2)+0.4*M(1,3);
	    s[9*i+7] = midy-3.0*M(2,1)-8.9*M(2,2)+0.4*M(2,3);
	    s[9*i+8] = midz-3.0*M(3,1)-8.9*M(3,2)+0.4*M(3,3);
	}

	s[9*nsteps] = temp(1,4);
	s[9*nsteps+1] = temp(2,4);
	s[9*nsteps+2] = temp(3,4);

	temp = identity(4);
	for (int i = nsteps/2-1; i >= 0; i--) {
	    M = temp*invert(calculateM(v[i]));
	    float midx = temp(1,4);
	    float midy = temp(2,4);
	    float midz = temp(3,4); 
           temp = temp*invert(calculateW(v[i]));

            s[9*i] = temp(1,4);
            s[9*i+1] = temp(2,4);
            s[9*i+2] = temp(3,4);

	    midx = (midx+s[9*i])/2.0;
            midy = (midy+s[9*i+1])/2.0;
            midz = (midz+s[9*i+2])/2.0;


	    s[9*i+3] = midx-3.0*M(1,1)+8.9*M(1,2)-0.4*M(1,3);
	    s[9*i+4] = midy-3.0*M(2,1)+8.9*M(2,2)-0.4*M(2,3);
	    s[9*i+5] = midz-3.0*M(3,1)+8.9*M(3,2)-0.4*M(3,3);
	    s[9*i+6] = midx-3.0*M(1,1)-8.9*M(1,2)+0.4*M(1,3);
	    s[9*i+7] = midy-3.0*M(2,1)-8.9*M(2,2)+0.4*M(2,3);
	    s[9*i+8] = midz-3.0*M(3,1)-8.9*M(3,2)+0.4*M(3,3);
	}
	return s;
}


void *runvisualization(void *x) {
	system_type *s = (system_type *)x;

	double *cell = new double[3];
	cell[0] = 1.0;
	cell[1] = 1.0;
	cell[2] = 1.0;
	int size = 3*(s->dna.nsteps) + s->Nions;
	int *indices = new int[size];
	for (int i = 0; i < s->dna.nsteps; i++) {
		indices[3*i] = 1;
		indices[3*i+1] = 0;
		indices[3*i+2] = 0;
	}
	int color = 2;
	int index = 3*s->dna.nsteps;
	indices[index] = color;
	for (int i = 1; i < s->Nions; i++) {
		if (s->ions[i].charge != s->ions[i-1].charge) color++;
		indices[index+i] = color;
	}
	double *coords = new double[3*3*s->dna.nsteps+3*s->Nions];
	double *rad = new double[3*(s->dna.nsteps)+s->Nions];
	int end = 0;

	float *ph;
	matrix *v = new matrix[s->dna.nsteps];
	sleep(2);
	while (1) {
		for (int i = 0; i < s->dna.nsteps; i++) {
			v[i] = s->dna.v[i];
		}
		ph = add_phosphates(v, s->dna.nsteps);
		for (int i = 0; i < s->dna.nsteps; i++) {
			coords[9*i] = ph[9*i];
			coords[9*i+1] = ph[9*i+1];
			coords[9*i+2] = ph[9*i+2];
			coords[9*i+3] = ph[9*i+3];
			coords[9*i+4] = ph[9*i+4];
			coords[9*i+5] = ph[9*i+5];
			coords[9*i+6] = ph[9*i+6];
			coords[9*i+7] = ph[9*i+7];
			coords[9*i+8] = ph[9*i+8];
			rad[3*i] = 11.0;
			rad[3*i+1] = 4.5;
			rad[3*i+2] = 4.5;
		}
		for (int i = 0; i < s->Nions; i++) {
			coords[9*(s->dna.nsteps)+3*i] = s->ions[i].x;
			coords[9*(s->dna.nsteps)+3*i+1] = s->ions[i].y;
			coords[9*(s->dna.nsteps)+3*i+2] = s->ions[i].z;
			rad[3*(s->dna.nsteps)+i] = s->ions[i].r;
		}
		delete [] ph;
		jsocket *js = GetJSocket((char *)"localhost", 7001, 0);
		if (js != NULL) {
			if (WriteJSocket(js->socket, cell, 3*sizeof(double)) == -1) end = 1;
			if (WriteJSocket(js->socket, &size, sizeof(int)) == -1) end = 1;
			if (WriteJSocket(js->socket, rad, size*sizeof(double)) == -1) end = 1;
			if (WriteJSocket(js->socket, indices, size*sizeof(int)) == -1) end = 1;
			if (WriteJSocket(js->socket, coords, 3*size*sizeof(double)) == -1) end = 1;
			FreeJSocket(js);
		}
		sleep(4);
	}


	
}

void printhelp() {
	printf("Usage: ./wlmc [extra parameters]\n\n");
	printf("-h hostname[127.0.0.1]: specify hostname of server\n");
	printf("-p port[7000]: specify port of server at hostname\n");
	printf("-i input-file[input.dat]: specify input file\n");
	printf("-e number[1000000]: specify number of equilibration ion moves\n");
	printf("-k x y z[random]: specify random number key (three 16-bit integers)\n");
	printf("-w filename[none]: save configurations to filename\n");
	printf("-v: turn on connection to local visualization server\n");
	printf("-P: compute persistence length outside Wang-Landau\n\n");
}

void parsecmdline(int argc, char **argv) {
	port = 7000;
	strcpy(host, "127.0.0.1");
	strcpy(inputfile, "input.dat");
	strcpy(savefile, "");
	usevis = 0;
	calcP = 0;
	Neq = 1000000;

	key[0] = (unsigned short)getpid();
	key[1] = (unsigned short)time(NULL);
	key[2] = (unsigned short)getuid();

	for (int i = 1; i < argc; i++) {
		if (strcmp(argv[i], "-h") == 0) {
			strcpy(host, argv[i+1]);
			i++;
		} else if (strcmp(argv[i], "-p") == 0) {
			sscanf(argv[i+1], "%d", &port);
			i++;
		} else if (strcmp(argv[i], "-i") == 0) {
			strcpy(inputfile, argv[i+1]);
			i++;
		} else if (strcmp(argv[i], "-k") == 0) {
			sscanf(argv[i+1], "%hu", &key[0]);
			sscanf(argv[i+2], "%hu", &key[1]);
			sscanf(argv[i+3], "%hu", &key[2]);
			i += 3;
		} else if (strcmp(argv[i], "-e") == 0) {
			sscanf(argv[i+1], "%ld", &Neq);
			i++;
		} else if (strcmp(argv[i], "-v") == 0) {
			usevis = 1;
		} else if (strcmp(argv[i], "-w") == 0) {
			strcpy(savefile, argv[i+1]);
			i++;
		} else if (strcmp(argv[i], "-P") == 0) {
			calcP = 1;
		}
		else {
			printf("bad command line parameter %s\n", argv[i]);
			printhelp();
			exit(0);
		}
	}

}


