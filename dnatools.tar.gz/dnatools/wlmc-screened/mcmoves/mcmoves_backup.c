#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mcmoves.h"
#include "../energy/energy.h"
#include "../tools/tools.h"

int ionlist[10000];
int ionlist2[10000];

int add_to_list(int ionN, int index) {
	ionlist[ionN] = index;
} 


int add_to_list2(int ionN, int index) {
	ionlist2[ionN] = index;
} 


int not_in_list2(int ionN, int index) {
	for (int i = 0; i < ionN; i++) if (ionlist2[i] == index) return 0;
	return 1;
}


int not_in_list(int ionN, int index) {
	for (int i = 0; i < ionN; i++) if (ionlist[i] == index) return 0;
	return 1;
}

void cross(double &x, double &y, double &z, double x1, double y1, double z1, double x2, double y2, double z2) {
	x = y1*z2 - z1*y2;
	y = x1*z2 - z1*x2;
	z = x1*y2 - x2*y1;
}


// clothed pivot move - remember that index (Nmonomers / 2) is fixed at the origin
int movepolymer(system_type *s, double &dE) {

	dE = 0.0;

	double E = calculateenergy(s);

// pick which half of the polymer to move
	int half = 2*drand48();
	
	int m;
	double d;
	double x1, y1, z1, r1;
	double zx, zy, zz, zr;
	double xx, xy, xz, xr;
	double yx, yy, yz, yr;
	double xold, yold, zold, xold2, yold2, zold2;
	double z2x, z2y, z2z;
	double costh, sinth, cosphi, sinphi, cosphi_old, cosphi_new, L;
	double dphi, dtheta, phi1, theta1;
	
	int ionN = 0;
	int ionN2 = 0;
	int added = 0;
	
// do the second half first, since the ordering is positive
	if (half == 0) {

		m = (s->Nmonomers / 2) + (s->Nmonomers - s->Nmonomers / 2 - 2) * drand48();

// check to see what ions we need to add to the cloth
		for (int j = 0; j < s->Nions; j++) {
			if (not_in_list(ionN, j)) {
				added = 0;
				for (int i = m+1; (i < s->Nmonomers) && !added; i++) {
				if (((s->monomers[i].x - s->ions[j].x) * (s->monomers[i].x - s->ions[j].x) + (s->monomers[i].y - s->ions[j].y) * (s->monomers[i].y - s->ions[j].y) + 
					(s->monomers[i].z - s->ions[j].z) * (s->monomers[i].z - s->ions[j].z) < s->pivot_r * s->pivot_r) && s->ions[j].charge > 0.0) {
					add_to_list(ionN++, j);
					added = 1;
				}
				}
			}
		}

/*		
		// interactions of the moved part of the chain with unmoved things
		for (int i = m+1; i < s->Nmonomers; i++) {
			for (int j = 0; j < m+1; j++) {
				x1 = s->monomers[i].x - s->monomers[j].x;
				y1 = s->monomers[i].y - s->monomers[j].y;
				z1 = s->monomers[i].z - s->monomers[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dE -= (double)(s->monomers[i].charge * s->monomers[j].charge) / d;
			}
			for (int j = 0; j < s->Nions; j++) {
				if (not_in_list(ionN, j)) {
					x1 = s->monomers[i].x - s->ions[j].x;
					y1 = s->monomers[i].y - s->ions[j].y;
					z1 = s->monomers[i].z - s->ions[j].z;
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					dE -= (double)(s->monomers[i].charge * s->ions[j].charge) / d;
				}
			}
		}
		
		// interaction of unmoved part of the chain with moved ions
		for (int i = 0; i < m+1; i++) {
			for (int j = 0; j < ionN; j++) {
				x1 = s->monomers[i].x - s->ions[ionlist[j]].x;
				y1 = s->monomers[i].y - s->ions[ionlist[j]].y;
				z1 = s->monomers[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dE -= (double)(s->monomers[i].charge * s->ions[ionlist[j]].charge) / d;
			}
		}
		
		// interaction of unmoved ions with moved ions
		for (int i = 0; i < s->Nions; i++) {
			if (not_in_list(ionN, i)) for (int j = 0; j < ionN; j++) {
				x1 = s->ions[i].x - s->ions[ionlist[j]].x;
				y1 = s->ions[i].y - s->ions[ionlist[j]].y;
				z1 = s->ions[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dE -= (double)(s->ions[i].charge * s->ions[ionlist[j]].charge) / d;			
			}
		}
*/

		zx = s->monomers[m].x - s->monomers[m-1].x;
		zy = s->monomers[m].y - s->monomers[m-1].y;
		zz = s->monomers[m].z - s->monomers[m-1].z;
		zr = sqrt(zx*zx + zy*zy + zz*zz);
		zx /= zr;
		zy /= zr;
		zz /= zr;
		x1 = s->monomers[m+1].x - s->monomers[m].x;
		y1 = s->monomers[m+1].y - s->monomers[m].y;
		z1 = s->monomers[m+1].z - s->monomers[m].z;
		r1 = sqrt(x1*x1+y1*y1+z1*z1);
		if ((zx * x1 + zy * y1 + zz * z1) / r1 >= 1.0) {
			z2x = zx + 0.1;
			z2y = zy + 0.1;
			z2z = zz;
			cross(yx, yy, yz, zx, zy, zz, z2x, z2y, z2z);
		} else cross(yx, yy, yz, zx, zy, zz, x1/r1, y1/r1, z1/r1);

		
		yr = sqrt(yx*yx+yy*yy+yz*yz);
		yx /= yr;
		yy /= yr;
		yz /= yr;
		cross(xx, xy, xz, yx, yy, yz, zx, zy, zz);
		xr = sqrt(xx*xx+xy*xy+xz*xz);
		xx /= xr;
		xy /= xr;
		xz /= xr;
		
		phi1 = RADIANS_TO_DEGREES * acos(((zx * x1 + zy * y1 + zz * z1) / r1 > 1.0) ? 1.0 : (zx * x1 + zy * y1 + zz * z1) / r1);
		theta1 = RADIANS_TO_DEGREES * atan2((x1 * yx + y1 * yy + z1 * yz), (x1 * xx + y1 * xy + z1 * xz));

		dphi = 10.0 * (drand48() - 0.5);
		dtheta = 10.0 * (drand48() - 0.5);
		
		costh = cos(DEGREES_TO_RADIANS * (theta1 + dtheta));
		sinth = sin(DEGREES_TO_RADIANS * (theta1 + dtheta));
		
		cosphi = cos(DEGREES_TO_RADIANS * (phi1 + dphi));
		sinphi = sin(DEGREES_TO_RADIANS * (phi1 + dphi));
		
//		printf("old = %f %f %f\n", s->monomers[m+1].x, s->monomers[m+1].y, s->monomers[m+1].z);

		xold2 = s->monomers[m].x;
		yold2 = s->monomers[m].y;
		zold2 = s->monomers[m].z;
		xold = s->monomers[m+1].x;
		yold = s->monomers[m+1].y;
		zold = s->monomers[m+1].z;
		s->monomers[m+1].x = s->bonds[m].L * (sinphi*(costh*xx+sinth*yx) + cosphi*zx) / r1 + s->monomers[m].x;
		s->monomers[m+1].y = s->bonds[m].L * (sinphi*(costh*xy+sinth*yy) + cosphi*zy) / r1 + s->monomers[m].y;
		s->monomers[m+1].z = s->bonds[m].L * (sinphi*(costh*xz+sinth*yz) + cosphi*zz) / r1 + s->monomers[m].z;

//		printf("new = %f %f %f, pivot = %f %f\n", s->monomers[m+1].x, s->monomers[m+1].y, s->monomers[m+1].z, dtheta, dphi);

		for (int i = 0; i < ionN; i++) {
			x1 = s->ions[ionlist[i]].x - s->monomers[m].x;
			y1 = s->ions[ionlist[i]].y - s->monomers[m].y;
			z1 = s->ions[ionlist[i]].z - s->monomers[m].z;
			r1 = sqrt(x1*x1+y1*y1+z1*z1);
			theta1 = RADIANS_TO_DEGREES * atan2((x1 * yx + y1 * yy + z1 * yz), (x1 * xx + y1 * xy + z1 * xz));
			costh = cos(DEGREES_TO_RADIANS * (theta1 + dtheta));
			sinth = sin(DEGREES_TO_RADIANS * (theta1 + dtheta));
			phi1 = RADIANS_TO_DEGREES * acos(((zx * x1 + zy * y1 + zz * z1) / r1 > 1.0) ? 1.0 : (zx * x1 + zy * y1 + zz * z1) / r1);
			cosphi = cos(DEGREES_TO_RADIANS * (phi1 + dphi));
			sinphi = sin(DEGREES_TO_RADIANS * (phi1 + dphi));
//			printf("old = %f %f %f\n", s->ions[ionlist[i]].x, s->ions[ionlist[i]].y, s->ions[ionlist[i]].z);
			s->ions[ionlist[i]].x = r1*sinphi*(costh*xx + sinth*yx) + r1*cosphi*zx + s->monomers[m].x;
			s->ions[ionlist[i]].y = r1*sinphi*(costh*xy + sinth*yy) + r1*cosphi*zy + s->monomers[m].y;
			s->ions[ionlist[i]].z = r1*sinphi*(costh*xz + sinth*yz) + r1*cosphi*zz + s->monomers[m].z;
//			printf("new = %f %f %f\n", s->ions[ionlist[i]].x, s->ions[ionlist[i]].y, s->ions[ionlist[i]].z);
		}

		for (int i = m+1; i < s->Nmonomers - 1; i++) {

			zx = xold - xold2;
			zy = yold - yold2;
			zz = zold - zold2;
			zr = sqrt(zx*zx + zy*zy + zz*zz);
			zx /= zr;
			zy /= zr;
			zz /= zr;
			x1 = s->monomers[i+1].x - xold;
			y1 = s->monomers[i+1].y - yold;
			z1 = s->monomers[i+1].z - zold;
			r1 = sqrt(x1*x1+y1*y1+z1*z1);
			if ((zx * x1 + zy * y1 + zz * z1) / r1 >= 1.0) {
				z2x = zx + 0.1;
				z2y = zy + 0.1;
				z2z = zz;
				cross(yx, yy, yz, zx, zy, zz, z2x, z2y, z2z);
			} else cross(yx, yy, yz, zx, zy, zz, x1/r1, y1/r1, z1/r1);
			yr = sqrt(yx*yx+yy*yy+yz*yz);
			yx /= yr;
			yy /= yr;
			yz /= yr;
			cross(xx, xy, xz, yx, yy, yz, zx, zy, zz);
			xr = sqrt(xx*xx+xy*xy+xz*xz);
			xx /= xr;
			xy /= xr;
			xz /= xr;
			theta1 = RADIANS_TO_DEGREES * atan2((x1 * yx + y1 * yy + z1 * yz), (x1 * xx + y1 * xy + z1 * xz));
			if (i == m+1) theta1 += dtheta;
			costh = cos(DEGREES_TO_RADIANS * theta1);
			sinth = sin(DEGREES_TO_RADIANS * theta1);
			phi1 = RADIANS_TO_DEGREES * acos(((zx * x1 + zy * y1 + zz * z1) / r1 > 1.0) ? 1.0 : (zx * x1 + zy * y1 + zz * z1) / r1);
			if (i == m+1) phi1 += dphi;
			cosphi = cos(DEGREES_TO_RADIANS * phi1);
			sinphi = sin(DEGREES_TO_RADIANS * phi1);
			xold2 = xold;
			yold2 = yold;
			zold2 = zold;
			xold = s->monomers[i+1].x;
			yold = s->monomers[i+1].y;
			zold = s->monomers[i+1].z;
			s->monomers[i+1].x = s->bonds[i].L * (sinphi*(costh*xx+sinth*yx) + cosphi*zx) / r1 + s->monomers[i].x;
			s->monomers[i+1].y = s->bonds[i].L * (sinphi*(costh*xy+sinth*yy) + cosphi*zy) / r1 + s->monomers[i].y;
			s->monomers[i+1].z = s->bonds[i].L * (sinphi*(costh*xz+sinth*yz) + cosphi*zz) / r1 + s->monomers[i].z;
		}
/*
		for (int i = s->Nmonomers - 2; i > m; i--) {
			x1 = s->monomers[i+1].x - s->monomers[i].x;
			y1 = s->monomers[i+1].y - s->monomers[i].y;
			z1 = s->monomers[i+1].z - s->monomers[i].z;
			r1 = sqrtf(x1*x1+y1*y1+z1*z1);
			s->monomers[i+1].x = s->bonds[i].L * x1 / r1 + s->monomers[i].x;
			s->monomers[i+1].y = s->bonds[i].L * y1 / r1 + s->monomers[i].y;
			s->monomers[i+1].z = s->bonds[i].L * z1 / r1 + s->monomers[i].z;
		}
*/

		for (int j = 0; j < s->Nions; j++) {	
				if (not_in_list2(ionN2, j)) {
					added = 0;
					for (int i = m+1; (i < s->Nmonomers) && !added; i++) {
						if (((s->monomers[i].x - s->ions[j].x) * (s->monomers[i].x - s->ions[j].x) + (s->monomers[i].y - s->ions[j].y) * (s->monomers[i].y - s->ions[j].y) + 
							(s->monomers[i].z - s->ions[j].z) * (s->monomers[i].z - s->ions[j].z) < s->pivot_r * s->pivot_r) && (s->ions[j].charge > 0.0)) {
								add_to_list2(ionN2++, j);
								added = 1;
						}
					}				
				}
		}
		
		if (ionN != ionN2) {
			dE = 1e100;
			return 0;
		}
/*
		// interaction of moved part of the chain with unmoved things
		for (int i = m+1; i < s->Nmonomers; i++) {
			for (int j = 0; j < ionN; j++) {
				x1 = s->monomers[i].x - s->ions[ionlist[j]].x;
				y1 = s->monomers[i].y - s->ions[ionlist[j]].y;
				z1 = s->monomers[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1*x1 + y1*y1 + z1*z1);
				if (d < s->monomers[i].r + s->ions[ionlist[j]].r) {
					dE = 1e100;
					return 0;
				}
			}

			for (int j = 0; j < s->Nions; j++) {
				if (not_in_list(ionN, j)) {
					x1 = s->monomers[i].x - s->ions[j].x;
					y1 = s->monomers[i].y - s->ions[j].y;
					z1 = s->monomers[i].z - s->ions[j].z;
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					if (d < s->monomers[i].r + s->ions[j].charge) {
						dE = 1e100;
						return 0;
					}
					dE += (double)(s->monomers[i].charge * s->ions[j].charge) / d;
				}
			}
			for (int j = 0; j < m+1; j++) {
				x1 = s->monomers[i].x - s->monomers[j].x;
				y1 = s->monomers[i].y - s->monomers[j].y;
				z1 = s->monomers[i].z - s->monomers[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				if ((i - j > 10) && (d < s->monomers[i].r + s->monomers[j].r)) {
					dE = 1e100;
					return 0;
				}
				dE += (double)(s->monomers[i].charge * s->monomers[j].charge) / d;
			}
		}

		// interaction of unmoved part of the chain with moved ions
		for (int i = 0; i < m+1; i++) {
			for (int j = 0; j < ionN; j++) {
				x1 = s->monomers[i].x - s->ions[ionlist[j]].x;
				y1 = s->monomers[i].y - s->ions[ionlist[j]].y;
				z1 = s->monomers[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				if (d < s->monomers[i].r + s->ions[ionlist[j]].r) {
					dE = 1e100;
					return 0;
				}
				dE += (double)(s->monomers[i].charge * s->ions[ionlist[j]].charge) / d;
			}
		}
		// interaction of moved ions with unmoved ions
		for (int i = 0; i < s->Nions; i++) {
			if (not_in_list(ionN, i)) for (int j = 0; j < ionN; j++) {
				x1 = s->ions[i].x - s->ions[ionlist[j]].x;
				y1 = s->ions[i].y - s->ions[ionlist[j]].y;
				z1 = s->ions[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				if (d < s->ions[i].r + s->ions[ionlist[j]].r) {
					dE = 1e100;
					return 0;
				}
				dE += (double)(s->ions[i].charge * s->ions[ionlist[j]].charge) / d;			
			}
		}
*/
	} else {
// do the first half
		m = 1 + (s->Nmonomers / 2) * drand48();
		
// check to see what ions we need to add to the cloth
		for (int j = 0; j < s->Nions; j++) {
		 	if (not_in_list(ionN, j)) {
				added = 0;
				for (int i = 0; (i < m) && !added; i++) {
					if (((s->monomers[i].x - s->ions[j].x) * (s->monomers[i].x - s->ions[j].x) + (s->monomers[i].y - s->ions[j].y) * (s->monomers[i].y - s->ions[j].y) + 
						(s->monomers[i].z - s->ions[j].z) * (s->monomers[i].z - s->ions[j].z) < s->pivot_r * s->pivot_r) && (s->ions[j].charge > 0.0)) {
							add_to_list(ionN++, j);
							added = 1;
						}
				}
			}
		}
/*
		// unmoved chain with moved ions and moved chains
		for (int i = m; i < s->Nmonomers; i++) {
			for (int j = 0; j < ionN; j++) {
				x1 = s->monomers[i].x - s->ions[ionlist[j]].x;
				y1 = s->monomers[i].y - s->ions[ionlist[j]].y;
				z1 = s->monomers[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dE -= (double)(s->monomers[i].charge * s->ions[ionlist[j]].charge) / d;
			}
			for (int j = 0; j < m; j++) {
				x1 = s->monomers[i].x - s->monomers[j].x;
				y1 = s->monomers[i].y - s->monomers[j].y;
				z1 = s->monomers[i].z - s->monomers[j].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dE -= (double)(s->monomers[i].charge * s->monomers[j].charge) / d;
			}
		}
		
		// unmoved ions with moved ions
		for (int i = 0; i < s->Nions; i++) {
			if (not_in_list(ionN, i)) for (int j = 0; j < ionN; j++) {
				x1 = s->ions[i].x - s->ions[ionlist[j]].x;
				y1 = s->ions[i].y - s->ions[ionlist[j]].y;
				z1 = s->ions[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				dE -= (double)(s->ions[i].charge * s->ions[ionlist[j]].charge) / d;			
			}
		}

		// moved chain with unmoved ions
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < s->Nions; j++) {
				if (not_in_list(ionN, j)) {
					x1 = s->monomers[i].x - s->ions[j].x;
					y1 = s->monomers[i].y - s->ions[j].y;
					z1 = s->monomers[i].z - s->ions[j].z;
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					dE -= (double)(s->monomers[i].charge * s->ions[j].charge) / d;
				}
			}
		}
*/
		zx = s->monomers[m].x - s->monomers[m+1].x;
		zy = s->monomers[m].y - s->monomers[m+1].y;
		zz = s->monomers[m].z - s->monomers[m+1].z;
		zr = sqrt(zx*zx + zy*zy + zz*zz);
		zx /= zr;
		zy /= zr;
		zz /= zr;
		x1 = s->monomers[m-1].x - s->monomers[m].x;
		y1 = s->monomers[m-1].y - s->monomers[m].y;
		z1 = s->monomers[m-1].z - s->monomers[m].z;
		r1 = sqrt(x1*x1+y1*y1+z1*z1);
		if ((zx * x1 + zy * y1 + zz * z1) / r1 >= 1.0) {
			z2x = zx + 0.1;
			z2y = zy + 0.1;
			z2z = zz;
			cross(yx, yy, yz, zx, zy, zz, z2x, z2y, z2z);
		} else cross(yx, yy, yz, zx, zy, zz, x1/r1, y1/r1, z1/r1);
	
		yr = sqrt(yx*yx+yy*yy+yz*yz);
		yx /= yr;
		yy /= yr;
		yz /= yr;
		cross(xx, xy, xz, yx, yy, yz, zx, zy, zz);
		xr = sqrt(xx*xx+xy*xy+xz*xz);
		xx /= xr;
		xy /= xr;
		xz /= xr;
		phi1 = RADIANS_TO_DEGREES*acos(((zx * x1 + zy * y1 + zz * z1) / r1 > 1.0) ? 1.0 : (zx * x1 + zy * y1 + zz * z1) / r1);
		theta1 = RADIANS_TO_DEGREES*atan2((x1 * yx + y1 * yy + z1 * yz), (x1 * xx + y1 * xy + z1 * xz));

		dphi = 10.0 * (drand48() - 0.5);
		dtheta = 10.0 * (drand48() - 0.5);
		
		costh = cos(DEGREES_TO_RADIANS * (theta1 + dtheta));
		sinth = sin(DEGREES_TO_RADIANS * (theta1 + dtheta));
		
		cosphi = cos(DEGREES_TO_RADIANS * (phi1 + dphi));
		sinphi = sin(DEGREES_TO_RADIANS * (phi1 + dphi));
		
		xold = s->monomers[m-1].x;
		yold = s->monomers[m-1].y;
		zold = s->monomers[m-1].z;
		xold2 = s->monomers[m].x;
		yold2 = s->monomers[m].y;
		zold2 = s->monomers[m].z;
		s->monomers[m-1].x = s->bonds[m-1].L * (sinphi*(costh*xx+sinth*yx) + cosphi*zx) / r1 + s->monomers[m].x;
		s->monomers[m-1].y = s->bonds[m-1].L * (sinphi*(costh*xy+sinth*yy) + cosphi*zy) / r1 + s->monomers[m].y;
		s->monomers[m-1].z = s->bonds[m-1].L * (sinphi*(costh*xz+sinth*yz) + cosphi*zz) / r1 + s->monomers[m].z;

		for (int i = 0; i < ionN; i++) {
			x1 = s->ions[ionlist[i]].x - s->monomers[m].x;
			y1 = s->ions[ionlist[i]].y - s->monomers[m].y;
			z1 = s->ions[ionlist[i]].z - s->monomers[m].z;
			r1 = sqrt(x1*x1+y1*y1+z1*z1);
			theta1 = RADIANS_TO_DEGREES * atan2((x1 * yx + y1 * yy + z1 * yz), (x1 * xx + y1 * xy + z1 * xz));
			theta1 += dtheta;
			costh = cos(DEGREES_TO_RADIANS * theta1);
			sinth = sin(DEGREES_TO_RADIANS * theta1);
			phi1 = RADIANS_TO_DEGREES * acos(((zx * x1 + zy * y1 + zz * z1) / r1 > 1.0) ? 1.0 : (zx * x1 + zy * y1 + zz * z1) / r1);
			cosphi = cos(DEGREES_TO_RADIANS * (phi1 + dphi));
			sinphi = sin(DEGREES_TO_RADIANS * (phi1 + dphi));
			s->ions[ionlist[i]].x = r1*sinphi*(costh*xx + sinth*yx) + r1*cosphi*zx + s->monomers[m].x;
			s->ions[ionlist[i]].y = r1*sinphi*(costh*xy + sinth*yy) + r1*cosphi*zy + s->monomers[m].y;
			s->ions[ionlist[i]].z = r1*sinphi*(costh*xz + sinth*yz) + r1*cosphi*zz + s->monomers[m].z;
		}
		
		for (int i = m-2; i >= 0; i--) {
			zx = xold - xold2;
			zy = yold - yold2;
			zz = zold - zold2;
			zr = sqrt(zx*zx + zy*zy + zz*zz);
			zx /= zr;
			zy /= zr;
			zz /= zr;
			x1 = s->monomers[i].x - xold;
			y1 = s->monomers[i].y - yold;
			z1 = s->monomers[i].z - zold;
			r1 = sqrt(x1*x1+y1*y1+z1*z1);
			if ((zx * x1 + zy * y1 + zz * z1) / r1 >= 1.0) {
				z2x = zx + 0.1;
				z2y = zy + 0.1;
				z2z = zz;
				cross(yx, yy, yz, zx, zy, zz, z2x, z2y, z2z);
			} else cross(yx, yy, yz, zx, zy, zz, x1/r1, y1/r1, z1/r1);
			yr = sqrt(yx*yx+yy*yy+yz*yz);
			yx /= yr;
			yy /= yr;
			yz /= yr;
			cross(xx, xy, xz, yx, yy, yz, zx, zy, zz);
			xr = sqrt(xx*xx+xy*xy+xz*xz);
			xx /= xr;
			xy /= xr;
			xz /= xr;
			theta1 = RADIANS_TO_DEGREES * atan2((x1 * yx + y1 * yy + z1 * yz), (x1 * xx + y1 * xy + z1 * xz));
			if (i == m-2) theta1 += dtheta;
			costh = cos(DEGREES_TO_RADIANS * theta1);
			sinth = sin(DEGREES_TO_RADIANS * theta1);
			phi1 = RADIANS_TO_DEGREES * acos(((zx * x1 + zy * y1 + zz * z1) / r1 > 1.0) ? 1.0 : (zx * x1 + zy * y1 + zz * z1) / r1);
			if (i == m-2) phi1 += dphi;	
			cosphi = cos(DEGREES_TO_RADIANS * phi1);
			sinphi = sin(DEGREES_TO_RADIANS * phi1);
			xold2 = xold;
			yold2 = yold;
			zold2 = zold;
			xold = s->monomers[i].x;
			yold = s->monomers[i].y;
			zold = s->monomers[i].z;
			s->monomers[i].x = s->bonds[i].L * (sinphi*(costh*xx+sinth*yx) + cosphi*zx) / r1 + s->monomers[i+1].x;
			s->monomers[i].y = s->bonds[i].L * (sinphi*(costh*xy+sinth*yy) + cosphi*zy) / r1 + s->monomers[i+1].y;
			s->monomers[i].z = s->bonds[i].L * (sinphi*(costh*xz+sinth*yz) + cosphi*zz) / r1 + s->monomers[i+1].z;
		}
		
		/*
		for (int i = 0; i < m; i++) {
			x1 = s->monomers[i+1].x - s->monomers[i].x;
			y1 = s->monomers[i+1].y - s->monomers[i].y;
			z1 = s->monomers[i+1].z - s->monomers[i].z;
			r1 = sqrtf(x1*x1+y1*y1+z1*z1);
			s->monomers[i+1].x = s->bonds[i].L * x1 / r1 + s->monomers[i].x;
			s->monomers[i+1].y = s->bonds[i].L * y1 / r1 + s->monomers[i].y;
			s->monomers[i+1].z = s->bonds[i].L * z1 / r1 + s->monomers[i].z;			
		}
		*/


		for (int j = 0; j < s->Nions; j++) {
			if (not_in_list2(ionN2, j)) {
				added = 0;
				for (int i = 0; (i < m) && !added; i++) {
				if (((s->monomers[i].x - s->ions[j].x) * (s->monomers[i].x - s->ions[j].x) + (s->monomers[i].y - s->ions[j].y) * (s->monomers[i].y - s->ions[j].y) + 
					(s->monomers[i].z - s->ions[j].z) * (s->monomers[i].z - s->ions[j].z) < s->pivot_r * s->pivot_r) && (s->ions[j].charge > 0.0)) {
						add_to_list2(ionN2++, j);
						added = 1;
					}
			}
		}
		}
		
		if (ionN != ionN2) {
			dE = 1e100;
			return 0;
		}

/*
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < ionN; j++) {
				x1 = s->monomers[i].x - s->ions[ionlist[j]].x;
				y1 = s->monomers[i].y - s->ions[ionlist[j]].y;
				z1 = s->monomers[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1*x1 + y1*y1 + z1*z1);
				if (d < s->monomers[i].r + s->ions[ionlist[j]].r) {
					dE = 1e100;
					return 0;
				}
			}
		}

		// moved chain with unmoved chain and unmoved ions
		for (int i = 0; i < m; i++) {
			for (int j = m; j < s->Nmonomers; j++) {
				x1 = s->monomers[i].x - s->monomers[j].x;
				y1 = s->monomers[i].y - s->monomers[j].y;
				z1 = s->monomers[i].z - s->monomers[j].z;
				d = sqrt(x1*x1 + y1*y1 + z1*z1);
				if (((j - i) > 10) && (d < s->monomers[i].r + s->monomers[j].r)) {
					dE = 1e100;
					return 0;
				}
				dE += (double)(s->monomers[i].charge * s->monomers[j].charge) / d;
			}
			for (int j = 0; j < s->Nions; j++) {
				if (not_in_list(ionN, j)) {
					x1 = s->monomers[i].x - s->ions[j].x;
					y1 = s->monomers[i].y - s->ions[j].y;
					z1 = s->monomers[i].z - s->ions[j].z;
					d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
					if (d < s->monomers[i].r + s->ions[j].r) {
						dE = 1e100;
						return 0;
					}
					dE += (double)(s->monomers[i].charge * s->ions[j].charge) / d;
				}
			}
		}
		
		// unmoved chain with moved ions
		for (int i = m; i < s->Nmonomers; i++) {
			for (int j = 0; j < ionN; j++) {
				x1 = s->monomers[i].x - s->ions[ionlist[j]].x;
				y1 = s->monomers[i].y - s->ions[ionlist[j]].y;
				z1 = s->monomers[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				if (d < s->monomers[i].r + s->ions[ionlist[j]].r) {
					dE = 1e100;
					return 0;
				}
				dE += (double)(s->monomers[i].charge * s->ions[ionlist[j]].charge) / d;
			}
		}
		// unmoved ions with moved ions
		for (int i = 0; i < s->Nions; i++) {
			if (not_in_list(ionN, i)) for (int j = 0; j < ionN; j++) {
				x1 = s->ions[i].x - s->ions[ionlist[j]].x;
				y1 = s->ions[i].y - s->ions[ionlist[j]].y;
				z1 = s->ions[i].z - s->ions[ionlist[j]].z;
				d = sqrt(x1 * x1 + y1 * y1 + z1 * z1);
				if (d < s->ions[i].r + s->ions[ionlist[j]].r) {
					dE = 1e100;
					return 0;
				}
				dE += (double)(s->ions[i].charge * s->ions[ionlist[j]].charge) / d;			
			}
		}
*/
	}
	
//	dE = K_ES * dE / DIELECTRIC;
//	dE += calculatepolymerenergy(s) - pE;

	dE = calculateenergy(s) - E;
	printf("dE = %lf\n", dE);
//	printf("dE = %lf, half = %d\n", dE, half);
	return 1;
	
}


// displace an ion
int moveion(system_type *s, double &dE) {

//	printf("We have %d ions\n", s->Nions);
	
// pick a random ion to displace
	int q = s->Nions * drand48();

	float dx = s->d_max * 2.0 * (drand48() - 0.5);
	float dy = s->d_max * 2.0 * (drand48() - 0.5);
	float dz = s->d_max * 2.0 * (drand48() - 0.5);

	double d;
	
	dE = 0.0;
	
	for (int i = 0; i < s->Nions; i++) {
		if (i != q) {
			d = sqrt((s->ions[i].x - s->ions[q].x) * (s->ions[i].x - s->ions[q].x) + (s->ions[i].y - s->ions[q].y) * (s->ions[i].y - s->ions[q].y) + (s->ions[i].z - s->ions[q].z) * (s->ions[i].z - s->ions[q].z));
			dE -= (double)(s->ions[i].charge * s->ions[q].charge) / d;
		}
	}
	for (int i = 0; i < s->Nmonomers; i++) {
		d = sqrt((s->monomers[i].x - s->ions[q].x) * (s->monomers[i].x - s->ions[q].x) + (s->monomers[i].y - s->ions[q].y) * (s->monomers[i].y - s->ions[q].y) + (s->monomers[i].z - s->ions[q].z) * (s->monomers[i].z - s->ions[q].z));
		dE -= (double)(s->monomers[i].charge * s->ions[q].charge) / d;
	}

	s->ions[q].x += dx;
	s->ions[q].y += dy;
	s->ions[q].z += dz;

	if (sqrt(s->ions[q].x * s->ions[q].x + s->ions[q].y * s->ions[q].y + s->ions[q].z * s->ions[q].z) > s->cell_radius - s->ions[q].r) {
		dE = 0.0;
		return 0;
	}

	for (int i = 0; i < s->Nions; i++) {
		if (i != q) {
			d = sqrt((s->ions[i].x - s->ions[q].x) * (s->ions[i].x - s->ions[q].x) + (s->ions[i].y - s->ions[q].y) * (s->ions[i].y - s->ions[q].y) + (s->ions[i].z - s->ions[q].z) * (s->ions[i].z - s->ions[q].z));
			if (d < s->ions[i].r + s->ions[q].r) {
				dE = 1e100;
				return 0;
			}
			dE += (double)(s->ions[i].charge * s->ions[q].charge) / d;
		}
	}
	
	for (int i = 0; i < s->Nmonomers; i++) {
		d = sqrt((s->monomers[i].x - s->ions[q].x) * (s->monomers[i].x - s->ions[q].x) + (s->monomers[i].y - s->ions[q].y) * (s->monomers[i].y - s->ions[q].y) + (s->monomers[i].z - s->ions[q].z) * (s->monomers[i].z - s->ions[q].z));
		if (d < s->monomers[i].r + s->ions[q].r) {
			dE = 1e100;
			return 0;
		}
		dE += (double)(s->monomers[i].charge * s->ions[q].charge) / d;
	}
	
	dE = K_ES * dE / DIELECTRIC;

	return 1;

}


// mcmove(system, dE) : 
// returns 1 if the move is valid, 0 if the move is invalid
// updates the system and returns (new energy - old energy) without factoring in U*
int mcmove(system_type *s, double &dE) {

	return (moveion(s, dE));
	
}

