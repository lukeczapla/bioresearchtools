#ifndef _ION_H

#define _ION_H

class ion {
public:
	double x,y,z,charge,radius;
	void set_position(double a, double b, double c);

}

#endif
