#include <stdio.h>
#include <math.h>

main() {
  for (int i = 1; i <= 80; i++) {
    printf("%d %lf\n", i, log(pow(21.1+0.5*(double)(i), 2.0) - pow(21.1+0.5*(double)(i-1), 2.0))-3.061052);
  }
}
